"""Builds one exam booklet (title/instructions + questions) as a PDF."""

import io
from dataclasses import dataclass, replace as dc_replace
from xml.sax.saxutils import escape

from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import BaseDocTemplate, Flowable, Frame, PageBreak, PageTemplate, Spacer, Table, TableStyle
from reportlab.platypus.doctemplate import Indenter, LayoutError

from .errors import ExamError
from .fonts import enclosed_letter
from .html_render import HtmlRenderer, substitute_variables, uses_variable
from .canvas import question_html

LETTERS = "ABCDEF"
_ZERO = [("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
         ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
         ("VALIGN", (0, 0), (-1, -1), "TOP")]


from . import i18n

# the standard instructions, in English (the printed ones follow --print-language; see cli)
CALCULATED_HINT = "Write your answer in the boxes on the answer card: one digit, minus sign or decimal point per box."
FILLBLANKS_HINT = "Write your answer in the box on the answer card."


class QuestionRule(Flowable):
    """The space after a question, with a thin grey line across the middle of it (--question-rules)."""
    GREY = 0.72
    WIDTH = 0.5

    def __init__(self, height):
        super().__init__()
        self.height = height

    def wrap(self, avail_w, avail_h):
        self.width = avail_w
        return avail_w, self.height

    def draw(self):
        c = self.canv
        c.saveState()
        c.setStrokeGray(self.GREY)
        c.setLineWidth(self.WIDTH)
        c.line(0, self.height / 2, self.width, self.height / 2)
        c.restoreState()


@dataclass
class Layout:
    pagesize: tuple
    margin_left: float
    margin_right: float
    margin_top: float
    margin_bottom: float
    family: str
    font_size: float
    option_family: str
    option_size: float
    option_dot: bool = True
    option_letters: str = "plain"     # plain (A), circled (Ⓐ) or filled (🅐)
    option_columns: int = 1
    show_points: bool = False
    question_spacing: float = None   # points between questions; None = 0.9 x font size (--question-spacing)
    question_rules: bool = False     # a thin grey line between one question and the next (--question-rules)
    instructions: bool = True   # False: the quiz instructions are not printed (--no-quiz-instructions)
    title_mode: str = "inline"  # inline: top of page 1 | page: own page in the booklet | separate: own file
    # instructions printed under written questions ("" = none); see --calculated-instructions / --fill-blank-instructions
    calculated_hint: str = CALCULATED_HINT
    fillblanks_hint: str = FILLBLANKS_HINT

    @property
    def frame_width(self):
        return self.pagesize[0] - self.margin_left - self.margin_right

    @property
    def frame_height(self):
        return self.pagesize[1] - self.margin_top - self.margin_bottom


def _points_text(points):
    return i18n.points_text(points)


def _height(flowables, width):
    total = 0
    for f in flowables:
        _w, h = f.wrap(width, 1000000)
        total += h + f.getSpaceBefore() + f.getSpaceAfter()
    return total


ITEM_LETTERS = "abcdefghijklmnopqrstuvwxyz"


def match_answers_table(eb, question, perm, variables, width):
    """A matching question's answers, numbered 1, 2, 3... in this exam's order: two to a line when
    they all fit, else one."""
    L, R = eb.layout, eb.renderer
    base = R.base_ctx()
    face = eb.fonts.face(L.family, bold=True)
    num_w = stringWidth(f"{len(question.answers)}.", face, L.font_size) + L.font_size * 0.6
    answers = question.printed_answers(perm)[0]
    for cols in (2, 1):
        cell_w = width / cols
        cells, fits = [], True
        for k, text in enumerate(answers):
            body = R.render(eb._html(text, True, variables), cell_w - num_w - 4) or [R.paragraph("", base)]
            t = Table([[R.paragraph(f"{k + 1}.", dc_replace(base, bold=True)), body]], colWidths=[num_w, cell_w - num_w])
            t.setStyle(TableStyle(_ZERO + [("BOTTOMPADDING", (0, 0), (-1, -1), L.font_size * 0.2),
                                           ("RIGHTPADDING", (1, 0), (1, 0), 4)]))
            if t.wrap(cell_w, 100000)[1] > L.font_size * 1.7:
                fits = False
            cells.append(t)
        if fits or cols == 1:
            rows = [cells[i:i + cols] + [""] * (cols - len(cells[i:i + cols])) for i in range(0, len(cells), cols)]
            table = Table(rows, colWidths=[cell_w] * cols)
            table.setStyle(TableStyle(_ZERO))
            return table


def match_flowables(eb, question, perm, variables, width, hint):
    """What a matching question prints after its text, in a booklet: the instruction, the items
    lettered a, b, c... (in the order of their boxes on the answer card), then the numbered answers."""
    L, R = eb.layout, eb.renderer
    base = R.base_ctx()
    out = []
    if hint:
        out.append(R.paragraph(hint, dc_replace(base, italic=True), spaceBefore=3))
    out.append(Spacer(1, L.font_size * 0.35))
    letter_w = L.font_size * 1.6
    rows = []
    for k, text in enumerate(question.prompts):
        body = R.render(eb._html(text, True, variables), width - letter_w) or [R.paragraph("", base)]
        rows.append([R.paragraph(ITEM_LETTERS[k], dc_replace(base, bold=True)), body])
    items = Table(rows, colWidths=[letter_w, width - letter_w])
    items.setStyle(TableStyle(_ZERO + [("BOTTOMPADDING", (0, 0), (-1, -1), L.font_size * 0.2)]))
    out.append(items)
    out.append(Spacer(1, L.font_size * 0.45))
    out.append(match_answers_table(eb, question, perm, variables, width))
    return out


class ExamBuilder:
    def __init__(self, quiz, layout, fonts):
        self.quiz = quiz
        self.layout = layout
        self.fonts = fonts
        self.renderer = HtmlRenderer(fonts, layout.family, layout.font_size, quiz.root)
        in_questions = any(uses_variable(q.html, "PAGE COUNT") or
                           any(uses_variable(o.text, "PAGE COUNT") for o in q.options) for q in quiz.questions)
        in_title = (layout.instructions and layout.title_mode != "separate"
                    and uses_variable(quiz.description, "PAGE COUNT"))
        self.needs_page_count = in_questions or in_title

    # ------------------------------------------------------------ pieces
    def _html(self, text, is_html, variables):
        return substitute_variables(text if is_html else escape(text), variables)

    def _title_block(self, renderer, variables, width):
        ctx = renderer.base_ctx(bold=True, align=TA_CENTER)
        ctx = dc_replace(ctx, size=ctx.size * 1.45)
        flows = [renderer.paragraph(self.quiz.title, ctx, spaceAfter=ctx.size * 0.6)]
        if self.layout.instructions:
            flows += renderer.render(self._html(self.quiz.description, True, variables), width)
        return flows

    def _title_page(self, variables):
        L = self.layout
        scale = 1.0
        while True:
            flows = self._title_block(self.renderer.scaled(scale), variables, L.frame_width)
            if _height(flows, L.frame_width) <= L.frame_height - 2 or scale < 0.15:
                return flows
            scale *= 0.94

    def _question(self, number, total, question, perm, variables):
        L, R = self.layout, self.renderer
        base = R.base_ctx()
        face = self.fonts.face(L.family)
        num_w = stringWidth(f"{total}.", face, L.font_size) + L.font_size * 0.7
        pts_text = _points_text(question.points) if L.show_points else ""
        pts_w = stringWidth("(00 pts)", face, L.font_size * 0.9) + 6 if L.show_points else 0
        content_w = L.frame_width - num_w - pts_w

        content = R.render(self._html(question_html(question, perm), True, variables), content_w)
        if question.kind == "match":
            content += match_flowables(self, question, perm, variables, content_w, i18n.t("match_hint"))
        elif question.kind == "essay":     # answered in the essay space at the end of the answer card
            content.append(R.paragraph(i18n.t("essay_hint", n=number), dc_replace(base, italic=True), spaceBefore=3))
        elif question.written:
            hint = L.calculated_hint if question.kind == "numeric" else L.fillblanks_hint
            if hint:
                content.append(R.paragraph(hint, dc_replace(base, italic=True), spaceBefore=3))
        if question.qtype == "multiple_answers_question":
            content.append(R.paragraph((i18n.t("select_n", n=sum(1 for o in question.options if o.correct)) if question.scoring == "limited" else i18n.t("select_all")), dc_replace(base, italic=True), spaceBefore=2))
        content.append(Spacer(1, L.font_size * 0.45))

        printed = [] if question.written else [question.options[i] for i in perm if not question.options[i].empty]
        cols = max(1, min(L.option_columns, len(printed)))
        gap = L.font_size * 0.8
        cell_w = content_w / cols
        optface = self.fonts.face(L.option_family)
        dot = "." if L.option_dot else ""
        marks = [enclosed_letter(k, L.option_letters) + dot for k in range(len(printed))]
        letter_w = max([self.fonts.width(m, optface, L.option_size) for m in marks], default=0) + L.font_size * 0.6
        octx = dc_replace(base, family=L.option_family, size=L.option_size)
        cells = []
        for k, opt in enumerate(printed):
            body = R.render(self._html(opt.text, opt.is_html, variables), cell_w - letter_w - gap) or [R.paragraph("", base)]
            t = Table([[R.paragraph(marks[k], octx), body]], colWidths=[letter_w, cell_w - letter_w])
            t.setStyle(TableStyle(_ZERO + [("BOTTOMPADDING", (0, 0), (-1, -1), L.font_size * 0.28),
                                           ("RIGHTPADDING", (1, 0), (1, 0), gap)]))
            cells.append(t)
        rows = [cells[i:i + cols] + [""] * (cols - len(cells[i:i + cols])) for i in range(0, len(cells), cols)]
        options = Table(rows, colWidths=[cell_w] * cols) if rows else Spacer(1, 0)
        if rows:
            options.setStyle(TableStyle(_ZERO))

        number_p = R.paragraph(f"{number}.", base)
        row, widths = [number_p, content + [options]], [num_w, content_w]
        if L.show_points:
            row.append(R.paragraph(pts_text, dc_replace(base, size=base.size * 0.9), align=TA_RIGHT))
            widths.append(pts_w)
        block = Table([row], colWidths=widths)
        block.setStyle(TableStyle(_ZERO))
        gap_h = L.font_size * 0.9 if L.question_spacing is None else L.question_spacing
        after = QuestionRule(gap_h) if L.question_rules and number < total else Spacer(1, gap_h)
        if block.wrap(L.frame_width, 1000000)[1] <= L.frame_height - 4:
            return [block, after]
        # taller than a page: let it flow across pages instead of keeping it together
        out = [R.paragraph(f"{number}. {pts_text}".strip(), base), Indenter(left=num_w)]
        out += content + cells + [Indenter(left=-num_w), after]
        return out

    def _story(self, selection, variables):
        L = self.layout
        story = []
        if L.title_mode == "page":
            story += self._title_page(variables) + [PageBreak()]
        elif L.title_mode == "inline":
            story += self._title_block(self.renderer, variables, L.frame_width)
            story.append(Spacer(1, L.font_size * 1.2))
        total = len(selection)
        for n, (question, perm) in enumerate(selection, 1):
            story += self._question(n, total, question, perm, variables)
        return story

    # ------------------------------------------------------------ build
    def title_page(self, variables):
        """A stand-alone, single-page PDF holding the title and instructions."""
        return self._build_once(None, variables, "")[0]

    def build_single(self, selection, variables, geo, draw_card, who):
        """A one-page quiz: the answer area (drawn by `draw_card`) at the top of the
        page and the instructions and questions underneath. Raises ExamError when
        everything does not fit on the one page."""
        L = self.layout
        variables = dict(variables)
        variables["QUESTION COUNT"], variables["PAGE COUNT"] = len(selection), 1
        top = min(L.pagesize[1] - L.margin_top, geo["zone_bottom"] - 8)
        height = top - L.margin_bottom
        story = []
        if L.instructions:
            story = self.renderer.render(self._html(self.quiz.description, True, variables), L.frame_width)
        if story:
            story.append(Spacer(1, L.font_size * 1.0))
        total = len(selection)
        for n, (question, perm) in enumerate(selection, 1):
            story += self._question(n, total, question, perm, variables)
        if story and isinstance(story[-1], Spacer):
            story.pop()
        need = _height(story, L.frame_width)

        def too_big(detail):
            return ExamError(
                f"The quiz does not fit on a single page for {who}: {detail} Use fewer questions "
                f"(--max-items #), a smaller --font-size, smaller margins, more --option-columns, "
                f"shorter quiz instructions (or --no-quiz-instructions), or a multi-page --page-size."
            )

        if height <= 0 or need > height + 0.5:
            raise too_big(f"the instructions and {total} question(s) need {need:.0f} pt of height but only "
                          f"{max(height, 0):.0f} pt remain below the answer area.")
        buf = io.BytesIO()
        doc = BaseDocTemplate(buf, pagesize=L.pagesize, leftMargin=L.margin_left, rightMargin=L.margin_right,
                              topMargin=L.margin_top, bottomMargin=L.margin_bottom, title=self.quiz.title,
                              author="MasterTest Builder", subject=who)
        frame = Frame(L.margin_left, L.margin_bottom, L.frame_width, height,
                      leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        # draw the answer area once on a scratch canvas first: an error raised while ReportLab
        # draws a page loses its message, so problems (such as instructions that do not fit) show here
        draw_card(rl_canvas.Canvas(io.BytesIO(), pagesize=L.pagesize))
        doc.addPageTemplates([PageTemplate(id="quiz", frames=[frame], onPage=lambda canv, _doc: draw_card(canv))])
        try:
            doc.build(story)
        except LayoutError as exc:
            raise too_big(f"a question could not be placed ({exc}).")
        if doc.page > 1:
            raise too_big("the questions run onto a second page.")
        return buf.getvalue()

    def _build_once(self, selection, variables, footer_label):
        L = self.layout
        buf = io.BytesIO()
        info = {}
        title = self.quiz.title
        face = self.fonts.face(L.family)
        first_numbered = 2 if L.title_mode == "page" else 1
        if selection is None:
            first_numbered = 10 ** 9  # a lone title page carries no footer

        class FooterCanvas(rl_canvas.Canvas):
            def __init__(self, *a, **kw):
                super().__init__(*a, **kw)
                self._eg_pages = []

            def showPage(self):
                self._eg_pages.append(dict(self.__dict__))
                self._startPage()

            def save(self):
                pages = self._eg_pages
                info["pages"] = len(pages)
                numbered = len(pages) - (first_numbered - 1)
                for i, state in enumerate(pages, 1):
                    self.__dict__.update(state)
                    if i >= first_numbered:
                        self._footer(i - first_numbered + 1, numbered)
                    super().showPage()
                super().save()

            def _footer(self, n, total):
                y = max(L.margin_bottom * 0.5 - 3, 10)
                size = 8
                self.saveState()
                self.setFont(face, size)
                self.setFillGray(0.25)
                centre = i18n.t("page_of", n=n, total=total)
                room = (L.frame_width - stringWidth(centre, face, size)) / 2 - 12
                self.drawCentredString(L.margin_left + L.frame_width / 2, y, centre)
                self.drawString(L.margin_left, y, _fit(title, face, size, room))
                self.drawRightString(L.pagesize[0] - L.margin_right, y, _fit(footer_label, face, size, room))
                self.restoreState()

        doc = BaseDocTemplate(buf, pagesize=L.pagesize, leftMargin=L.margin_left, rightMargin=L.margin_right,
                              topMargin=L.margin_top, bottomMargin=L.margin_bottom, title=title,
                              author="MasterTest Builder", subject=footer_label)
        frame = Frame(L.margin_left, L.margin_bottom, L.frame_width, L.frame_height,
                      leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        doc.addPageTemplates([PageTemplate(id="exam", frames=[frame])])
        try:
            story = self._title_page(variables) if selection is None else self._story(selection, variables)
            doc.build(story, canvasmaker=FooterCanvas)
        except LayoutError as exc:
            raise ExamError(f"The exam could not be laid out on the page (is a table or image too large?): {exc}")
        return buf.getvalue(), info["pages"] - (first_numbered - 1)

    def build(self, selection, variables, footer_label):
        """Returns (pdf bytes, number of exam pages excluding the title page)."""
        variables = dict(variables)
        variables["QUESTION COUNT"] = len(selection)
        if not self.needs_page_count:
            variables["PAGE COUNT"] = ""
            return self._build_once(selection, variables, footer_label)
        variables["PAGE COUNT"] = "00"
        pdf, pages = self._build_once(selection, variables, footer_label)
        for _ in range(3):  # re-run until the printed page count matches reality
            variables["PAGE COUNT"] = pages
            pdf, new_pages = self._build_once(selection, variables, footer_label)
            if new_pages == pages:
                break
            pages = new_pages
        return pdf, pages


def _fit(text, face, size, room):
    if room <= 0:
        return ""
    if stringWidth(text, face, size) <= room:
        return text
    while text and stringWidth(text + "...", face, size) > room:
        text = text[:-1]
    return text.rstrip() + "..." if text else ""
