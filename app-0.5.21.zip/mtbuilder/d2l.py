"""Reads D2L Brightspace quiz exports (Course Admin > Import/Export/Copy Components > Export as a zip).

A D2L export is QTI 1.2 like a Canvas one, with D2L's own conventions:

* each quiz is a quiz_d2l_<id>.xml file (manifest type "webcontent", d2l material type "d2lquiz");
* an item's type and points are in qti_metadatafield qmd_questiontype and qmd_weighting;
* the question text and the answers sit inside presentation/flow, the options inside flow_label;
* multi-select and matching questions are scored with counters (D2L_Correct, D2L_Incorrect), and
  carry D2L's scoring method in response_extension/grading_type;
* arithmetic questions give each variable's range and a formula instead of worked examples, so
  the worked examples are made here;
* random sections ("pools") have qmd_numberofitems and may point to questions in other quiz files
  (itemref linkrefid = the item's label);
* equations are MathML, printed here as text with superscripts and subscripts.

`parse_item` returns the same Question as canvas._parse_item, so everything after reading (layout,
QR codes, marking) is shared.
"""
import ast
import math
import operator
import random
import re

from lxml import etree


D2L_NS = "http://desire2learn.com/xsd/d2lcp_v2p0"

# D2L's grading_type for multi-select questions (Question.scoring), and for matching questions
CHOICE_SCORING = {"0": "all", "1": "right_minus_wrong", "2": "correct_selections", "3": "limited"}
MATCH_SCORING = {"0": "all", "1": "equal", "2": "right_minus_wrong"}


def is_d2l(assessment):
    """Whether an <assessment> element was written by D2L."""
    return any(k.startswith("{" + D2L_NS + "}") for k in assessment.attrib) or D2L_NS in (assessment.nsmap or {}).values()


def is_d2l_item(item):
    return item.find("itemmetadata/qtimetadata/qti_metadatafield") is not None


def metadata(item):
    md = {}
    for f in item.iterfind("itemmetadata/qtimetadata/qti_metadatafield"):
        md[(f.findtext("fieldlabel") or "").strip()] = (f.findtext("fieldentry") or "").strip()
    return md


def find(el, name):
    """A D2L element (d2l_2p0:name), with its namespace or without it (canvas._parse strips them)."""
    if el is None:
        return None
    found = el.find(name)
    return found if found is not None else el.find(f"{{{D2L_NS}}}{name}")


_d2l = find


# ------------------------------------------------------------------ question text

def _material_html(canvas, mat):
    mt = mat.find("mattext") if mat is not None else None
    if mt is None:
        return ""
    html = canvas._inner(mt)
    if (mt.get("texttype") or "text/html") == "text/plain" and not len(mt):
        html = canvas._escape(html)
    return mathml(html)


def _flow_html(canvas, flow, blanks=False):
    """The question text: the flow's materials in order; with `blanks`, each answer box in the text
    (a fill-in-the-blanks question's response_str) becomes canvas.BLANK."""
    parts = []
    for child in flow:
        if child.tag == "material":
            parts.append(_material_html(canvas, child))
        elif blanks and child.tag == "response_str":
            parts.append(f" {canvas.BLANK} ")
    html = " ".join(p for p in parts if p).strip()
    # a blank between two paragraphs reads better inside the first
    return re.sub(r"</p>\s*(" + re.escape(canvas.BLANK) + r")\s*<p>", r" \1 ", html)


def _option(canvas, label, index):
    mt = label.find("flow_mat/material/mattext")
    if mt is None:
        mt = label.find("material/mattext")
    text = mathml(canvas._inner(mt))
    is_html = mt is not None and ((mt.get("texttype") or "text/plain") == "text/html" or len(mt) > 0)
    return text, is_html


def _negated(ve, stop):
    anc = ve.getparent()
    while anc is not None and anc is not stop:
        if anc.tag == "not":
            return True
        anc = anc.getparent()
    return False


def _correct_idents(item):
    """The responses that score: a condition that adds to D2L_Correct, or sets or adds a positive
    score without a counter (single-answer questions and all-or-nothing multi-select)."""
    correct = set()
    for cond in item.iterfind("resprocessing/respcondition"):
        good = False
        for sv in cond.iterfind("setvar"):
            name = sv.get("varname") or ""
            if name == "D2L_Correct":
                good = True
            elif name in ("", "SCORE"):
                try:
                    good = good or float((sv.text or "").strip()) > 0
                except ValueError:
                    pass
        cv = cond.find("conditionvar")
        if not good or cv is None:
            continue
        for ve in cv.iter("varequal"):
            if ve.text and not _negated(ve, cv):
                correct.add(ve.text.strip())
    return correct


# ------------------------------------------------------------------ the types

def parse_item(canvas, item, points_override=None, bank_title=""):
    """(Question, None), or (None, why it cannot be printed)."""
    md = metadata(item)
    dtype = md.get("qmd_questiontype", "")
    points = points_override if points_override is not None else canvas._to_float(md.get("qmd_weighting"))
    ident = item.get("ident") or ""
    title = item.get("title") or ""
    flow = item.find("presentation/flow")
    if flow is None:
        return None, "it has no question text"
    grading = (_d2l(flow.find("response_extension"), "grading_type").text or "").strip() \
        if _d2l(flow.find("response_extension"), "grading_type") is not None else ""
    Q = canvas.Question

    if dtype in ("Multiple Choice", "True/False", "Multi-Select"):
        lid = flow.find("response_lid")
        labels = list(lid.iterfind("render_choice/flow_label/response_label")) if lid is not None else []
        labels = labels or (list(lid.iterfind("render_choice/response_label")) if lid is not None else [])
        if not labels:
            return None, "it has no answer options"
        correct = _correct_idents(item)
        options = []
        for lab in labels:
            text, is_html = _option(canvas, lab, len(options))
            options.append(canvas.Option(lab.get("ident") or "", text, is_html, (lab.get("ident") or "") in correct, len(options)))
        qtype = {"Multiple Choice": "multiple_choice_question", "True/False": "true_false_question"}.get(dtype, "multiple_answers_question")
        q = Q(ident, title, qtype, points, _flow_html(canvas, flow), options, bank_title)
        if dtype == "Multi-Select":
            q.scoring = CHOICE_SCORING.get(grading, "all")
        if not any(o.correct for o in options):
            return None, "no correct answer is marked"
        return canvas.check_choice(q)

    if dtype == "Matching":
        q = Q(ident, title, "matching_question", points, _flow_html(canvas, flow), [], bank_title, kind="match")
        q.scoring = MATCH_SCORING.get(grading, "equal")
        groups = list(flow.iterfind("response_grp"))
        if not groups:
            return None, "it has no items to match"
        answer_ids = []
        for grp in groups:
            for lab in grp.iterfind("render_choice/flow_label/response_label"):
                aid = lab.get("ident") or ""
                if aid not in answer_ids:
                    answer_ids.append(aid)
                    text, is_html = _option(canvas, lab, 0)
                    q.answers.append(text if is_html else canvas._escape(text))
        right = {}
        for cond in item.iterfind("resprocessing/respcondition"):
            if not any((sv.get("varname") or "") == "D2L_Correct" for sv in cond.iterfind("setvar")):
                continue
            for ve in cond.iter("varequal"):
                if ve.get("respident") and ve.text:
                    right.setdefault(ve.get("respident"), ve.text.strip())
        for grp in groups:
            text = _material_html(canvas, grp.find("material"))
            answer = right.get(grp.get("respident") or "")
            if answer not in answer_ids:
                return None, f"item '{re.sub('<[^>]+>', '', text).strip()[:40]}' has no correct answer"
            q.prompts.append(text)
            q.matches.append(answer_ids.index(answer))
        return canvas.check_match(q)

    if dtype in ("Short Answer", "Fill in the Blanks"):
        boxes = list(flow.iterfind("response_str"))
        if len(boxes) != 1:
            return None, f"it has {len(boxes)} blanks; only fill-in-the-blank questions with one blank are supported"
        inputs = boxes[0].find("render_fib")
        if inputs is not None and (inputs.get(f"{{{D2L_NS}}}input_boxes") or "1") != "1":
            return None, "it has several answer boxes; only one is supported"
        html = _flow_html(canvas, flow, blanks=dtype == "Fill in the Blanks")
        q = Q(ident, title, "short_answer_question", points, html, [], bank_title, kind="text")
        for cond in item.iterfind("resprocessing/respcondition"):
            for ve in cond.iter("varequal"):
                text = (ve.text or "").strip()
                if text and text not in q.accepted:
                    q.accepted.append(text)
        if not q.accepted:
            return None, "it has no accepted answers"
        return q, None

    if dtype in ("Long Answer", "Written Response"):
        size = canvas.essay_size_in(title)
        return Q(ident, title, "essay_question", points, _flow_html(canvas, flow), [], bank_title,
                 kind="essay", essay_quarters=size or 1, essay_named=size is not None), None

    if dtype == "Arithmetic":
        return _arithmetic(canvas, item, flow, ident, title, points, bank_title)

    names = {"Ordering": "ordering", "Multi-Short Answer": "multi-short answer", "Significant Figures": "significant figures",
             "Likert": "Likert", "Text Information": "text information"}
    return None, f"question type '{names.get(dtype, dtype or 'unknown')}' is not supported"


# ------------------------------------------------------------------ arithmetic

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod}
_FUNCS = {"sqrt": math.sqrt, "abs": abs, "sin": math.sin, "cos": math.cos, "tan": math.tan, "asin": math.asin,
          "acos": math.acos, "atan": math.atan, "exp": math.exp, "ln": math.log, "log": math.log10,
          "round": round, "floor": math.floor, "ceil": math.ceil, "min": min, "max": max,
          "sinh": math.sinh, "cosh": math.cosh, "tanh": math.tanh}
_CONSTS = {"pi": math.pi, "e": math.e}


def _evaluate(formula, values):
    """A D2L formula ({x}+{y}^2, sqrt(...), pi ...) with the variables' values; safe: arithmetic only."""
    expr = re.sub(r"\{(\w+)\}", lambda m: f"({values[m.group(1)]!r})", formula).replace("^", "**")

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            return -ev(n.operand) if isinstance(n.op, ast.USub) else ev(n.operand)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id.lower() in _FUNCS:
            return _FUNCS[n.func.id.lower()](*[ev(a) for a in n.args])
        if isinstance(n, ast.Name) and n.id.lower() in _CONSTS:
            return _CONSTS[n.id.lower()]
        raise ValueError("unsupported")
    return ev(ast.parse(expr, mode="eval"))


def _fmt(value, places):
    text = f"{value:.{places}f}" if places > 0 else str(int(round(value)))
    return "0" if text in ("-0", "-0.0") else text


def _arithmetic(canvas, item, flow, ident, title, points, bank_title):
    """Worked examples made from the variables' ranges: up to canvas.MAX_VALUE_SETS, the same for
    every run on the same export (drawn with the question's identifier as the seed)."""
    mat = flow.find("material")
    ext = mat.find("mat_extension") if mat is not None else None
    cond = item.find("resprocessing/respcondition/respcond_extension")
    formula = (cond.findtext("formula") if cond is not None else None) or (ext.findtext("formula") if ext is not None else None)
    if ext is None or not formula:
        return None, "it has no calculated-answer data"
    variables = []
    for v in ext.iterfind("variable"):
        try:
            lo, hi = float(v.findtext("minvalue")), float(v.findtext("maxvalue"))
            places = int(v.findtext("decimalplaces") or 0)
            step = float(v.findtext("step") or 0) or 10 ** -places
        except (TypeError, ValueError):
            return None, "its variables cannot be read"
        count = int(math.floor((hi - lo) / step + 1e-9)) + 1
        if count < 1:
            return None, "its variables cannot be read"
        variables.append((v.get("name") or "", lo, step, count, places))
    precision = cond.find("precision") if cond is not None else None
    answer_places = int((precision.text or "0").strip() or 0) if precision is not None else 2
    tol = cond.find("tolerance") if cond is not None else None
    q = canvas.Question(ident, title, "calculated_question", points, _flow_html(canvas, flow), [], bank_title, kind="numeric")
    q.tolerance = ((tol.text or "0").strip() if tol is not None else "0") or "0"
    q.tolerance_percent = tol is not None and (tol.get("type") or "") == "percent"
    rng = random.Random(f"mastertest-d2l:{ident}")
    combos = math.prod(v[3] for v in variables)
    seen, too_long = set(), 0
    for _ in range(min(combos, 400)):
        if len(q.value_sets) >= canvas.MAX_VALUE_SETS:
            break
        pick = tuple(rng.randrange(v[3]) for v in variables)
        if pick in seen:
            continue
        seen.add(pick)
        shown = {name: _fmt(lo + k * step, places) for (name, lo, step, _c, places), k in zip(variables, pick)}
        try:
            answer = _evaluate(formula, {n: float(s) for n, s in shown.items()})
        except (ValueError, ZeroDivisionError, OverflowError, KeyError, SyntaxError, TypeError):
            continue
        if not math.isfinite(answer):
            continue
        text = _fmt(answer, answer_places)
        if len(text) > canvas.NUMERIC_BOXES:
            too_long += 1
            continue
        q.value_sets.append((shown, text))
    if not q.value_sets:
        return None, f"none of its answers fit in the {canvas.NUMERIC_BOXES} answer boxes" if too_long \
            else "its formula cannot be worked out"
    return q, None


# ------------------------------------------------------------------ equations (MathML)

_MATH = re.compile(r"<math\b.*?</math>", re.S)


def mathml(html):
    """Each MathML equation in `html` as text: superscripts and subscripts as <sup> and <sub>,
    fractions as (a)/(b), roots as √(…), table rows (aligned equations) on their own lines."""
    if "<math" not in html:
        return html
    return _MATH.sub(lambda m: _math_html(m.group(0)), html)


def _math_html(source):
    try:
        el = etree.fromstring(source)
    except etree.XMLSyntaxError:
        return re.sub(r"<[^>]+>", "", source)
    out = _m(el)
    return f"<br/>{out}<br/>" if el.get("display") == "block" else out


def _tag(el):
    return etree.QName(el).localname if isinstance(el.tag, str) else ""


def _esc(text):
    return (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _group(html):
    """Brackets round a part of a fraction that is more than one term."""
    plain = re.sub(r"<[^>]+>", "", html)
    return f"({html})" if len(plain.strip()) > 1 and re.search(r"[+\-−·×/ ]", plain.strip()) else html


def _m(el):
    tag = _tag(el)
    kids = [c for c in el if _tag(c) and _tag(c) != "annotation" and _tag(c) != "annotation-xml"]
    inner = lambda: "".join(_m(c) for c in kids)
    if tag in ("mi",):
        text = _esc("".join(el.itertext()))
        italic = len(text) == 1 and text.isalpha() and el.get("mathvariant") != "normal"
        return f"<i>{text}</i>" if italic else text
    if tag in ("mn", "mtext", "ms"):
        return _esc("".join(el.itertext()))
    if tag == "mo":
        op = "".join(el.itertext()).strip()
        return f" {_esc(op)} " if op in ("=", "+", "−", "-", "×", "·", "<", ">", "≤", "≥", "≠", "≈", "∈", "∋", "→", "⇒") else _esc(op)
    if tag == "semantics":
        return _m(kids[0]) if kids else ""
    if tag in ("msup", "msub", "msubsup", "munder", "mover", "munderover"):
        base = _m(kids[0]) if kids else ""
        a = _m(kids[1]) if len(kids) > 1 else ""
        b = _m(kids[2]) if len(kids) > 2 else ""
        if tag in ("msup", "mover"):
            return f"{base}<sup>{a}</sup>" if a else base
        if tag in ("msub", "munder"):
            return f"{base}<sub>{a}</sub>" if a else base
        return base + (f"<sub>{a}</sub>" if a else "") + (f"<sup>{b}</sup>" if b else "")
    if tag == "mfrac":
        num = _m(kids[0]) if kids else ""
        den = _m(kids[1]) if len(kids) > 1 else ""
        return f"{_group(num)}/{_group(den)}"
    if tag == "msqrt":
        return f"√({inner()})"
    if tag == "mroot":
        return f"<sup>{_m(kids[1]) if len(kids) > 1 else ''}</sup>√({_m(kids[0]) if kids else ''})"
    if tag == "mfenced":
        return f"{el.get('open', '(')}{', '.join(_m(c) for c in kids)}{el.get('close', ')')}"
    if tag == "mtable":
        return "<br/>".join(_m(r) for r in kids)
    if tag in ("mtr", "mlabeledtr"):
        return " ".join(_m(c) for c in kids)
    if tag == "mspace":
        return "<br/>" if el.get("linebreak") == "newline" else " "
    return inner()
