"""Reads Canvas quiz exports (QTI 1.2) from both the Classic and New Quizzes engines, and D2L
Brightspace exports (QTI 1.2 too, read with d2l.py)."""

import atexit
import html
import urllib.parse
import re
import random
import shutil
import sys
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from lxml import etree

from . import d2l, i18n, latex, progress, word
from .errors import ExamError, warn

CHOICE_TYPES = {
    "multiple_choice_question",
    "true_false_question",
    "multiple_answers_question",
}
NUMERIC_TYPES = {"calculated_question"}
MATCH_TYPES = {"matching_question"}
ORDER_TYPES = {"ordering_question"}     # printed as matching: each item's position in a digit cell
TEXT_TYPES = {"fill_in_multiple_blanks_question", "short_answer_question"}
ESSAY_TYPES = {"essay_question"}
SUPPORTED_TYPES = CHOICE_TYPES | NUMERIC_TYPES | TEXT_TYPES | MATCH_TYPES | ORDER_TYPES | ESSAY_TYPES
# IMS Common Cartridge (.imscc): its five standard question types, as their Canvas equivalents. A
# Canvas cartridge also has Canvas's own copy of each quiz (non_cc_assessments/), which is read
# instead; other systems' cartridges (Brightspace, Moodle, Blackboard) have only these.
CC_TYPES = {
    "cc.multiple_choice.v0p1": "multiple_choice_question",
    "cc.true_false.v0p1": "true_false_question",
    "cc.multiple_response.v0p1": "multiple_answers_question",
    "cc.fib.v0p1": "short_answer_question",
    "cc.pattern_match.v0p1": "short_answer_question",
    "cc.essay.v0p1": "essay_question",
}

# essay questions: the space for the answer, in quarters of a page, from "(1/2 page)" in the question's
# name (Canvas does not show question names to students); otherwise --essay-space
ESSAY_SIZES = {"1/4": 1, "1/2": 2, "3/4": 3, "1": 4}
_ESSAY_SIZE = re.compile(r"\(\s*(1/4|1/2|3/4|1)\s*page\s*\)", re.I)


def essay_size_in(title):
    """Quarters of a page named in a question name such as "Causes of the war (1/2 page)", or None."""
    m = _ESSAY_SIZE.search(title or "")
    return ESSAY_SIZES[m.group(1)] if m else None

NUMERIC_BOXES = 6        # handwritten characters for a numeric answer (digits, "-" and ".")
MAX_VALUE_SETS = 32      # worked value sets kept per calculated question (5 bits on the card)
BLANK = "__________"     # printed in place of the blank in a fill-in-the-blank question
MAX_OPTIONS = 6          # printed options (A-F)
MAX_EXPORT_OPTIONS = 8   # options in the export, counting empty ones (answer-key masks are one byte)
MAX_MATCH_ANSWERS = 99   # matching: answers are numbered 1-99 (two digit cells at most)
MAX_MATCH_PROMPTS = 26   # matching: items lettered a-z


@dataclass
class Option:
    ident: str
    text: str
    is_html: bool
    correct: bool
    export_pos: int = 0  # position of this option in the Canvas export

    @property
    def empty(self):
        return not self.text.strip()


@dataclass
class Question:
    ident: str
    title: str
    qtype: str
    points: Optional[float]
    html: str
    options: List[Option]
    bank_title: str = ""
    index: int = -1         # position in the pre-randomized (master) order
    export_index: int = -1  # position in the Canvas export
    kind: str = "choice"    # "choice" (bubbles), "numeric" (digit boxes), "text" (written box), "match" or "essay"
    # essay: the answer space in quarters of a page (1-4); named: it came from the question's name
    essay_quarters: int = 1
    essay_named: bool = False
    # numeric: worked examples from Canvas, each ({variable: value}, answer as written by Canvas)
    value_sets: List[tuple] = field(default_factory=list)
    tolerance: str = "0"            # numeric: allowed difference from the answer
    tolerance_percent: bool = False  # numeric: tolerance is a percentage of the answer
    accepted: List[str] = field(default_factory=list)  # text: every accepted answer
    # match: the items (HTML, lettered a, b, c...), the answers (HTML, numbered 1, 2, 3... in this
    # order, the pre-randomized one) and, for each item, the index of its answer in `answers`
    prompts: List[str] = field(default_factory=list)
    answers: List[str] = field(default_factory=list)
    matches: List[int] = field(default_factory=list)
    # how a multiple-answer or matching question is scored (D2L's methods; "" = the usual one):
    # multiple answers: "all" (all or nothing), "right_minus_wrong", "correct_selections", "limited";
    # matching: "equal" (a share for each item), "all", "right_minus_wrong"
    scoring: str = ""
    # ordering (kind "match"): the items are `prompts` in their correct order and the answers are the
    # positions 1, 2, 3...; each exam prints the items in its own order (printed_prompts) and the
    # student writes each one's position. `scale`: what 1 and the last position mean ("Strongest",
    # "Weakest"), when the quiz says
    ordering: bool = False
    scale: tuple = ("", "")

    def printed_prompts(self, perm):
        """match: the items in the order printed on the exam whose seed is perm[0]. A matching
        question prints them as written; an ordering question prints item order.index(k) in slot k,
        so the number printed_answers gives slot k is that item's position, and MasterTest Marker
        marks it as it marks any matching question (the answer key lists the answers 1, 2, 3...)."""
        if not self.ordering or not perm:
            return list(self.prompts)
        order = ordering_order(perm[0], len(self.prompts))
        return [self.prompts[order.index(k)] for k in range(len(self.prompts))]

    def printed_answers(self, perm):
        """match: (answers in the order printed on the exam whose seed is perm[0], printed number of
        each item's answer)."""
        from .qr_payload import match_order
        order = match_order(perm[0], len(self.answers)) if perm else list(range(len(self.answers)))
        return [self.answers[i] for i in order], [order.index(m) + 1 for m in self.matches]

    @property
    def cells(self):
        """match: digit cells per item, enough for the highest answer number."""
        return 1 if len(self.answers) <= 9 else 2

    @property
    def written(self):
        return self.kind != "choice"

    @property
    def printed_option_count(self):
        return sum(1 for o in self.options if not o.empty)


@dataclass
class Group:
    """A set of questions the export says to draw from (an item bank, a question
    group, or a single stand-alone question)."""

    label: str
    select: Optional[int]  # None = use every question
    indices: List[int] = field(default_factory=list)


@dataclass
class QuizInfo:
    number: int
    ident: str
    title: str
    path: Path


@dataclass
class Quiz:
    ident: str
    title: str
    description: str
    questions: List[Question]
    groups: List[Group]
    root: Path


# ---------------------------------------------------------------- utilities

def _parse(path):
    """Parse an XML file and strip namespaces so tags can be matched by name."""
    try:
        tree = etree.parse(str(path), etree.XMLParser(recover=True, huge_tree=True))
    except (OSError, etree.XMLSyntaxError) as exc:
        raise ExamError(f"Could not read {path}: {exc}")
    root = tree.getroot()
    if root is None:
        raise ExamError(f"{path} is not a valid XML file.")
    for el in root.iter():
        if isinstance(el.tag, str) and "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]
    return root


def open_export(path):
    """Return a folder containing the export; zip files are unpacked to a temp folder."""
    p = Path(path)
    if not p.exists():
        raise ExamError(f"Canvas export not found: {path}")
    if p.is_dir():
        return p
    if word.is_word(p):
        return word.open_document(p)
    if not zipfile.is_zipfile(p):
        raise ExamError(f"{path} is neither a folder nor a zip file.")
    tmp = Path(tempfile.mkdtemp(prefix="examgen_"))
    atexit.register(shutil.rmtree, tmp, ignore_errors=True)
    with zipfile.ZipFile(p) as zf:
        for member in zf.infolist():
            target = (tmp / member.filename).resolve()
            if not str(target).startswith(str(tmp.resolve())):
                raise ExamError(f"Unsafe path in zip file: {member.filename}")
        needed = needed_members(zf, report=True)
        for member in needed:
            zf.extract(member, tmp)
        progress.report("reading", 1, 1, cli=False)
    return tmp


QUIZ_FILES = (".xml", ".qti")


def needed_members(zf, report=False):
    """The files of an export that a quiz can use: its XML files, and the other files (pictures)
    whose names the XML mentions. A D2L export with its course files can be hundreds of megabytes
    of slides, documents and photos that no question shows; those are left in the zip."""
    members = [m for m in zf.infolist() if not m.is_dir()]
    xml = [m for m in members if m.filename.lower().endswith(QUIZ_FILES)]
    parts = []
    for k, m in enumerate(xml, 1):
        parts.append(zf.read(m).decode("utf-8", "replace"))
        if report:       # the quiz files are most of the reading (the files they name are few)
            progress.report("reading", k, len(xml) + 1, cli=False)
    text = "\n".join(parts)
    text = html.unescape(html.unescape(text)).lower()     # escaped HTML inside XML
    text += "\n" + urllib.parse.unquote(text.replace("+", " ")) + "\n" + urllib.parse.unquote(text)
    out = list(xml)
    for m in members:
        if m in xml:
            continue
        name = m.filename.replace("\\", "/").rsplit("/", 1)[-1].lower()
        if name and name in text:
            out.append(m)
    return out


def _manifest_resources(root_dir):
    """Map of resource identifier -> (type, href) from imsmanifest.xml."""
    out = {}
    mf = root_dir / "imsmanifest.xml"
    if not mf.exists():
        return out
    for res in _parse(mf).iter("resource"):
        href = res.get("href")
        if not href:
            f = res.find("file")
            href = f.get("href") if f is not None else None
        if href:
            # a D2L export marks its quizzes with its own material type (the resource type is "webcontent")
            d2l_type = res.get(f"{{{d2l.D2L_NS}}}material_type")
            out[res.get("identifier")] = (d2l_type if d2l_type == "d2lquiz" else res.get("type") or "", href.replace("\\", "/"))
    return out


def list_quizzes(root_dir):
    if word.is_word_folder(root_dir):
        return [QuizInfo(1, word.quiz_ident(root_dir), word.quiz_title(root_dir), Path(root_dir) / word.SOURCE_NAME)]
    resources = _manifest_resources(root_dir)
    paths = [root_dir / href for typ, href in resources.values() if typ.startswith("imsqti_xml") or typ == "d2lquiz"]
    if not paths:  # no manifest: look for any QTI file holding an <assessment>
        paths = sorted(p for p in root_dir.rglob("*.xml") if p.name not in ("imsmanifest.xml", "assessment_meta.xml"))
    quizzes = []
    for p in paths:
        if not p.exists():
            continue
        a = _parse(p).find("assessment")
        if a is None:
            continue
        ident = a.get("ident") or p.stem
        # a Canvas cartridge: Canvas's own copy of the quiz has every question type, and its groups'
        # item banks are next to it; the standard copy has only the standard types
        own = root_dir / "non_cc_assessments" / f"{ident}.xml.qti"
        if own.is_file() and _parse(own).find("assessment") is not None:
            p = own
        quizzes.append(QuizInfo(len(quizzes) + 1, ident, a.get("title") or p.stem, p))
    if not quizzes:
        raise ExamError("No quizzes were found in the export.")
    return quizzes


# ------------------------------------------------------------------ parsing

def _metadata(item):
    md = {}
    for f in item.iterfind("itemmetadata/qtimetadata/qtimetadatafield"):
        md[(f.findtext("fieldlabel") or "").strip()] = (f.findtext("fieldentry") or "").strip()
    return md


def _to_float(text):
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _correct_idents(item):
    """Identifiers of the correct responses, read from <resprocessing>."""
    correct = set()
    conds = list(item.iterfind("resprocessing/respcondition"))
    # Common Cartridges (Brightspace's among them) list a condition for every option, with nothing
    # set; only the ones that set a score count, when any does
    scored = any((_to_float(sv.text) or 0) > 0 for c in conds for sv in c.iterfind("setvar"))
    for cond in conds:
        score = None
        for sv in cond.iterfind("setvar"):
            score = _to_float(sv.text)
        if score is not None and score <= 0:
            continue
        if score is None and scored:
            continue
        cv = cond.find("conditionvar")
        if cv is None:
            continue
        for ve in cv.iter("varequal"):
            negated, anc = False, ve.getparent()
            while anc is not None and anc is not cv:
                negated = negated or anc.tag == "not"
                anc = anc.getparent()
            if not negated and ve.text:
                correct.add(ve.text.strip())
    return correct


def _parse_item(item, points_override=None, bank_title=""):
    """Returns (Question, None) or (None, reason-it-is-unsupported)."""
    if d2l.is_d2l_item(item):
        return d2l.parse_item(sys.modules[__name__], item, points_override, bank_title)
    md = _metadata(item)
    qtype = md.get("question_type", "")
    if not qtype and md.get("cc_profile"):       # a Common Cartridge question
        qtype = CC_TYPES.get(md["cc_profile"], md["cc_profile"])
        md.setdefault("points_possible", md.get("cc_weighting", ""))
    if qtype not in SUPPORTED_TYPES:
        return None, f"question type '{qtype or 'unknown'}' is not supported"
    if qtype in NUMERIC_TYPES or qtype in TEXT_TYPES:
        return _parse_written(item, md, qtype, points_override, bank_title)
    if qtype in MATCH_TYPES:
        return _parse_matching(item, md, qtype, points_override, bank_title)
    if qtype in ORDER_TYPES:
        return _parse_ordering(item, md, qtype, points_override, bank_title)
    if qtype in ESSAY_TYPES:
        points = points_override if points_override is not None else _to_float(md.get("points_possible"))
        title = item.get("title") or ""
        size = essay_size_in(title)
        return Question(item.get("ident") or "", title, qtype, points, _question_html(item), [], bank_title,
                        kind="essay", essay_quarters=size or 1, essay_named=size is not None), None
    pres = item.find("presentation")
    lid = pres.find("response_lid") if pres is not None else None
    labels = list(lid.iterfind("render_choice/response_label")) if lid is not None else []
    if not labels:
        return None, "it has no answer options"
    mat = pres.find("material/mattext")
    html = _inner(mat)
    if mat is not None and (mat.get("texttype") or "text/html") == "text/plain" and not len(mat):
        html = _escape(html)
    correct = _correct_idents(item)
    options = []
    for lab in labels:
        mt = lab.find("material/mattext")
        text = _inner(mt)
        is_html = mt is not None and ((mt.get("texttype") or "text/plain") == "text/html" or len(mt) > 0)
        ident = lab.get("ident") or ""
        options.append(Option(ident, text, is_html, ident in correct, len(options)))
    points = points_override if points_override is not None else _to_float(md.get("points_possible"))
    return check_choice(Question(item.get("ident") or "", item.get("title") or "", qtype, points, html, options, bank_title))


def check_choice(q):
    """A multiple-choice question that can be printed: (q, None), or (None, why not)."""
    label = q.title or q.ident or "untitled"
    if q.printed_option_count > MAX_OPTIONS:
        raise ExamError(
            f"Question '{label}' ({q.ident}) has {q.printed_option_count} options; "
            f"at most {MAX_OPTIONS} (A-F) are supported."
        )
    if q.printed_option_count == 0:
        return None, "all of its answer options are empty"
    if len(q.options) > MAX_EXPORT_OPTIONS:
        raise ExamError(
            f"Question '{label}' ({q.ident}) has {len(q.options)} options in the export (including empty "
            f"ones); at most {MAX_EXPORT_OPTIONS} are supported. Delete the empty options in Canvas."
        )
    empty = len(q.options) - q.printed_option_count
    if empty:
        warn(f"Question '{label}' ({q.ident}) has {empty} empty option(s) in the export; "
             f"{'it is' if empty == 1 else 'they are'} not printed.")
    return q, None


def _question_html(item):
    pres = item.find("presentation")
    mat = pres.find("material/mattext") if pres is not None else None
    html = _inner(mat)
    if mat is not None and (mat.get("texttype") or "text/html") == "text/plain":
        html = _escape(html)
    return html


def _number(text):
    try:
        float(text)
        return True
    except (TypeError, ValueError):
        return False


def _parse_written(item, md, qtype, points_override, bank_title):
    """Calculated (numeric) and single-blank fill-in (text) questions."""
    html = _question_html(item)
    points = points_override if points_override is not None else _to_float(md.get("points_possible"))
    q = Question(item.get("ident") or "", item.get("title") or "", qtype, points, html, [], bank_title)
    label = item.get("title") or item.get("ident") or "untitled"

    if qtype in NUMERIC_TYPES:
        q.kind = "numeric"
        calc = item.find("itemproc_extension/calculated")
        if calc is None:
            return None, "it has no calculated-answer data"
        tol_el = calc.find("answer_tolerance")
        tol = ((tol_el.text if tol_el is not None else None) or "0").strip()
        q.tolerance_percent = tol.endswith("%") or (tol_el is not None and tol_el.get("margin_type") == "percent")
        q.tolerance = tol.rstrip("%").strip() or "0"
        if not _number(q.tolerance):
            return None, f"its answer tolerance '{tol}' is not a number"
        too_long = 0
        for vs in calc.iterfind("var_sets/var_set"):
            values = {(v.get("name") or ""): (v.text or "").strip() for v in vs.iterfind("var")}
            answer = (vs.findtext("answer") or "").strip().lstrip("+")
            if not _number(answer):
                continue
            if len(answer) > NUMERIC_BOXES:
                too_long += 1
                continue
            q.value_sets.append((values, answer))
        if not q.value_sets:
            if too_long:
                return None, f"none of its answers fit in the {NUMERIC_BOXES} answer boxes"
            return None, "the export has no worked values (var_sets) for it"
        if too_long:
            warn(f"Question '{label}' ({q.ident}): {too_long} of its worked values have answers longer than "
                 f"{NUMERIC_BOXES} characters and are not used.")
        q.value_sets = q.value_sets[:MAX_VALUE_SETS]
        return q, None

    q.kind = "text"
    pres = item.find("presentation")
    if qtype == "short_answer_question":       # Classic "fill in the blank": one blank, answers in resprocessing
        for cond in item.iterfind("resprocessing/respcondition"):
            for ve in cond.iter("varequal"):
                text = (ve.text or "").strip()
                if text and text not in q.accepted:
                    q.accepted.append(text)
    else:
        lids = list(pres.iterfind("response_lid")) if pres is not None else []
        if len(lids) != 1:
            return None, f"it has {len(lids)} blanks; only fill-in-the-blank questions with one blank are supported"
        lid = lids[0]
        token = (lid.get("ident") or "")[len("response_"):]
        labels = list(lid.iterfind("render_choice/response_label"))
        correct = _correct_idents(item)
        # Typed ("open entry") answers: every listed answer is accepted. Otherwise only the scored ones.
        open_entry = any(lab.get("answer_type") == "openEntry" for lab in labels)
        for lab in labels:
            if open_entry or (lab.get("ident") or "") in correct:
                text = _plain(lab.find("material/mattext")).strip()
                if text and text not in q.accepted:
                    q.accepted.append(text)
        if not q.accepted:   # no answer marked as scored: accept them all
            q.accepted = [t for t in (_plain(lab.find("material/mattext")).strip() for lab in labels) if t]
        if token:
            q.html = q.html.replace(f"[{token}]", BLANK)
    if not q.accepted:
        return None, "it has no accepted answers"
    return q, None


def _parse_matching(item, md, qtype, points_override, bank_title):
    """Matching: each item (a response_lid) is matched with one of a shared list of answers (its
    labels, distractors included). Classic and New Quizzes export them the same way."""
    html = _question_html(item)
    points = points_override if points_override is not None else _to_float(md.get("points_possible"))
    q = Question(item.get("ident") or "", item.get("title") or "", qtype, points, html, [], bank_title, kind="match")
    pres = item.find("presentation")
    lids = list(pres.iterfind("response_lid")) if pres is not None else []
    if not lids:
        return None, "it has no items to match"
    answer_ids = []
    for lid in lids:
        for lab in lid.iterfind("render_choice/response_label"):
            ident = lab.get("ident") or ""
            if ident not in answer_ids:
                answer_ids.append(ident)
                mt = lab.find("material/mattext")
                text = _inner(mt)
                is_html = mt is not None and ((mt.get("texttype") or "text/plain") == "text/html" or len(mt) > 0)
                q.answers.append(text if is_html else _escape(text))
    right = {}
    for cond in item.iterfind("resprocessing/respcondition"):
        for ve in cond.iter("varequal"):
            if ve.get("respident") and ve.text:
                right.setdefault(ve.get("respident"), ve.text.strip())
    for lid in lids:
        mt = lid.find("material/mattext")
        text = _inner(mt)
        is_html = mt is not None and ((mt.get("texttype") or "text/plain") == "text/html" or len(mt) > 0)
        answer = right.get(lid.get("ident") or "")
        if answer not in answer_ids:
            return None, f"item '{_plain(mt).strip()[:40]}' has no correct answer"
        q.prompts.append(text if is_html else _escape(text))
        q.matches.append(answer_ids.index(answer))
    return check_match(q)


def ordering_order(seed, n):
    from .qr_payload import match_order
    return match_order(seed, n)


def ordering_shuffled(seed, n):
    """Whether an ordering question's items are printed out of order with this seed: neither in
    their correct order nor (with three or more) in reverse."""
    order = ordering_order(seed, n)
    printed = [order.index(k) for k in range(n)]
    return printed != list(range(n)) and (n < 3 or printed != list(range(n))[::-1])


def make_ordering(q, items):
    """An ordering question (kind "match") with these items, in their correct order."""
    q.kind, q.ordering = "match", True
    q.prompts = list(items)
    q.answers = [str(k + 1) for k in range(len(items))]
    q.matches = list(range(len(items)))
    if len(items) < 2:
        return None, "it has fewer than two items to order"
    return check_match(q)


def _parse_ordering(item, md, qtype, points_override, bank_title):
    """Ordering (New Quizzes): the items are the labels of a response_lid, the correct order the
    answers of the condition that scores. Canvas gives no marks for a partly right order."""
    points = points_override if points_override is not None else _to_float(md.get("points_possible"))
    q = Question(item.get("ident") or "", item.get("title") or "", qtype, points, _question_html(item), [], bank_title)
    q.scoring = "all"
    lid = item.find("presentation/response_lid")
    if lid is None:
        return None, "it has no items to order"
    texts = {}
    for lab in lid.iter("response_label"):
        mt = lab.find("material/mattext")
        text = _inner(mt)
        is_html = mt is not None and ((mt.get("texttype") or "text/plain") == "text/html" or len(mt) > 0)
        texts[lab.get("ident") or ""] = text if is_html else _escape(text)
    order = []
    for cond in item.iterfind("resprocessing/respcondition"):
        if any((_to_float(sv.text) or 0) > 0 for sv in cond.iterfind("setvar")):
            order = [ve.text.strip() for ve in cond.iter("varequal") if ve.text and ve.get("respident") == lid.get("ident")]
            break
    if sorted(order) != sorted(texts):
        return None, "its correct order is not in the export"
    ends = {m.get("position"): _plain(m.find("mattext")).strip() for m in lid.iterfind("render_extension/material")}
    q.scale = (ends.get("top", ""), ends.get("bottom", ""))
    return make_ordering(q, [texts[i] for i in order])


def check_match(q):
    """A matching question that can be printed: (q, None), or (None, why not)."""
    if len(q.answers) > MAX_MATCH_ANSWERS:
        return None, f"it has {len(q.answers)} answers; at most {MAX_MATCH_ANSWERS} are supported"
    if len(q.prompts) > MAX_MATCH_PROMPTS:
        return None, f"it has {len(q.prompts)} items; at most {MAX_MATCH_PROMPTS} are supported"
    return q, None


def _inner(el):
    """The content of a mattext (or description) element as HTML. Canvas writes the HTML as
    escaped text, so it is the element's text; other QTI tools write it as XHTML elements
    (<mattext texttype="text/html"><p>What does <strong>喝</strong> mean?</p></mattext>), or mix
    the two, and then the text before the first element is not all of it."""
    if el is None:
        return ""
    # each element as XHTML, and the text after it as it stands: a file can mix the two forms
    # (&lt;p&gt;What does <b>喝</b> mean?&lt;/p&gt;), and that text is HTML source like the rest
    inner = "".join(re.sub(r'\s+xmlns(?::\w+)?="[^"]*"', "", etree.tostring(c, encoding="unicode", with_tail=False))   # not the QTI namespace
                    + (c.tail or "") for c in el)
    return latex.equations((el.text or "") + inner)     # Canvas equation pictures as text


def _plain(el):
    """The text of an element, whatever markup it holds (for accepted answers)."""
    return "".join(el.itertext()) if el is not None else ""


def question_html(question, perm):
    """The question text as printed. For a calculated question the variables are replaced by the
    values of the worked example chosen for this exam (perm[0])."""
    html = question.html
    if question.kind == "numeric" and perm:
        for name, value in question.value_sets[perm[0]][0].items():
            if not name:
                continue
            value = i18n.number(value)                  # 2,5 with the decimal comma
            html = re.sub(r"(?<!\[)\[" + re.escape(name) + r"\](?!\])", value, html)   # Classic: [x]
            html = html.replace(f"`{name}`", value)                                     # New Quizzes: `x`
            html = html.replace("{" + name + "}", value)                                # D2L: {x}
    return html


def _escape(text):
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class _Loader:
    def __init__(self, root_dir):
        self.root_dir = root_dir
        self.resources = _manifest_resources(root_dir)
        self.banks = {}
        self.questions = []
        self.by_ident = {}
        self.groups = []
        self.d2l_files = {}

    def bank(self, ref):
        """Items of an item bank: (title, [item elements]) or None when not exported."""
        if ref in self.banks:
            return self.banks[ref]
        path = None
        if ref in self.resources:
            path = self.root_dir / self.resources[ref][1]
        if path is None or not path.exists():
            hits = sorted(self.root_dir.rglob(f"{ref}*"))
            path = hits[0] if hits else None
        result = None
        if path is not None and path.is_file():
            ob = _parse(path).find("objectbank")
            if ob is not None:
                title = ""
                for f in ob.iterfind("qtimetadata/qtimetadatafield"):
                    if (f.findtext("fieldlabel") or "").strip() == "bank_title":
                        title = (f.findtext("fieldentry") or "").strip()
                result = (title, list(ob.iterfind("item")))
        self.banks[ref] = result
        return result

    def add(self, item, points=None, bank_title=""):
        """Register a question; returns its index or None when it is omitted."""
        ident = item.get("ident") or ""
        # D2L gives the questions written straight into a random section that section's id, so
        # several share one ident; their label (QUES_...) is what tells them apart, and what other
        # quizzes' itemrefs point to
        key = (item.get("label") or ident) if d2l.is_d2l_item(item) else ident
        if key in self.by_ident:
            return self.by_ident[key]
        q, reason = _parse_item(item, points, bank_title)
        if q is None:
            name = item.get("title") or ident
            where = f" in bank '{bank_title}'" if bank_title else ""
            warn(f"Question '{name}' ({ident}){where} was omitted: {reason}.")
            self.by_ident[key] = None
            return None
        if key != ident and any(other.ident == q.ident for other in self.questions):
            q.ident = key
        q.index = len(self.questions)
        self.questions.append(q)
        self.by_ident[key] = q.index
        return q.index

    def add_group(self, label, select, indices, total):
        indices = [i for i in indices if i is not None]
        if not indices:
            return
        if select is not None and select > len(indices):
            warn(
                f"'{label}' asks for {select} question(s) but only {len(indices)} of its "
                f"{total} are usable; using {len(indices)}."
            )
            select = len(indices)
        self.groups.append(Group(label, select, indices))

    def walk(self, section):
        for child in section:
            if child.tag == "item":
                idx = self.add(child)
                self.add_group(child.get("title") or child.get("ident") or "question", None, [idx], 1)
            elif child.tag == "bankentry_item":
                ref = child.get("sourcebank_ref") or ""
                bank = self.bank(ref)
                target = None
                if bank:
                    target = next((i for i in bank[1] if i.get("ident") == child.get("item_ref")), None)
                if target is None:
                    warn(f"A question references item bank '{ref}', which is not in the export; it was omitted.")
                    continue
                idx = self.add(target, _to_float(child.get("points_possible")), bank[0])
                self.add_group(bank[0] or ref, None, [idx], 1)
            elif child.tag == "section":
                self.walk_section(child)
            elif child.tag == "itemref":          # D2L: a question kept in another quiz file of the export
                target = self.d2l_item(child)
                if target is None:
                    warn(f"A question references '{child.get('linkrefid')}', which is not in the export; it was omitted.")
                    continue
                idx = self.add(target, self.d2l_points(child))
                self.add_group(target.get("title") or target.get("ident") or "question", None, [idx], 1)

    def d2l_item(self, ref):
        """The item an itemref points to (its label is the linkrefid), in the file it names."""
        link = ref.get("linkrefid") or ""
        f = d2l.find(ref, "file")
        files = [self.root_dir / f.get("href")] if f is not None and f.get("href") else []
        for path in files + sorted(self.root_dir.glob("quiz_d2l_*.xml")):
            if not path.is_file():
                continue
            if path not in self.d2l_files:
                self.d2l_files[path] = {i.get("label"): i for i in _parse(path).iter("item")}
            if link in self.d2l_files[path]:
                return self.d2l_files[path][link]
        return None

    @staticmethod
    def d2l_points(ref):
        p = d2l.find(ref, "points")
        return _to_float(p.text) if p is not None else None

    def walk_section(self, sec):
        sel = sec.find("selection_ordering/selection")
        d2l_pick = next((f.findtext("fieldentry") for f in sec.iterfind("qtimetadata/qti_metadatafield")
                         if (f.findtext("fieldlabel") or "").strip() == "qmd_numberofitems"), None)
        if sel is None and d2l_pick is not None:     # D2L random section: N questions drawn from those in it
            label = sec.get("title") or sec.get("ident") or "pool"
            indices, total = [], 0
            for child in sec:
                if child.tag not in ("item", "itemref"):
                    continue
                target = child if child.tag == "item" else self.d2l_item(child)
                total += 1
                if target is None:
                    warn(f"A question of '{label}' is not in the export; it was omitted.")
                    continue
                indices.append(self.add(target, self.d2l_points(child) if child.tag == "itemref" else None, label))
            number = d2l_pick.strip()
            self.add_group(label, int(number) if number.isdigit() else None, indices, total)
            return
        if sel is None:
            self.walk(sec)
            return
        number = (sel.findtext("selection_number") or "").strip()
        select = int(number) if number.isdigit() else None
        points = _to_float(sel.findtext("selection_extension/points_per_item"))
        ref = (sel.findtext("sourcebank_ref") or "").strip()
        label = sec.get("title") or ref or sec.get("ident") or "group"
        items, bank_title = list(sec.iterfind("item")), ""
        if ref:
            bank = self.bank(ref)
            if bank is None:
                if not items:
                    warn(f"Item bank '{label}' ({ref}) is not included in the export; its questions were omitted.")
            else:
                bank_title = bank[0]
                items = bank[1] + items
        indices = [self.add(i, points, bank_title) for i in items]
        self.add_group(label, select, indices, len(items))


def is_brightspace_cartridge(root_dir, path):
    """A quiz from a Brightspace Common Cartridge: quiz/<id>/qti_<id>.xml in a cartridge, which keeps only
    the standard question types and loses random sections."""
    try:
        rel = Path(path).relative_to(root_dir).as_posix()
    except ValueError:
        return False
    if not re.fullmatch(r"quiz/[^/]+/qti_[^/]+\.xml", rel):
        return False
    mf = Path(root_dir) / "imsmanifest.xml"
    return mf.exists() and "IMS Common Cartridge" in (_parse(mf).findtext("metadata/schema") or "")


def load_quiz(root_dir, info, blank=BLANK):
    """`blank`: printed in place of the blank in fill-in-the-blank questions (--fill-blank-text)."""
    if word.is_word_folder(root_dir):
        return _word_quiz(root_dir, info, blank)
    qroot = _parse(info.path)
    assessment = qroot.find("assessment")
    title, description = info.title, ""
    if is_brightspace_cartridge(root_dir, info.path):
        warn("This is a Brightspace Common Cartridge (.imscc). Cartridges leave out matching, ordering and arithmetic "
             "questions, multi-select scoring methods and random sections: every question of a pool is printed for every "
             "student, and the exam's total points differ from the quiz's in Brightspace. If this quiz uses any of these, "
             "export it from Brightspace as a zip instead (Course Admin > Import/Export/Copy Components > Export Components).")
    meta = info.path.parent / "assessment_meta.xml"
    if not meta.exists():     # a Canvas cartridge: next to the standard copy, in the quiz's own folder
        meta = root_dir / info.ident / "assessment_meta.xml"
    if meta.exists():
        m = _parse(meta)
        title = (m.findtext("title") or title).strip()
        description = _inner(m.find("description"))
    loader = _Loader(root_dir)
    for sec in assessment.iterfind("section"):
        loader.walk(sec)
    if not loader.questions:
        raise ExamError(f"Quiz '{title}' contains no supported questions.")
    if blank != BLANK:
        for q in loader.questions:
            if q.kind == "text":
                q.html = q.html.replace(BLANK, _escape(blank) if blank else "")
    questions, groups = _pre_randomize(info.ident, loader.questions, loader.groups)
    return Quiz(info.ident, title, description, questions, groups, root_dir)


def _word_quiz(root_dir, info, blank):
    """A quiz from a Word document (see word.py): every question is printed, in the document's order
    before the usual pre-randomizing."""
    questions = word.load(root_dir, sys.modules[__name__])
    if not questions:
        raise ExamError(f"No questions that can be marked were found in the Word document '{info.title}'.")
    groups = []
    for i, q in enumerate(questions):
        q.index = i
        if blank != BLANK and q.kind == "text":
            q.html = q.html.replace(BLANK, _escape(blank) if blank else "")
        groups.append(Group(q.title, None, [i]))
    questions, groups = _pre_randomize(info.ident, questions, groups)
    return Quiz(info.ident, info.title, "", questions, groups, Path(root_dir))


def _pre_randomize(quiz_ident, questions, groups):
    """Put the questions, and the options inside each question, into the
    pre-randomized (master) order. Everything printed in QR codes refers to this
    order, never to the order in the export, so a pattern in how the instructor
    wrote the quiz (e.g. the first option is always correct) cannot leak.

    The shuffle is seeded from the quiz identifier only, so every run on the same
    export produces the same master order and therefore the same answer key."""
    rng = random.Random(f"mastertest-order:{quiz_ident}")
    order = list(range(len(questions)))
    rng.shuffle(order)
    new_index = {old: new for new, old in enumerate(order)}
    out = []
    for new, old in enumerate(order):
        q = questions[old]
        q.export_index, q.index = old, new
        rng.shuffle(q.options)
        if q.kind == "match" and not q.ordering:   # the answers' numbering: a pre-randomized order too
            perm = list(range(len(q.answers)))
            rng.shuffle(perm)
            q.answers = [q.answers[i] for i in perm]
            q.matches = [perm.index(m) for m in q.matches]
        out.append(q)
    for g in groups:
        g.indices = [new_index[i] for i in g.indices]
    return out, groups
