"""Glue for the in-browser version (web/): describes the command-line options so the page can
build its form from them, runs the program on files held in memory, and zips the result.

Everything here runs inside the visitor's browser (Pyodide). Input and output live in the
in-memory file system under /work, which disappears when the page is closed.
"""
import argparse
import io
import json
import os
import contextlib
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

from . import __version__, canvas, cli, errors
from .errors import ExamError

WORK = Path("/work")
INPUT = WORK / "in"
OUTPUT = WORK / "out"
# options the page handles itself or does not show
HIDDEN = {"-h", "--help", "--version", "--list-quizzes", "--output", "-o", "--password"}


def _kind(action):
    if isinstance(action, argparse.BooleanOptionalAction):
        return "bool"
    if isinstance(action, argparse._StoreTrueAction):
        return "flag"
    if action.choices:
        return "choice"
    if action.metavar and "filename" in str(action.metavar):
        return "file"
    if action.type in (int, float):
        return "number"
    return "text"


def spec():
    """The options as JSON, grouped as in --help, for building the form."""
    parser = cli.build_parser()
    exclusive = {}
    for n, group in enumerate(parser._mutually_exclusive_groups):
        for a in group._group_actions:
            exclusive[id(a)] = n
    groups = []
    for group in parser._action_groups:
        options = []
        for a in group._group_actions:
            names = a.option_strings
            if not names:          # the export, chosen separately
                continue
            name = next((s for s in names if s.startswith("--")), names[0])
            if name in HIDDEN or a.help == argparse.SUPPRESS:
                continue
            kind, choices = _kind(a), [str(c) for c in a.choices] if a.choices else None
            if name == "--page-size":   # accepts many spellings; the form offers the canonical names
                kind, choices = "choice", list(dict.fromkeys(v[0] for v in cli.PAGE_SIZES.values()))
            options.append({
                "name": name, "kind": kind, "help": (a.help or "").replace("%%", "%"),
                "default": a.default if isinstance(a.default, (str, int, float, bool)) else None,
                "choices": choices,
                "metavar": str(a.metavar) if a.metavar else None,
                "exclusive": exclusive.get(id(a)),
            })
        if options:
            groups.append({"title": group.title, "options": options})
    return json.dumps({"version": __version__, "groups": groups})


def reset():
    """Empties /work (the files of the last run) and makes it ready for the next. Also removes the
    folders exports were unpacked into (on the desktop they go when the program exits, but the
    browser's worker keeps running) and forgets which warnings were shown, so each run shows its own."""
    global _export
    _export = None
    os.chdir("/")
    shutil.rmtree(WORK, ignore_errors=True)
    for tmp in Path(tempfile.gettempdir()).glob("examgen_*"):
        shutil.rmtree(tmp, ignore_errors=True)
    errors._seen.clear()
    INPUT.mkdir(parents=True, exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    os.chdir(INPUT)


def run(argv, password=""):
    """Runs MasterTest Generator on the files in /work/in; returns the exit code. The password, if
    --password is used, is read from standard input as in a script."""
    os.chdir(INPUT)
    old_stdin = sys.stdin
    sys.stdin = io.StringIO(password + "\n")
    try:
        return cli.main(list(argv) + ["--output", str(OUTPUT)])
    except SystemExit as exc:          # argparse after --help and the like
        return exc.code if isinstance(exc.code, int) else 1
    finally:
        sys.stdin = old_stdin


def output_zip():
    """(file name, zip bytes) of everything the run wrote."""
    title = "exam_generator_output"
    manifest = OUTPUT / "manifest.json"
    if manifest.exists():
        title = cli.safe_name(json.loads(manifest.read_text(encoding="utf-8"))["quiz"]["title"], 80)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(OUTPUT.rglob("*")):
            if path.is_file():
                z.write(path, f"{title}/{path.relative_to(OUTPUT)}")
    return f"{title}.zip", buf.getvalue()


# ---------------------------------------------------------------- reading an export before a run

_export = None     # (file name, unpacked folder, [QuizInfo]) of the export last inspected


def _open(name):
    global _export
    if _export is None or _export[0] != name:
        root = canvas.open_export(INPUT / name)
        _export = (name, root, canvas.list_quizzes(root))
    return _export


def quizzes(name):
    """JSON: the quizzes in the export /work/in/<name>, or {"error": message}."""
    try:
        _name, _root, found = _open(name)
    except ExamError as exc:
        message = str(exc)
        if "neither a folder nor a zip file" in message:
            message = "This is not a .zip file. In Canvas, export the quiz as a QTI .zip file."
        elif "No quizzes were found" in message:
            message = "This .zip file holds no Canvas quiz. In Canvas, export the quiz as a QTI .zip file."
        return json.dumps({"error": message})
    except Exception as exc:  # a damaged zip and the like
        return json.dumps({"error": f"This file could not be read as a Canvas quiz export ({exc})."})
    return json.dumps({"quizzes": [{"number": q.number, "title": q.title} for q in found]})


def summary(name, number):
    """JSON: what quiz `number` of the export holds, for the page to show before Generate:
    question count and types, questions left out (with the program's warnings), the largest
    number of options, and how many questions a student gets when item banks are used."""
    stderr = io.StringIO()
    try:
        _name, root, found = _open(name)
        info = found[number - 1]
        with contextlib.redirect_stderr(stderr):
            quiz = canvas.load_quiz(root, info)
    except ExamError as exc:
        return json.dumps({"error": str(exc), "warnings": _warnings(stderr)})
    kinds = {"multiple choice": 0, "multiple answer": 0, "true/false": 0, "calculated": 0, "fill in the blank": 0}
    for q in quiz.questions:
        if q.kind == "numeric":
            kinds["calculated"] += 1
        elif q.kind == "text":
            kinds["fill in the blank"] += 1
        elif q.qtype == "true_false_question":
            kinds["true/false"] += 1
        elif q.qtype == "multiple_answers_question":
            kinds["multiple answer"] += 1
        else:
            kinds["multiple choice"] += 1
    choice = [q.printed_option_count for q in quiz.questions if q.kind == "choice"]
    drawn = [g for g in quiz.groups if g.select is not None]
    per_exam_banks = sum(len(g.indices) if g.select is None else g.select for g in quiz.groups) if drawn else None
    warnings = _warnings(stderr)
    return json.dumps({
        "title": quiz.title, "questions": len(quiz.questions),
        "kinds": {k: v for k, v in kinds.items() if v},
        "omitted": sum(1 for w in warnings if "omitted" in w),
        "warnings": warnings,
        "max_options": max(choice) if choice else 0,
        "merged_ok": all(n <= 4 for n in choice),           # two columns: A-D
        "merged1_ok": all(n <= 6 for n in choice),          # one column: A-F
        "per_exam_with_banks": per_exam_banks,
    })


def _warnings(buffer):
    return [line[len("WARNING: "):] for line in buffer.getvalue().splitlines() if line.startswith("WARNING: ")]
