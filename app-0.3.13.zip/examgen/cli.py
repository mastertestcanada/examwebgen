"""Command-line interface for MasterTest Generator."""

import argparse
import csv
import difflib
import getpass
import io
import json
import random
import re
import shlex
import sys
from pathlib import Path

import reportlab.rl_config
from pypdf import PageObject, PdfReader, PdfWriter, Transformation
from reportlab.lib.pagesizes import A4, landscape, letter

from . import __app_name__, __version__
from . import answer_card, canvas, qr_payload
from .answer_key import answer_key_pdf, key_payload
from .attendance import attendance_pdf
from .errors import ExamError, warn
from . import merged as merged_layout
from .card_instructions import CardInstructions
from .exam_pdf import CALCULATED_HINT, FILLBLANKS_HINT, LETTERS, ExamBuilder, Layout
from .fonts import FontManager
from .html_render import normalise_variable

# --page-options values: canonical name by its letters (case, hyphens and spaces are ignored)
PAGE_OPTIONS = {
    "collateanswercards": "collate-answer-cards", "padanswercards": "pad-answer-cards",
    "collateexams": "collate-exams", "titlepage": "title-page", "padtitlepage": "pad-title-page",
    "padexam": "pad-exam", "collatetitlepages": "collate-title-pages",
}
# former --pageOptions values that are now options of their own (0.3.5)
MOVED_PAGE_OPTIONS = {"padoptions": "--pad-options", "noinstructions": "--no-quiz-instructions",
                      "onecolumn": "--columns 1"}

# --page-size values by their letters: (canonical name, paper, kind)
PAGE_SIZES = {
    "letter": ("letter", "letter", "booklet"), "a4": ("a4", "a4", "booklet"),
    "lettersinglepage": ("letter-single-page", "letter", "single"), "a4singlepage": ("a4-single-page", "a4", "single"),
    "lettermerged": ("letter-merged", "letter", "merged"), "a4merged": ("a4-merged", "a4", "merged"),
    "tabloidbooklet": ("tabloid-booklet", "letter", "duplex"), "a3booklet": ("a3-booklet", "a4", "duplex"),
    "tabloidduplexlandscape": ("tabloid-booklet", "letter", "duplex"), "a3duplexlandscape": ("a3-booklet", "a4", "duplex"),
}

# Options renamed or replaced in 0.3.5 (and earlier): using one stops with this explanation.
OLD_OPTIONS = {
    "--questionBank": "--questionBank is replaced by --max-items <#>, --use-item-banks or --title-map <filename> "
                      "(leave all three out to use every question)",
    "--classlist": "--classlist is now --class-list",
    "--preferId": "--preferId is now --student-id-column",
    "--addToQR": "--addToQR is now --add-qr-field",
    "--qrQuality": "--qrQuality is now --qr-quality",
    "--blanks": "--blanks is now --blank-cards",
    "--randomizeSeats": "--randomizeSeats is now --randomize-seats (seats 1..N), or --seat-labels \"A1,A2,A3\" to "
                        "draw the seats from a list",
    "--questionSpacing": "--questionSpacing is now --question-spacing",
    "--answerCardInstructions": "--answerCardInstructions is now --answer-card-instructions",
    "--answerWidth": "--answerWidth is now --answer-width",
    "--cellShading": "--cellShading is now --cell-shading",
    "--optionFont": "--optionFont is now --option-font",
    "--optionFontSize": "--optionFontSize is now --option-font-size",
    "--optionDot": "--optionDot true/false is now --option-dot / --no-option-dot",
    "--optionColumns": "--optionColumns is now --option-columns",
    "--pageSize": "--pageSize is now --page-size (e.g. letter, a4-merged, letter-single-page, tabloid-booklet)",
    "--pageOptions": "--pageOptions is now --page-options (padOptions, noInstructions and oneColumn are now "
                     "--pad-options, --no-quiz-instructions and --columns 1)",
    "--calculatedInstructions": "--calculatedInstructions is now --calculated-instructions",
    "--fillblanksBlank": "--fillblanksBlank is now --fill-blank-text",
    "--fillblanksInstructions": "--fillblanksInstructions is now --fill-blank-instructions",
    "--attendenceSheet": "--attendenceSheet is replaced: the attendance sheet is made whenever there is a class list; "
                         "add columns with --add-attendance-field \"Section,Time in\"",
    "--attendanceSheet": "--attendanceSheet is replaced: the attendance sheet is made whenever there is a class list; "
                         "add columns with --add-attendance-field \"Section,Time in\"",
}


# ------------------------------------------------------------------ parsing


def hint_option(value, default):
    """--calculated-instructions / --fill-blank-instructions / --fill-blank-text: None (not
    given) keeps the default; "none" (any case) or an empty string means print nothing."""
    if value is None:
        return default
    value = value.strip()
    return "" if value.lower() == "none" else value


class Parser(argparse.ArgumentParser):
    """argparse with "did you mean" suggestions and our error format."""

    def error(self, message):
        m = re.search(r"unrecognized arguments: (.*)", message)
        if m:
            known = [o for a in self._actions for o in a.option_strings]
            hints = []
            for word in m.group(1).split():
                if word.startswith("--"):
                    name = word.split("=")[0]
                    close = difflib.get_close_matches(name.lower(), known, n=1, cutoff=0.6)
                    hints.append(f"unknown option {name}" + (f"; did you mean {close[0]}?" if close else ""))
            if hints:
                message = "; ".join(hints)
        raise ExamError(message + "  (see --help)")


def build_parser():
    p = Parser(
        prog="exam_generator", allow_abbrev=False,
        description="Create printable exams and machine-readable answer cards from a Canvas quiz export. "
                    "Options can also be read from a text file: exam_generator.py export.zip @options.txt",
    )
    g = p.add_argument_group("input")
    g.add_argument("export", help="Canvas quiz export (.zip file or unpacked folder)")
    g.add_argument("--list-quizzes", action="store_true", help="list the quizzes in the export and exit")
    g.add_argument("--quiz", type=int, metavar="#", help="which quiz to use when the export holds several")

    g = p.add_argument_group("question selection (default: every usable question)")
    x = g.add_mutually_exclusive_group()
    x.add_argument("--max-items", type=int, metavar="#", help="a random subset of # questions per exam")
    x.add_argument("--use-item-banks", action="store_true",
                   help="follow the export's item banks / question groups")
    x.add_argument("--title-map", metavar="<filename>",
                   help="CSV of 'question title,count': count questions are drawn from the questions with each title")
    g.add_argument("--variants", default="all", metavar="#|all",
                   help="number of randomized exam variants, or 'all' (default) for one per student")

    g = p.add_argument_group("students and answer cards")
    g.add_argument("--class-list", metavar="<filename>", help="CSV with student name, student number and optional seat")
    g.add_argument("--student-id-column", metavar="<column>",
                   help="class-list column to use as the student number (default: the first column with a "
                        "recognised student-number header)")
    g.add_argument("--add-qr-field", default="", metavar="<columns>",
                   help="comma-separated class-list columns to store in each card's QR code after the name and number")
    g.add_argument("--blank-cards", type=int, default=0, metavar="#", help="number of blank (bubble-in ID) answer cards")
    g.add_argument("--randomize-seats", action="store_true", help="assign random seats 1..N (replaces the class-list seat)")
    g.add_argument("--seat-labels", metavar="<seats>",
                   help='assign random seats drawn from this comma-separated list, e.g. "A1,A2,A3,B1,B2,B3"')
    g.add_argument("--qr-quality", default="M", type=str.upper, choices=["L", "M", "Q", "H"],
                   help="QR error-correction level: L (7%%), M (15%%, default), Q (25%%) or H (30%%)")
    g.add_argument("--password", action="store_true",
                   help="encrypt the answer-key QR code; you are asked to type a password, and the marking app "
                        "asks for it when it scans the key")

    g = p.add_argument_group("page layout and fonts (a length without a unit is in points)")
    g.add_argument("--page-size", default="letter", metavar="<size>",
                   help="letter (default) or a4; letter-single-page or a4-single-page (questions and answer area on "
                        "one page); letter-merged or a4-merged (each answer beside its question, one or more sheets); "
                        "tabloid-booklet or a3-booklet (folded booklets, two letter/A4 pages per side of a "
                        "tabloid/A3 sheet)")
    g.add_argument("--page-options", default="", metavar="<list>",
                   help="comma-separated: " + ", ".join(dict.fromkeys(PAGE_OPTIONS.values())))
    g.add_argument("--columns", type=int, choices=[1, 2], default=2,
                   help="merged page sizes: questions in 1 full-width column or 2 columns (default)")
    g.add_argument("--margin", default="0.75in", metavar="<len>", help="page margins, e.g. 0.75in (default), 2cm, 20mm, 54pt")
    for side in ("left", "right", "top", "bottom"):
        g.add_argument(f"--margin-{side}", default=None, metavar="<len>", help=f"{side} margin (overrides --margin)")
    g.add_argument("--font", default="Helvetica", metavar="<font>", help="Helvetica (default), Times, Courier, a font file or an installed font name")
    g.add_argument("--font-size", type=float, default=None, metavar="<pt>",
                   help="base font size in points (default 11; 9 for the merged page sizes)")
    g.add_argument("--question-spacing", default=None, metavar="<len>",
                   help="space between one question and the next, e.g. 12pt, 0.25in, 5mm "
                        "(default 0.9 x the font size: 9.9pt at 11pt)")
    g.add_argument("--option-font", default=None, metavar="<font>", help="font for the option letters (A, B, ...)")
    g.add_argument("--option-font-size", type=float, default=None, metavar="<pt>", help="font size for the option letters")
    g.add_argument("--option-dot", action=argparse.BooleanOptionalAction, default=True,
                   help="print a period after each option letter (default: --option-dot)")
    g.add_argument("--option-columns", type=int, default=1, metavar="#", help="lay options out in this many columns (default 1)")
    g.add_argument("--show-points", action="store_true", help="print each question's point value")
    g.add_argument("--no-quiz-instructions", action="store_true", help="do not print the quiz instructions")
    g.add_argument("--pad-options", action="store_true",
                   help="answer cards print every bubble (A-F; on merged sheets A-D, or A-F for questions with more than four options) for every question")

    g = p.add_argument_group("answer cards")
    g.add_argument("--answer-width", default=None, metavar="<len>",
                   help="width of the written-answer boxes, e.g. 1.5in or 110pt; bubbles, cells and rows scale with "
                        "it, so fewer or more questions fit. Default: 90 pt on merged sheets, about 95 pt (letter) / "
                        "91 pt (A4) on answer cards")
    g.add_argument("--cell-shading", default="15", metavar="<percent>",
                   help="darkness of the shaded cells of number, short-answer, student-number and seat boxes, "
                        "as a percentage of black (default 15); 0 or none prints outlined boxes instead")
    g.add_argument("--answer-card-instructions", default=None, metavar="<filename>",
                   help="HTML file with the instructions printed on answer cards and merged sheets (same tags and "
                        "images as question text; default: answerCardInstructions.html next to exam_generator.py); "
                        "none prints no instructions")

    g = p.add_argument_group('question text ("none" or "" prints nothing)')
    g.add_argument("--calculated-instructions", default=None, metavar="<text>",
                   help="text printed under every calculated (formula) question in place of the standard instructions")
    g.add_argument("--fill-blank-text", default=None, metavar="<text>",
                   help="what is printed in place of the blank in fill-in-the-blank questions (default __________)")
    g.add_argument("--fill-blank-instructions", default=None, metavar="<text>",
                   help="text printed under every fill-in-the-blank question in place of the standard instructions")

    g = p.add_argument_group("attendance sheet (attendance.pdf, made whenever there is a class list)")
    g.add_argument("--add-attendance-field", default=None, metavar="<fields>",
                   help="comma-separated extra columns; a column of the class list shows its value, any other name "
                        "is left blank. The seat is included when seats are randomized")
    g.add_argument("--attendance-sort", default=None, metavar="<fields>",
                   help='comma-separated columns to sort by, e.g. "Seat" or "Section,Student Name"; add " desc" '
                        'to a column to reverse it (default: class-list order)')
    g.add_argument("--attendance-orientation", default="portrait", type=str.lower,
                   choices=["portrait", "landscape"], help="portrait (default) or landscape")

    g = p.add_argument_group("output")
    g.add_argument("-o", "--output", metavar="<folder>", help="output folder (default: the exam title)")
    g.add_argument("--seed", type=int, metavar="#", help="random seed, for reproducible runs")
    g.add_argument("--version", action="version", version=f"{__app_name__} {__version__}")
    return p


def expand_option_files(argv):
    """@<file> arguments: the file's lines are read as more arguments. Each line is split like a
    command line (quotes group words); blank lines and lines starting with # are skipped."""
    out = []
    for arg in argv:
        if arg.startswith("@") and len(arg) > 1:
            path = Path(arg[1:])
            try:
                text = path.read_text(encoding="utf-8-sig")
            except OSError as exc:
                raise ExamError(f"Could not read options file '{path}': {exc}")
            for line in text.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    try:
                        out += expand_option_files(shlex.split(line, posix=True))
                    except ValueError as exc:
                        raise ExamError(f"Options file '{path}': {exc} in: {line}")
        else:
            out.append(arg)
    return out


def check_old_options(argv):
    for arg in argv:
        name = arg.split("=", 1)[0]
        if name in OLD_OPTIONS:
            raise ExamError(OLD_OPTIONS[name] + ". See --help or the README for the current option names.")


def parse_page_size(text):
    """--page-size -> (canonical name, pagesize, kind) with kind booklet / single / merged / duplex."""
    entry = PAGE_SIZES.get(_key(text))
    if entry is None:
        names = ", ".join(dict.fromkeys(v[0] for v in PAGE_SIZES.values()))
        raise ExamError(f"Unknown --page-size '{text}'. Choose from: {names}.")
    name, paper, kind = entry
    return name, letter if paper == "letter" else A4, kind


def parse_shading(text):
    """--cell-shading: a percentage of black, 0 (or off/none) for outlined boxes."""
    t = str(text).strip().lower().rstrip("%")
    if t in ("off", "none", "no", "false"):
        return 0.0
    try:
        v = float(t)
    except ValueError:
        raise ExamError(f"--cell-shading must be a percentage such as 15, or none; got '{text}'.")
    if not 0 <= v <= 40:
        raise ExamError(f"--cell-shading must be between 0 and 40 (percent); got {text}. "
                        "Darker shading hides pencil from the marking app.")
    return v / 100.0


def parse_answer_width(text, pagesize, merged, one_column=False):
    """--answer-width: whole points, or None for the default layout (also when the default is given)."""
    if text is None:
        return None
    width = round(parse_length(text, "--answer-width"))
    if merged:
        default, low = merged_layout.ANSWER_WIDTH, 60
        if one_column:   # the QR code holds the width in one byte
            high = min(255, int(pagesize[0] - 2 * merged_layout.MARGIN - merged_layout.NUMBER_WIDTH
                                - merged_layout.GUTTER_AIR - 6 - 80))
            where = "on a one-column merged sheet"
        else:
            high = int(merged_layout.column_width(pagesize[0]) - merged_layout.NUMBER_WIDTH - merged_layout.GUTTER_AIR - 6 - 80)
            where = ("on a two-column merged sheet (the question text needs at least 80 pt; "
                     "--columns 1 allows up to 255 pt)")
    else:
        default, low = answer_card.default_answer_width(pagesize), 50
        high = int(pagesize[0] - 2 * 40 - 26 - 10 - 2)
        where = "on an answer card (one column of answers at the widest)"
    if not low <= width <= high:
        raise ExamError(f"--answer-width must be between {low} and {high} pt {where}; got {width} pt.")
    return None if abs(width - default) < 0.01 else width


def parse_length(text, what, minimum_bare=None):
    """A length in points; a number without a unit is in points. `minimum_bare`: a bare number
    below it is refused as a probable inch value (margins were inches before 0.3.5)."""
    m = re.match(r"^\s*([\d.]+)\s*(in|cm|mm|pt|)\s*$", str(text).lower())
    if not m:
        raise ExamError(f"Invalid {what} '{text}'. Use a number with in, cm, mm or pt (e.g. 0.75in, 2cm).")
    try:
        n = float(m.group(1))
    except ValueError:
        raise ExamError(f"Invalid {what} '{text}'.")
    if not m.group(2) and minimum_bare is not None and n < minimum_bare:
        raise ExamError(f"{what} {text} would be {text} points; a length without a unit is in points. "
                        f"Did you mean {text}in?")
    return n * {"": 1.0, "in": 72.0, "cm": 72 / 2.54, "mm": 72 / 25.4, "pt": 1.0}[m.group(2)]


def parse_page_options(text):
    chosen = set()
    for item in split_list(text):
        key = _key(item)
        if key in MOVED_PAGE_OPTIONS:
            raise ExamError(f"Page option '{item}' is now an option of its own: {MOVED_PAGE_OPTIONS[key]}.")
        if key not in PAGE_OPTIONS:
            raise ExamError(f"Unknown page option '{item}'. Choose from: {', '.join(PAGE_OPTIONS.values())}.")
        chosen.add(PAGE_OPTIONS[key])
    return chosen


def ask_password():
    """Prompt for the answer-key password. At a terminal it is typed twice without being shown;
    when input is piped in (a script), one line is read instead."""
    if sys.stdin.isatty():
        for _ in range(3):
            first = getpass.getpass("Answer-key password: ")
            if not first:
                print("The password cannot be empty.", file=sys.stderr)
                continue
            if getpass.getpass("Type it again: ") == first:
                password = first
                break
            print("The two entries did not match.", file=sys.stderr)
        else:
            raise ExamError("No password was set.")
    else:
        password = sys.stdin.readline().rstrip("\r\n")
        if not password:
            raise ExamError("--password: no password was supplied on standard input.")
    if len(password) < 12:
        warn("The password is short. Anyone who photographs the answer-key code can try passwords on "
             "their own computer; use a long passphrase (four or more random words).")
    return password


def _read_csv(path, what):
    try:
        with open(path, newline="", encoding="utf-8-sig") as fh:
            return [row for row in csv.reader(fh)]
    except OSError as exc:
        raise ExamError(f"Could not read {what} '{path}': {exc}")
    except UnicodeDecodeError:
        with open(path, newline="", encoding="cp1252") as fh:
            return [row for row in csv.reader(fh)]


def split_list(text):
    """A comma-separated option value -> its non-empty items (double quotes protect commas inside an item)."""
    return [c.strip() for row in csv.reader([text or ""], skipinitialspace=True) for c in row if c.strip()]


def _key(text):
    return re.sub(r"[^a-z0-9]", "", text.lower())


NAME_HEADERS = ("studentname", "name", "fullname", "student")
NUMBER_HEADERS = ("studentnumber", "studentid", "studentno", "number", "id", "sisuserid", "sisid", "sisloginid")
SEAT_HEADERS = ("seat", "seatnumber", "seatno")
SERIAL_FIELD = "Card serial"   # the last QR field of a class-list card (0.3.8); a blank card's only field


def luhn_digit(digits):
    """The Luhn check digit for a string of digits (as on payment cards): catches any single
    mistyped digit and most swaps of two neighbouring digits."""
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 0:          # every second digit from the right, starting next to the check digit
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return str((10 - total % 10) % 10)


def luhn_valid(serial):
    return serial.isdigit() and len(serial) > 1 and luhn_digit(serial[:-1]) == serial[-1]


def new_serial(rng, used):
    """A 12-digit card serial: 11 random digits (the first not 0) and a Luhn check digit,
    different from every serial already in `used`."""
    while True:
        body = str(rng.randrange(10 ** 10, 10 ** 11))
        serial = body + luhn_digit(body)
        if serial not in used:
            used.add(serial)
            return serial


def show_serial(serial):
    """A serial as printed: groups of four digits."""
    return " ".join(serial[i:i + 4] for i in range(0, len(serial), 4))


def read_classlist(path, prefer_id=None, add_to_qr=()):
    """Columns are recognised by their header names (case, spaces and punctuation
    are ignored), never by position."""
    rows = [r for r in _read_csv(path, "class list") if any(c.strip() for c in r)]
    if not rows:
        raise ExamError(f"Class list '{path}' is empty.")
    header = [h.strip() for h in rows[0]]
    keys = [_key(h) for h in header]
    listing = ", ".join(h for h in header if h)

    def find(*names):
        return next((keys.index(n) for n in names if n in keys), None)

    def column(name, option):
        k = _key(name)
        if not k or k not in keys:
            raise ExamError(f"{option}: the class list has no column named '{name}'. Its columns are: {listing}.")
        return keys.index(k)

    name_i = find(*NAME_HEADERS)
    seat_i = find(*SEAT_HEADERS)
    first_i, last_i = find("firstname", "first"), find("lastname", "last", "surname")
    if name_i is None and (first_i is None or last_i is None):
        raise ExamError(f"Class list '{path}' needs a 'student name' column.")
    if prefer_id:
        num_i = column(prefer_id, "--student-id-column")
    else:  # the left-most column whose header is one of the student-number names
        num_i = next((i for i, k in enumerate(keys) if k in NUMBER_HEADERS), None)
        if num_i is None:
            raise ExamError(f"Class list '{path}' needs a 'student number' column (or name one with --student-id-column).")
    qr_cols = [column(name, "--add-qr-field") for name in add_to_qr]
    students, seen = [], set()
    for line, row in enumerate(rows[1:], 2):
        row = [c.strip() for c in row] + [""] * (len(header) - len(row))
        name = row[name_i] if name_i is not None else f"{row[first_i]} {row[last_i]}".strip()
        number = row[num_i]
        if not number:
            # e.g. the "Test Student" and "Points Possible" rows of a Canvas gradebook export
            warn(f"Class list line {line} ({name or 'no name'}) was skipped: its '{header[num_i]}' column is empty.")
            continue
        if number in seen:
            raise ExamError(f"Class list line {line}: '{header[num_i]}' value {number} appears more than once.")
        seen.add(number)
        for i in [name_i, num_i, *qr_cols]:
            if i is not None and len(row[i].encode("utf-8")) > qr_payload.MAX_FIELD_BYTES:
                warn(f"Class list line {line}: '{header[i]}' is longer than {qr_payload.MAX_FIELD_BYTES} bytes "
                     f"and is cut short in the QR code.")
        students.append({
            "name": name, "number": number, "seat": row[seat_i] if seat_i is not None else "",
            "columns": {normalise_variable(h): row[i] for i, h in enumerate(header) if h},
            # every column by its header with case, spaces and punctuation removed (attendance sheet)
            "fields": {_key(h): row[i] for i, h in enumerate(header) if _key(h)},
            # extra QR values; None = the seat column, filled in later so --randomize-seats is honoured
            "qr_extra": [None if i == seat_i else row[i] for i in qr_cols],
        })
    if not students:
        raise ExamError(f"Class list '{path}' has no students.")
    name_header = header[name_i] if name_i is not None else "Student Name"
    info = {"number_column": header[num_i],
            "qr_fields": [name_header, header[num_i]] + [header[i] for i in qr_cols] + [SERIAL_FIELD]}
    return students, [normalise_variable(h) for h in header if h], info


def assign_seats(students, option, rng):
    """--randomize-seats (True): seats 1..N; --seat-labels: the comma-separated seat labels."""
    if option is True:
        seats = [str(i) for i in range(1, len(students) + 1)]
    else:
        seats = []
        for cell in split_list(option):
            if cell not in seats:
                seats.append(cell)
        if len(seats) < len(students):
            raise ExamError(f"--seat-labels lists {len(seats)} different seat(s) but the class list has "
                            f"{len(students)} students.")
    for student, seat in zip(students, rng.sample(seats, len(students))):
        student["seat"] = seat


def _natural(value):
    """Sort key that puts 'A2' before 'A10' and empty values last."""
    parts = re.findall(r"\d+|\D+", value.strip().lower())
    return (not parts, [(0, int(p), "") if p.isdigit() else (1, 0, p) for p in parts])


def attendance_layout(students, fields, sort, seats_assigned, list_info):
    """The attendance sheet's column headers and rows (without the signature column).
    Student Name and Student Number always; the seat when --randomize-seats is used; then each
    --add-attendance-field: the class-list value when the class list has that column, else blank.
    Rows follow the class list unless --attendance-sort names columns to sort by."""
    name_keys = {"studentname", "name", "fullname"}
    number_keys = {"studentnumber", _key(list_info["number_column"] or "")}
    known = set().union(*(s["fields"] for s in students))

    def getter(label):
        k = _key(label)
        if k in name_keys:
            return lambda s: s["name"]
        if k in number_keys:
            return lambda s: s["number"]
        if k in SEAT_HEADERS:
            return lambda s: s["seat"]
        if k in known:
            return lambda s: s["fields"].get(k, "")
        return None

    columns = [("Student Name", getter("Student Name")), ("Student Number", getter("Student Number"))]
    if seats_assigned and not any(_key(f) in SEAT_HEADERS for f in fields):
        columns.append(("Seat", getter("Seat")))
    seen = {"studentname", "studentnumber"} | ({"seat"} if len(columns) == 3 else set())
    for label in fields:
        k = _key(label)
        if not k or k in seen or k in name_keys | number_keys:
            continue
        seen.add(k if k not in SEAT_HEADERS else "seat")
        columns.append((label, getter(label) or (lambda s: "")))
    keys = []
    for label in sort:
        # "Seat desc" or "-Seat": that column in reverse order
        m = re.match(r"^(-)?\s*(.*?)(?:\s+(desc|descending|asc|ascending))?$", label.strip(), re.I)
        descending = bool(m.group(1)) or (m.group(3) or "").lower().startswith("desc")
        label = m.group(2)
        g = getter(label)
        if g is None:
            shown = ", ".join(c for c, _ in columns)
            raise ExamError(f"--attendance-sort: there is no column '{label}' on the attendance sheet or in the class "
                            f"list. The sheet's columns are: {shown}.")
        keys.append((g, descending))
    ordered = list(students)
    for g, descending in reversed(keys):        # stable sorts, least important column first
        ordered.sort(key=lambda s: _natural(g(s)), reverse=descending)
        if descending:                           # empty values stay last
            ordered = [s for s in ordered if g(s).strip()] + [s for s in ordered if not g(s).strip()]
    return [c for c, _ in columns], [[g(s) for _, g in columns] for s in ordered]


# ---------------------------------------------------------------- selection

class Selector:
    """Chooses and shuffles the questions of one exam variant."""

    def __init__(self, quiz, max_items=None, item_banks=False, title_map=None):
        """At most one of --max-items, --use-item-banks and --title-map; none of them: every question."""
        self.quiz = quiz
        self.mode, self.max_items, self.title_counts = "none", None, None
        pool = len(quiz.questions)
        if max_items is not None:
            if not 1 <= max_items <= pool:
                raise ExamError(f"--max-items must be a number from 1 to {pool} (the usable questions in the export).")
            self.mode, self.max_items = "maxitems", max_items
        elif item_banks:
            self.mode = "useitembanks"
            if not quiz.has_item_banks and all(g.select is None for g in quiz.groups):
                warn("This export has no item banks or question groups; --use-item-banks uses every question.")
        elif title_map is not None:
            self.mode = "titlemap"
            self.title_counts = self._read_title_map(title_map.strip())

    def _read_title_map(self, path):
        if not path:
            raise ExamError("--title-map needs a filename.")
        by_title = {}
        for q in self.quiz.questions:
            by_title.setdefault(q.title.strip(), []).append(q.index)
        counts = {}
        rows = [r for r in _read_csv(path, "title map") if any(c.strip() for c in r)]
        for n, row in enumerate(rows):
            title = row[0].strip()
            count = row[1].strip() if len(row) > 1 else ""
            if not count.isdigit():
                if n == 0:
                    continue  # header row
                raise ExamError(f"Title map '{path}': '{title}' needs a whole number of questions, not '{count}'.")
            if title not in by_title:
                raise ExamError(f"Title map '{path}': no usable question in the export has the title '{title}'.")
            if int(count) > len(by_title[title]):
                raise ExamError(f"Title map '{path}': '{title}' asks for {count} questions but only {len(by_title[title])} exist.")
            counts[title] = (int(count), by_title[title])
        unused = sorted(t for t in by_title if t not in counts)
        if unused:
            warn("Question titles not listed in the title map are left out of the exam: " + ", ".join(repr(t) for t in unused))
        if not sum(c for c, _ in counts.values()):
            raise ExamError(f"Title map '{path}' selects no questions.")
        return counts

    def max_questions(self):
        if self.mode == "maxitems":
            return self.max_items
        if self.mode == "useitembanks":
            return sum(len(g.indices) if g.select is None else g.select for g in self.quiz.groups)
        if self.mode == "titlemap":
            return sum(c for c, _ in self.title_counts.values())
        return len(self.quiz.questions)

    def draw(self, rng):
        """Returns [(Question, option permutation)] in printed order."""
        qs = self.quiz.questions
        if self.mode == "maxitems":
            chosen = rng.sample(range(len(qs)), self.max_items)
        elif self.mode == "useitembanks":
            chosen = []
            for g in self.quiz.groups:
                avail = [i for i in g.indices if i not in chosen]
                chosen += avail if g.select is None else rng.sample(avail, min(g.select, len(avail)))
        elif self.mode == "titlemap":
            chosen = []
            for count, indices in self.title_counts.values():
                chosen += rng.sample(indices, count)
        else:
            chosen = list(range(len(qs)))
        rng.shuffle(chosen)
        selection = []
        for i in chosen:
            q = qs[i]
            if q.kind == "numeric":         # which worked example (value set) this exam prints
                selection.append((q, [rng.randrange(len(q.value_sets))]))
                continue
            if q.kind == "text":
                selection.append((q, []))
                continue
            # perm[i] = pre-randomized position of the option printed in slot i
            perm = list(range(len(q.options)))
            if q.qtype == "true_false_question":  # always printed as written: True, then False
                perm.sort(key=lambda i: q.options[i].export_pos)
            else:
                rng.shuffle(perm)
            selection.append((q, perm))
        return selection


def correct_letters(question, perm):
    """The correct answer as printed: letters for multiple choice, the number for a calculated
    question, accepted answers separated by | for fill-in-the-blank."""
    if question.kind == "numeric":
        return question.value_sets[perm[0]][1]
    if question.kind == "text":
        return "|".join(question.accepted)
    printed = [i for i in perm if not question.options[i].empty]
    return "".join(LETTERS[k] for k, i in enumerate(printed) if question.options[i].correct)


# ----------------------------------------------------------------- assembly

def safe_name(text, limit=80):
    text = re.sub(r"[^\w\-]+", "_", str(text), flags=re.UNICODE).strip("_")
    return text[:limit] or "untitled"


def _writer():
    w = PdfWriter()
    w.add_metadata({"/Producer": f"{__app_name__} {__version__}"})
    return w


DUPLEX_CARD_PAGES = 4   # one folded sheet: the hard limit is 4 x 100 questions


def impose(writer, pages, pagesize):
    """Lay portrait pages two-up on landscape sheets of twice the width, in the order that
    makes a booklet when the printed sheets are stacked and folded down the middle.

    `pages` holds the booklet pages in reading order (None = blank) and its length is a
    multiple of four. Sheet s (counting from 0) of an N-page booklet carries
        front:  page N-2s      | page 1+2s
        back:   page 2+2s      | page N-1-2s
    so a 4-page booklet is  4|1  then  2|3.  Print double-sided, flipping on the short edge."""
    width, height = pagesize
    n = len(pages)
    for s in range(n // 4):
        for left, right in ((pages[n - 1 - 2 * s], pages[2 * s]), (pages[2 * s + 1], pages[n - 2 - 2 * s])):
            sheet = PageObject.create_blank_page(width=2 * width, height=height)
            if left is not None:
                sheet.merge_page(left)
            if right is not None:
                sheet.merge_transformed_page(right, Transformation().translate(width, 0))
            writer.add_page(sheet)


def add_booklet(writer, pdf, pagesize, pad_title, pad_exam, duplex=False):
    """Append an exam booklet, inserting the blank pages asked for by padTitlePage / padExam.
    With `duplex` the booklet is imposed on folded sheets and always ends on a blank page."""
    if duplex:
        pages = list(PdfReader(io.BytesIO(pdf)).pages)
        if pad_title:
            pages.insert(1, None)
        pages.append(None)                 # the back cover is always blank
        while len(pages) % 4:
            pages.append(None)
        impose(writer, pages, pagesize)
        return
    start = len(writer.pages)
    writer.append(PdfReader(io.BytesIO(pdf)))
    if pad_title:
        writer.insert_blank_page(pagesize[0], pagesize[1], start + 1)
    if pad_exam:
        count = len(writer.pages) - start
        for _ in range(2 if count % 2 == 0 else 1):
            writer.add_blank_page(pagesize[0], pagesize[1])


def add_card(writer, pdf, pagesize, pad, duplex=False):
    """Append answer card(s); with `pad`, a blank page follows every card.
    With `duplex` the cards become one folded sheet, always four pages."""
    if duplex:
        pages = list(PdfReader(io.BytesIO(pdf)).pages)
        pages += [None] * (DUPLEX_CARD_PAGES - len(pages))
        impose(writer, pages, pagesize)
        return
    for page in PdfReader(io.BytesIO(pdf)).pages:
        writer.add_page(page)
        if pad:
            writer.add_blank_page(pagesize[0], pagesize[1])


def _save(writer, path):
    with open(path, "wb") as fh:
        writer.write(fh)


def _progress(what, done, total):
    if total >= 20 and (done % 10 == 0 or done == total):
        print(f"  {what} {done}/{total}", file=sys.stderr, flush=True)


# --------------------------------------------------------------------- main

def run(argv=None):
    argv = expand_option_files(list(sys.argv[1:] if argv is None else argv))
    check_old_options(argv)
    args = build_parser().parse_args(argv)
    reportlab.rl_config.invariant = 1  # identical input + seed -> identical PDFs

    root = canvas.open_export(args.export)
    quizzes = canvas.list_quizzes(root)
    if args.list_quizzes:
        for q in quizzes:
            print(f"{q.number}: {q.title}")
        return 0
    if args.quiz is None:
        if len(quizzes) > 1:
            listing = "\n".join(f"  {q.number}: {q.title}" for q in quizzes)
            raise ExamError(f"The export contains {len(quizzes)} quizzes; choose one with --quiz <#>:\n{listing}")
        info = quizzes[0]
    else:
        if not 1 <= args.quiz <= len(quizzes):
            raise ExamError(f"--quiz must be between 1 and {len(quizzes)} (see --list-quizzes).")
        info = quizzes[args.quiz - 1]

    # ---- validate options before doing any heavy work
    page_opts = parse_page_options(args.page_options)
    # `pagesize` is always the portrait letter/A4 page everything is laid out on; in the booklet
    # sizes two of them are placed side by side on each tabloid/A3 sheet at the very end.
    page_name, pagesize, page_kind = parse_page_size(args.page_size)
    merged = page_kind == "merged"
    single = page_kind in ("single", "merged")   # one document is both quiz and answer card
    if args.font_size is None:
        args.font_size = 9.0 if merged else 11.0
    duplex = page_kind == "duplex"
    if duplex:
        if "collate-title-pages" in page_opts:
            raise ExamError("collate-title-pages cannot be used with a booklet --page-size: "
                            "the title page is always the first page of the booklet.")
        page_opts.add("title-page")                      # always: booklet page 1 is the title page
        page_opts -= {"pad-exam", "pad-answer-cards"}    # no effect: booklets and cards are always padded
    if "pad-title-page" in page_opts and not single and not page_opts & {"title-page", "collate-title-pages"}:
        raise ExamError("pad-title-page can only be used together with title-page or collate-title-pages.")
    one_column = args.columns == 1
    if one_column and not merged:
        raise ExamError("--columns applies only to the merged page sizes (letter-merged, a4-merged).")
    if single:
        banned = sorted(page_opts & {"title-page", "pad-title-page", "collate-title-pages"})
        if banned:
            raise ExamError(f"{', '.join(banned)} cannot be used with a single-page or merged --page-size: "
                            f"the quiz and its answers start on the first page.")
    margin = parse_length(args.margin, "--margin", minimum_bare=5)
    margins = {s: (parse_length(getattr(args, f"margin_{s}"), f"--margin-{s}", minimum_bare=5) if getattr(args, f"margin_{s}") is not None else margin)
               for s in ("left", "right", "top", "bottom")}
    if margins["left"] + margins["right"] > pagesize[0] - 144 or margins["top"] + margins["bottom"] > pagesize[1] - 144:
        raise ExamError("The margins leave too little room on the page.")
    if not 4 <= args.font_size <= 72:
        raise ExamError("--font-size must be between 4 and 72 points.")
    if args.option_columns < 1:
        raise ExamError("--option-columns must be 1 or more.")
    if args.blank_cards < 0:
        raise ExamError("--blank-cards cannot be negative.")
    if not args.class_list and not args.blank_cards:
        raise ExamError("Nothing to generate: give --class-list <filename>, --blank-cards <#>, or both.")
    if args.variants.strip().lower() == "all":
        n_variants = None
    elif args.variants.strip().isdigit() and int(args.variants) >= 1:
        n_variants = int(args.variants)
    else:
        raise ExamError("--variants must be a number (1 or more) or 'all'.")

    password = ask_password() if args.password else None   # asked now, before the slow work starts

    seed = args.seed if args.seed is not None else random.SystemRandom().randrange(2 ** 32)
    rng = random.Random(seed)

    add_to_qr = split_list(args.add_qr_field)
    if (args.student_id_column or add_to_qr) and not args.class_list:
        raise ExamError("--student-id-column and --add-qr-field need a class list.")
    students, columns, list_info = (read_classlist(args.class_list, args.student_id_column, add_to_qr) if args.class_list
                                    else ([], [], {"number_column": None, "qr_fields": []}))
    seats_randomized = args.randomize_seats or args.seat_labels is not None
    if seats_randomized:
        if students:
            assign_seats(students, True if args.seat_labels is None else args.seat_labels, rng)
        else:
            warn("--randomize-seats / --seat-labels was ignored because there is no class list.")
    if (args.add_attendance_field is not None or args.attendance_sort is not None) and not students:
        raise ExamError("--add-attendance-field and --attendance-sort need a class list.")
    attendance = (attendance_layout(students, split_list(args.add_attendance_field), split_list(args.attendance_sort),
                                    seats_randomized, list_info) if students else None)

    quiz = canvas.load_quiz(root, info, blank=canvas.BLANK if args.fill_blank_text is None else hint_option(args.fill_blank_text, ""))
    if merged:
        merged_layout.check_choices(quiz.questions, 1 if one_column else 2)
    selector = Selector(quiz, max_items=args.max_items, item_banks=args.use_item_banks, title_map=args.title_map)
    answer_width = parse_answer_width(args.answer_width, pagesize, merged, one_column=one_column)
    per_card = answer_card.capacity(pagesize, None if merged else answer_width)
    if duplex and selector.max_questions() > per_card * DUPLEX_CARD_PAGES:
        raise ExamError(
            f"The exam would have {selector.max_questions()} questions; with a booklet --page-size the answer "
            f"card is one folded sheet of {DUPLEX_CARD_PAGES} pages, so the limit is {per_card * DUPLEX_CARD_PAGES}. "
            f"Use --max-items, --use-item-banks or --title-map to print fewer questions."
        )
    if selector.max_questions() > per_card * answer_card.MAX_CARDS:
        raise ExamError(
            f"The exam would have {selector.max_questions()} questions; the limit is "
            f"{per_card * answer_card.MAX_CARDS} ({answer_card.MAX_CARDS} answer cards of {per_card}). "
            f"Use --max-items, --use-item-banks or --title-map to print fewer questions."
        )
    key_data = key_payload(quiz, list_info["qr_fields"])   # the plain answer key
    key_qr = key_data                                        # what is printed
    if password is not None:
        try:
            key_qr = qr_payload.protect_key(key_data, password)
        except RuntimeError as exc:
            raise ExamError(str(exc))

    fonts = FontManager()
    family = fonts.load(args.font)
    option_family = fonts.load(args.option_font) if args.option_font else family
    layout = Layout(
        pagesize=pagesize, margin_left=margins["left"], margin_right=margins["right"],
        margin_top=margins["top"], margin_bottom=margins["bottom"], family=family, font_size=args.font_size,
        option_family=option_family, option_size=args.option_font_size or args.font_size,
        option_dot=args.option_dot, option_columns=args.option_columns,
        show_points=args.show_points,
        question_spacing=None if args.question_spacing is None else parse_length(args.question_spacing, "--question-spacing"),
        instructions=not args.no_quiz_instructions,
        title_mode="separate" if "collate-title-pages" in page_opts else "page" if "title-page" in page_opts else "inline",
        calculated_hint=hint_option(args.calculated_instructions, CALCULATED_HINT),
        fillblanks_hint=hint_option(args.fill_blank_instructions, FILLBLANKS_HINT),
    )
    builder = ExamBuilder(quiz, layout, fonts)
    shading = parse_shading(args.cell_shading)
    card_text = CardInstructions.load(args.answer_card_instructions)
    if merged:
        # the question hints default to none here: the header says how to fill in the answers
        mbuilder = merged_layout.MergedBuilder(
            builder, pagesize, spacing=layout.question_spacing,
            hints=(hint_option(args.calculated_instructions, "") if args.calculated_instructions is not None else None,
                   hint_option(args.fill_blank_instructions, "") if args.fill_blank_instructions is not None else None),
            pad_options=args.pad_options, shading=shading, columns=1 if one_column else 2,
            answer_width=answer_width, instructions=card_text)

    out_dir = Path(args.output) if args.output else Path(safe_name(quiz.title, 120))
    out_dir.mkdir(parents=True, exist_ok=True)

    # ---- people who get a card: students first, then blanks. Every card has a 12-digit serial
    # (identifying it without naming the student, e.g. to support); a blank card is filed under it.
    # The serials come from their own generator, so they do not change which questions are drawn.
    serial_rng = random.Random(f"card serials {seed}")
    used = set()
    people = [dict(s, blank=False, id=s["number"], serial=new_serial(serial_rng, used)) for s in students]
    for _ in range(args.blank_cards):
        serial = new_serial(serial_rng, used)
        people.append({"name": "", "number": "", "seat": "", "columns": {}, "blank": True, "id": serial, "serial": serial})

    def qr_fields(p):
        """Data-field values stored in the card's QR code. Their names, in the
        same order, are list_info["qr_fields"] and go in the answer key."""
        if p["blank"]:
            return [p["serial"]]  # ties the card to its booklet and to its other cards
        return [p["name"], p["number"]] + [p["seat"] if v is None else v for v in p["qr_extra"]] + [p["serial"]]

    empty_vars = {k: "" for k in ["STUDENT NAME", "STUDENT NUMBER", "SEAT NUMBER", "SEAT", *columns]}

    def person_vars(p):
        v = dict(empty_vars)
        if not p["blank"]:
            v.update(p["columns"])
            v.update({"STUDENT NAME": p["name"], "STUDENT NUMBER": p["number"], "SEAT NUMBER": p["seat"], "SEAT": p["seat"]})
        return v

    # ---- build the exam booklets
    booklets = []  # (file stem, pdf bytes, pages)
    if single:  # only decide who gets which questions; each page is built with its answer area below
        if n_variants is None:
            for n, p in enumerate(people, 1):
                p["variant"], p["selection"] = n, selector.draw(rng)
        else:
            variants = {n: selector.draw(rng) for n in range(1, n_variants + 1)}
            order = [(i % n_variants) + 1 for i in range(len(people))]
            rng.shuffle(order)
            for p, n in zip(people, order):
                p["variant"], p["selection"] = n, variants[n]
    elif n_variants is None:
        for n, p in enumerate(people, 1):
            p["variant"] = n
            p["selection"] = selector.draw(rng)
        for done, p in enumerate(people, 1):
            _progress("exam", done, len(people))
            label = f"Blank {p['id']}" if p["blank"] else f"{p['number']}  {p['name']}"
            pdf, pages = builder.build(p["selection"], dict(person_vars(p), VARIANT=p["variant"]), label)
            stem = f"{safe_name(p['id'])}_{safe_name(p['name']) if not p['blank'] else 'blank'}_exam"
            booklets.append((stem, pdf, pages))
            p["exam_file"], p["pages"] = stem + ".pdf", pages
    else:
        variants = {n: selector.draw(rng) for n in range(1, n_variants + 1)}
        order = [(i % n_variants) + 1 for i in range(len(people))]
        rng.shuffle(order)
        pages_of = {}
        for n, selection in variants.items():
            pdf, pages = builder.build(selection, dict(empty_vars, VARIANT=n), f"Variant {n}")
            booklets.append((f"variant_{n}", pdf, pages))
            pages_of[n] = pages
        for p, n in zip(people, order):
            p["variant"], p["selection"] = n, variants[n]
            p["exam_file"], p["pages"] = f"variant_{n}.pdf", pages_of[n]

    pad_title = "pad-title-page" in page_opts and layout.title_mode == "page"
    pad_exam = "pad-exam" in page_opts
    written = []
    if single:
        pass
    elif "collate-exams" in page_opts:
        w = _writer()
        for _stem, pdf, _pages in booklets:
            add_booklet(w, pdf, pagesize, pad_title, pad_exam, duplex)
        _save(w, out_dir / "exams.pdf")
        written.append("exams.pdf")
        for p in people:
            p["exam_file"] = "exams.pdf"
    else:
        for stem, pdf, _pages in booklets:
            if pad_title or pad_exam or duplex:
                w = _writer()
                add_booklet(w, pdf, pagesize, pad_title, pad_exam, duplex)
                _save(w, out_dir / f"{stem}.pdf")
            else:
                (out_dir / f"{stem}.pdf").write_bytes(pdf)
        written.append(f"{len(booklets)} exam booklet(s)")

    # ---- individual title pages in their own file
    if layout.title_mode == "separate" and not single:
        w = _writer()
        for done, p in enumerate(people, 1):
            _progress("title page", done, len(people))
            tv = dict(person_vars(p), VARIANT=p["variant"])
            tv["PAGE COUNT"], tv["QUESTION COUNT"] = p["pages"], len(p["selection"])
            w.append(PdfReader(io.BytesIO(builder.title_page(tv))))
            if "pad-title-page" in page_opts:
                w.add_blank_page(pagesize[0], pagesize[1])
        _save(w, out_dir / "title_pages.pdf")
        written.append("title_pages.pdf")

    # ---- answer cards
    pool_size = len(quiz.questions)
    collate_cards, pad_cards = "collate-answer-cards" in page_opts, "pad-answer-cards" in page_opts
    if single:  # one page is both exam and card, so the exam options mean the same as the card options
        collate_cards = collate_cards or "collate-exams" in page_opts
        pad_cards = pad_cards or "pad-exam" in page_opts
    kind, collated_name = ("quiz", "quizzes.pdf") if single else ("answer", "answer_cards.pdf")
    pad_options = args.pad_options  # always print six bubbles (A-F) per question
    card_writer = _writer() if collate_cards else None
    geo = answer_card.geometry(pagesize, answer_width=None if merged else answer_width)
    manifest_cards, key_rows, card_pdfs = [], [], []

    def card_entries(chunk):
        """(index, value, bits) per question for the card's QR code; see qr_payload.entry_field."""
        return [(q.index, *qr_payload.entry_field(q.kind, perm, len(q.value_sets))) for q, perm in chunk]

    def row_kind(q):
        """What the card shows for a question: bubble count, or a written-answer box."""
        if q.kind == "numeric":
            return answer_card.NUMERIC
        if q.kind == "text":
            return answer_card.TEXT
        return canvas.MAX_OPTIONS if pad_options else q.printed_option_count
    for p in people:
        sel = p["selection"]
        cards = []
        for k, start in enumerate(range(0, len(sel), per_card)):  # long exams spill onto further cards
            chunk = sel[start:start + per_card]
            cards.append({
                "payload": qr_payload.encode(quiz.ident, p["blank"], qr_fields(p), card_entries(chunk), pool_size,
                                             card_index=k, a4=pagesize is A4, pad_options=pad_options,
                                             shaded=shading > 0, answer_width=answer_width),
                "option_counts": [row_kind(q) for q, _ in chunk],
                "first_number": start + 1,
            })
        show_variant = p["variant"] if n_variants is not None else ""
        details = dict(blank=p["blank"], name=p["name"], number=p["number"], seat=p["seat"],
                       variant=show_variant, card_id=show_serial(p["serial"]), qr_quality=args.qr_quality)
        drawing = dict(details, shading=shading, answer_width=answer_width, instructions=card_text)
        if merged:
            _progress("quiz", len(manifest_cards) + 1, len(people))
            who = f"blank {p['id']}" if p["blank"] else f"{p['name']} ({p['number']})"

            def payload_for(sheet, first, indices, spots, p=p, sel=sel):
                return qr_payload.encode_merged(quiz.ident, p["blank"], qr_fields(p), card_entries([sel[i] for i in indices]),
                                                pool_size, sheet, first, spots, a4=pagesize is A4, pad_options=pad_options,
                                                shaded=shading > 0, answer_width=answer_width,
                                                answer_scale=merged_layout.answer_scale(answer_width) if answer_width else None,
                                                wide_pad=pad_options and any(sel[i][0].kind == "choice" and
                                                    sel[i][0].printed_option_count > merged_layout.MAX_CHOICES for i in indices))

            pdf, sheets = mbuilder.build(sel, dict(person_vars(p), VARIANT=p["variant"]), who, payload_for,
                                         quiz_title=quiz.title, **{k: v for k, v in details.items() if k != "qr_quality"},
                                         qr_quality=args.qr_quality)
            cards = [{"payload": sh["payload"]} for sh in sheets]
            page_geo = {"sheets": [sh["layout"] for sh in sheets]}
            p["pages"] = len(sheets)
        elif single:
            _progress("quiz", len(manifest_cards) + 1, len(people))
            who = f"blank {p['id']}" if p["blank"] else f"{p['name']} ({p['number']})"
            if len(cards) != 1:
                raise ExamError(f"The quiz does not fit on a single page for {who}: it has {len(sel)} questions.")
            card = cards[0]
            card["payload"] = qr_payload.encode(quiz.ident, p["blank"], qr_fields(p), card_entries(sel), pool_size,
                                                single_page=True, a4=pagesize is A4, pad_options=pad_options,
                                                shaded=shading > 0, answer_width=answer_width)
            page_geo = answer_card.geometry(pagesize, single=True, blank=p["blank"], questions=len(sel), answer_width=answer_width)

            def draw(canv, card=card, page_geo=page_geo, drawing=drawing):
                answer_card.draw_card(canv, pagesize, fonts, family, quiz.title, card["payload"],
                                      option_counts=card["option_counts"], geo=page_geo, **drawing)

            pdf = builder.build_single(sel, dict(person_vars(p), VARIANT=p["variant"]), page_geo, draw, who)
            p["pages"] = 1
        else:
            pdf = answer_card.cards_pdf(pagesize, fonts, family, quiz.title, cards, **drawing)
        stem = f"{safe_name(p['id'])}_{safe_name(p['name']) if not p['blank'] else 'blank'}_{kind}"
        card_file = collated_name if collate_cards else stem + ".pdf"
        card_pdfs.append((card_file, pdf))  # written only after every card has been built without error
        if single:
            p["exam_file"] = card_file
        keys = [correct_letters(q, perm) for q, perm in sel]
        key_rows.append([p["serial"], p["name"] or "blank", p["number"], p["variant"], p["seat"], *keys])
        manifest_cards.append({
            "id": p["id"], "serial": p["serial"], "blank": p["blank"], "qr_fields": qr_fields(p), "name": p["name"], "seat": p["seat"], "variant": p["variant"],
            "exam_file": p["exam_file"], "card_file": card_file, "exam_pages": p["pages"],
            "qr_payloads_hex": [c["payload"].hex() for c in cards],
            **({"card_layout": page_geo} if single else {}),
            "questions": [{"number": n, "index": q.index, "ident": q.ident, "kind": q.kind,
                           "option_order": perm if q.kind == "choice" else [],
                           **({"value_set": perm[0]} if q.kind == "numeric" else {}),
                           "printed_options": q.printed_option_count, "correct": k}
                          for n, ((q, perm), k) in enumerate(zip(sel, keys), 1)],
        })
    for card_file, pdf in card_pdfs:
        if collate_cards:
            add_card(card_writer, pdf, pagesize, pad_cards, duplex)
        elif pad_cards or duplex:
            w = _writer()
            add_card(w, pdf, pagesize, pad_cards, duplex)
            _save(w, out_dir / card_file)
        else:
            (out_dir / card_file).write_bytes(pdf)
    if collate_cards:
        _save(card_writer, out_dir / collated_name)
        written.append(collated_name)
    else:
        written.append(f"{len(people)} {'single-page quiz' if single else 'answer card'} file(s)")

    # ---- answer key: one page, one QR code
    (out_dir / "answer_key.pdf").write_bytes(answer_key_pdf(pagesize, fonts, family, quiz, key_qr, args.qr_quality, protected=key_qr is not key_data))
    written.append("answer_key.pdf")

    # ---- attendance sheet
    if attendance is not None:
        headers, rows = attendance
        sheet = landscape(pagesize) if args.attendance_orientation == "landscape" else pagesize
        (out_dir / "attendance.pdf").write_bytes(attendance_pdf(sheet, fonts, family, quiz.title, headers, rows))
        written.append("attendance.pdf")

    # ---- answer key + manifest (for marking)
    most = max(len(r) for r in key_rows) - 5
    with open(out_dir / "answer_key.csv", "w", newline="", encoding="utf-8-sig") as fh:
        wr = csv.writer(fh)
        wr.writerow(["card serial", "name", "student number", "variant", "seat"] + [f"Q{i}" for i in range(1, most + 1)])
        wr.writerows(key_rows)
    manifest = {
        "generator": f"{__app_name__} {__version__}", "seed": seed,
        "quiz": {"ident": quiz.ident, "title": quiz.title, "hash": f"{qr_payload.quiz_hash(quiz.ident):08x}",
                 "question_index_bits": qr_payload.index_bits(pool_size)},
        "options": {"max-items": args.max_items, "use-item-banks": args.use_item_banks,
                    "title-map": args.title_map, "variants": args.variants, "page-size": page_name,
                    "page-options": sorted(page_opts), "columns": args.columns if merged else None,
                    "pad-options": args.pad_options, "qr-quality": args.qr_quality,
                    "cell-shading": round(shading * 100, 1), "answer-width": answer_width},
        "student_number_column": list_info["number_column"],
        "qr_fields": list_info["qr_fields"],
        "answer_key_payload_hex": key_data.hex(),          # plain (schema 0x03 or 0x06), for checking
        "answer_key_qr_hex": key_qr.hex(),                 # as printed (schema 0x05 when password protected)
        "answer_key_protected": key_qr is not key_data,
        "questions": [{"index": q.index, "export_index": q.export_index, "ident": q.ident, "title": q.title,
                                "type": q.qtype, "kind": q.kind, "points": q.points, "options": len(q.options),
                                **({"answers": [a for _v, a in q.value_sets], "tolerance": q.tolerance,
                                    "tolerance_percent": q.tolerance_percent} if q.kind == "numeric" else {}),
                                **({"accepted": q.accepted} if q.kind == "text" else {}),
                                "empty_options": [i for i, o in enumerate(q.options) if o.empty],
                                "correct_options": [i for i, o in enumerate(q.options) if o.correct]}
                               for q in quiz.questions],
        "card_layout": None if single else geo,  # single-page layouts differ per card: see cards[].card_layout
        "cards": manifest_cards,
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    written += ["answer_key.csv", "manifest.json"]

    n_q = sorted({len(p["selection"]) for p in people})
    print(f"{__app_name__} {__version__}")
    print(f"Quiz:      {quiz.title}")
    print(f"Questions: {'-'.join(map(str, (n_q[0], n_q[-1]))) if len(n_q) > 1 else n_q[0]} per exam (from {pool_size} usable in the export)")
    print(f"Cards:     {len(students)} student(s), {args.blank_cards} blank(s)")
    print(f"Seed:      {seed}")
    print(f"Output:    {out_dir}  ({', '.join(written)})")
    return 0


def main(argv=None):
    try:
        return run(argv)
    except ExamError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
