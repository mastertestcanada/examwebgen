"""Command-line interface for MasterTest Builder: one build, from the options to the files.

`run` goes through the stages in order; each reads what the earlier ones left on the `Job` and adds
its own results to it:

    options      the command line, checked before any slow work         (options.py)
    class list   students, seats and the attendance sheet's rows        (classlist.py)
    quiz         the questions, and which of them each exam gets        (selection.py)
    layout       fonts and the page layout
    booklets     the exam booklets and title pages                       (assembly.py)
    cards        answer cards, single-page quizzes or merged sheets, with their QR codes
    key          the answer key (PDF and CSV), attendance sheet and manifest.json
"""

import csv
import io
import json
import random
import re
import sys
from pathlib import Path

import reportlab.rl_config
from pypdf import PdfReader
from reportlab.lib.pagesizes import A4, landscape

from . import __app_name__, __version__
from . import answer_card, canvas, qr_payload, word
from . import i18n, messages
from . import merged as merged_layout
from .answer_key import answer_key_pdf, key_payload
from .assembly import DUPLEX_CARD_PAGES, add_booklet, add_card, new_writer, parallel_map, progress, safe_name, save
from .attendance import attendance_pdf
from .card_instructions import CardInstructions
from .classlist import assign_seats, attendance_layout, new_serial, read_classlist, show_serial, split_list
from .errors import ExamError, warn
from .exam_pdf import ExamBuilder, Layout
from .fonts import FontManager, detect_cjk
from .i18n import t
from .options import (ONE_COLUMN_ANSWER_WIDTH, ask_password, build_parser, expand_option_files, hint_option,
                      parse_answer_width, parse_length, parse_page_options, parse_page_size, parse_shading)
from .selection import Selector, correct_letters


class Job:
    """Everything one build has worked out so far."""

    def __init__(self, **values):
        self.__dict__.update(values)

    def update(self, **values):
        self.__dict__.update(values)


# ------------------------------------------------------------------ options

def parse(argv):
    argv = list(sys.argv[1:] if argv is None else argv)
    # the messages' language first, so that even a mistake in the options is explained in it
    messages.set_language(messages.default_language())
    for i, a in enumerate(argv):
        if a == "--messages-language" and i + 1 < len(argv):
            messages.set_language(argv[i + 1].lower())
        elif a.startswith("--messages-language="):
            messages.set_language(a.split("=", 1)[1].lower())
    args = build_parser().parse_args(expand_option_files(argv))
    i18n.set_language(args.print_language, args.decimal_mark)
    reportlab.rl_config.invariant = 1  # identical input + seed -> identical PDFs
    return args


def list_fonts():
    from .fonts import bundled_fonts, installed_families
    print(messages.translate("Built into every PDF reader: Helvetica, Times, Courier"))
    print(messages.translate("Supplied with MasterTest Builder: " + ", ".join(sorted(bundled_fonts(), key=str.lower))))
    installed = installed_families()
    print(messages.translate(f"Installed on this computer ({len(installed)}):"))
    for name in installed:
        print("  " + name)
    print(messages.translate("Or give the path of a .ttf, .otf or .ttc file."))


def choose_quiz(args):
    """(export folder, the chosen quiz's entry); None after --list-quizzes."""
    if not args.export:
        raise ExamError("Give the Canvas or D2L quiz export (.zip file or unpacked folder) or Word document (.docx) to build from.")
    root = canvas.open_export(args.export)
    quizzes = canvas.list_quizzes(root)
    if args.list_quizzes:
        for q in quizzes:
            print(f"{q.number}: {q.title}")
        return None
    if args.quiz is None:
        if len(quizzes) > 1:
            listing = "\n".join(f"  {q.number}: {q.title}" for q in quizzes)
            raise ExamError(f"The export contains {len(quizzes)} quizzes; choose one with --quiz <#>:\n{listing}")
        return root, quizzes[0]
    if not 1 <= args.quiz <= len(quizzes):
        raise ExamError(f"--quiz must be between 1 and {len(quizzes)} (see --list-quizzes).")
    return root, quizzes[args.quiz - 1]


def check_page_settings(job):
    """The page size and options, checked together before any heavy work."""
    args = job.args
    page_opts = parse_page_options(args.page_options)
    # `pagesize` is always the portrait letter/A4 page everything is laid out on; in the booklet
    # sizes two of them are placed side by side on each tabloid/A3 sheet at the very end.
    page_name, pagesize, page_kind = parse_page_size(args.page_size)
    merged = page_kind == "merged"
    single = page_kind in ("single", "merged")   # one document is both quiz and answer card
    if args.font_size is None:
        args.font_size = 9.0 if merged else 11.0
    duplex = page_kind == "duplex"
    if duplex:
        if "collate-title-pages" in page_opts:
            raise ExamError("collate-title-pages cannot be used with a booklet --page-size: "
                            "the title page is always the first page of the booklet.")
        page_opts.add("title-page")                      # always: booklet page 1 is the title page
        page_opts -= {"pad-exam", "pad-answer-cards"}    # no effect: booklets and cards are always padded
    if "pad-title-page" in page_opts and (merged or not single) and not page_opts & {"title-page", "collate-title-pages"}:
        raise ExamError("pad-title-page can only be used together with title-page or collate-title-pages.")
    one_column = args.columns == 1
    if one_column and not merged:
        raise ExamError("--columns applies only to the merged page sizes (letter-merged, a4-merged).")
    if single and not merged:
        banned = sorted(page_opts & {"title-page", "pad-title-page", "collate-title-pages"})
        if banned:
            raise ExamError(f"{', '.join(banned)} cannot be used with a single-page --page-size: "
                            f"the quiz and its answers start on the first page.")
    if merged and "collate-title-pages" in page_opts:
        raise ExamError("collate-title-pages cannot be used with a merged --page-size: use title-page, "
                        "which puts the title page before each student's first sheet.")
    margin = parse_length(args.margin, "--margin", minimum_bare=5)
    margins = {s: (parse_length(getattr(args, f"margin_{s}"), f"--margin-{s}", minimum_bare=5) if getattr(args, f"margin_{s}") is not None else margin)
               for s in ("left", "right", "top", "bottom")}
    if margins["left"] + margins["right"] > pagesize[0] - 144 or margins["top"] + margins["bottom"] > pagesize[1] - 144:
        raise ExamError("The margins leave too little room on the page.")
    if not 4 <= args.font_size <= 72:
        raise ExamError("--font-size must be between 4 and 72 points.")
    if args.option_columns < 1:
        raise ExamError("--option-columns must be 1 or more.")
    if args.blank_cards < 0:
        raise ExamError("--blank-cards cannot be negative.")
    if not args.class_list and not args.blank_cards:
        raise ExamError("Nothing to generate: give --class-list <filename>, --blank-cards <#>, or both.")
    if args.variants.strip().lower() == "all":
        n_variants = None
    elif args.variants.strip().isdigit() and int(args.variants) >= 1:
        n_variants = int(args.variants)
    else:
        raise ExamError("--variants must be a number (1 or more) or 'all'.")
    # with a single page, one page is both exam and card, so the exam options mean the same as the card options
    collate_cards = "collate-answer-cards" in page_opts or (single and "collate-exams" in page_opts)
    pad_cards = "pad-answer-cards" in page_opts or (single and "pad-exam" in page_opts)
    job.update(page_opts=page_opts, page_name=page_name, pagesize=pagesize, merged=merged, single=single, duplex=duplex,
               one_column=one_column, rules=(args.question_rules == "on") if args.question_rules else (merged and one_column),
               margins=margins, n_variants=n_variants, collate_cards=collate_cards, pad_cards=pad_cards)


# ------------------------------------------------------------------ class list

def read_class_list(job):
    args = job.args
    add_to_qr = split_list(args.add_qr_field)
    if (args.student_id_column or add_to_qr) and not args.class_list:
        raise ExamError("--student-id-column and --add-qr-field need a class list.")
    students, columns, list_info = (read_classlist(args.class_list, args.student_id_column, add_to_qr) if args.class_list
                                    else ([], [], {"number_column": None, "qr_fields": []}))
    seats_randomized = args.randomize_seats or args.seat_labels is not None
    if seats_randomized:
        if students:
            assign_seats(students, True if args.seat_labels is None else args.seat_labels, job.rng)
        else:
            warn("--randomize-seats / --seat-labels was ignored because there is no class list.")
    if (args.add_attendance_field is not None or args.attendance_sort is not None) and not students:
        raise ExamError("--add-attendance-field and --attendance-sort need a class list.")
    attendance = (attendance_layout(students, split_list(args.add_attendance_field), split_list(args.attendance_sort),
                                    seats_randomized, list_info) if students else None)
    job.update(students=students, columns=columns, list_info=list_info, attendance=attendance)


def make_people(job):
    """Who gets a card: students first, then blanks. Every card has a 12-digit serial (identifying it
    without naming the student, e.g. to support); a blank card is filed under it. The serials come
    from their own generator, so they do not change which questions are drawn."""
    serial_rng = random.Random(f"card serials {job.seed}")
    used = set()
    people = [dict(s, blank=False, id=s["number"], serial=new_serial(serial_rng, used)) for s in job.students]
    for _ in range(job.args.blank_cards):
        serial = new_serial(serial_rng, used)
        people.append({"name": "", "number": "", "seat": "", "columns": {}, "blank": True, "id": serial, "serial": serial})
    job.people = people
    job.empty_vars = {k: "" for k in ["STUDENT NAME", "STUDENT NUMBER", "SEAT NUMBER", "SEAT", *job.columns]}


def qr_fields(p):
    """Data-field values stored in the card's QR code. Their names, in the same order, are
    list_info["qr_fields"] and go in the answer key."""
    if p["blank"]:
        return [p["serial"]]  # ties the card to its booklet and to its other cards
    return [p["name"], p["number"]] + [p["seat"] if v is None else v for v in p["qr_extra"]] + [p["serial"]]


def person_vars(job, p):
    """The values of the [[...]] variables in the instructions for one person."""
    v = dict(job.empty_vars)
    if not p["blank"]:
        v.update(p["columns"])
        v.update({"STUDENT NAME": p["name"], "STUDENT NUMBER": p["number"], "SEAT NUMBER": p["seat"], "SEAT": p["seat"]})
    return v


# ------------------------------------------------------------------ quiz

def load_quiz(job):
    args, merged, single = job.args, job.merged, job.single
    quiz = canvas.load_quiz(job.root, job.info, blank=canvas.BLANK if args.fill_blank_text is None else hint_option(args.fill_blank_text, ""))
    if args.title is not None:
        # only the printed name changes: the quiz hash (from its identifier) and so the answer key stay the same
        if not args.title.strip():
            raise ExamError("--title cannot be empty.")
        quiz.title = " ".join(args.title.split())
    if merged:
        merged_layout.check_choices(quiz.questions, 1 if job.one_column else 2)
    # essay questions: their answer space, from the question's name ("(1/2 page)") or --essay-space
    essays = [q for q in quiz.questions if q.kind == "essay"]
    for q in essays:
        if args.essay_space_all or not q.essay_named:
            q.essay_quarters = canvas.ESSAY_SIZES[args.essay_space]
    if essays and single and not merged:
        warn(f"Essay questions are not printed on single-page quizzes: {len(essays)} left out. Use a booklet or "
             f"merged --page-size to print them, with the space for the answers at the end of the answer card.")
    # padding (the default from 0.4.3): every multiple-choice question gets as many bubbles as the
    # question of the quiz with the most printed options; the marking app works the number out from the key
    choice_counts = [q.printed_option_count for q in quiz.questions if q.kind == "choice"]
    pad_to = None if args.no_option_pad or not choice_counts else max(choice_counts)
    if args.ignore_item_banks and not any(g.select is not None and g.select < len(g.indices) for g in quiz.groups):
        warn("This quiz has no item banks or question groups that pick fewer than all their questions; "
             "--ignore-item-banks changes nothing.")
    selector = Selector(quiz, max_items=args.max_items, item_banks=not args.ignore_item_banks, title_map=args.title_map,
                        essays=not (single and not merged))
    job.update(quiz=quiz, pad_to=pad_to, selector=selector)


def check_answer_width(job):
    """The answer width, and a check that the longest exam fits on the cards there can be."""
    args, selector = job.args, job.selector
    job.width_defaulted = args.answer_width is None
    if job.merged and job.one_column and args.answer_width is None:
        args.answer_width = f"{ONE_COLUMN_ANSWER_WIDTH}pt"   # one column has room for wider written answers (0.3.17)
    job.answer_width = parse_answer_width(args.answer_width, job.pagesize, job.merged, one_column=job.one_column)
    per_card = job.per_card = answer_card.capacity(job.pagesize, None if job.merged else job.answer_width)
    if job.duplex and selector.max_questions() > per_card * DUPLEX_CARD_PAGES:
        raise ExamError(
            f"The exam would have {selector.max_questions()} questions; with a booklet --page-size the answer "
            f"card is one folded sheet of {DUPLEX_CARD_PAGES} pages, so the limit is {per_card * DUPLEX_CARD_PAGES}. "
            f"Use --max-items or --title-map to print fewer questions."
        )
    if selector.max_questions() > per_card * answer_card.MAX_CARDS:
        raise ExamError(
            f"The exam would have {selector.max_questions()} questions; the limit is "
            f"{per_card * answer_card.MAX_CARDS} ({answer_card.MAX_CARDS} answer cards of {per_card}). "
            f"Use --max-items or --title-map to print fewer questions."
        )


def make_answer_key(job, password):
    job.key_data = key_payload(job.quiz, job.list_info["qr_fields"])   # the plain answer key
    job.key_qr = job.key_data if password is None else qr_payload.protect_key(job.key_data, password)   # as printed


# ------------------------------------------------------------------ layout

def set_up_layout(job):
    args, quiz, page_opts, margins = job.args, job.quiz, job.page_opts, job.margins
    fonts = FontManager()
    quiz_text = " ".join([quiz.title, quiz.description] + [q.html for q in quiz.questions] +
                         [o.text for q in quiz.questions for o in q.options])
    job.cjk_found = detect_cjk(quiz_text)
    job.cjk_region = job.cjk_found if args.cjk_region == "auto" else args.cjk_region
    fonts.set_cjk(job.cjk_region, args.cjk_font)
    family = fonts.load(args.font)
    same = not args.option_font or args.option_font.strip().lower() == "same"
    option_family = family if same else fonts.load(args.option_font, quiet=True)
    layout = Layout(
        pagesize=job.pagesize, margin_left=margins["left"], margin_right=margins["right"],
        margin_top=margins["top"], margin_bottom=margins["bottom"], family=family, font_size=args.font_size,
        option_family=option_family, option_size=args.option_font_size or args.font_size,
        option_dot=args.option_dot, option_letters=args.option_letters, option_columns=args.option_columns,
        show_points=args.show_points,
        question_rules=job.rules,
        question_spacing=None if args.question_spacing is None else parse_length(args.question_spacing, "--question-spacing"),
        option_spacing=None if args.option_spacing is None else parse_length(args.option_spacing, "--option-spacing"),
        instructions=not args.no_quiz_instructions,
        title_mode="separate" if "collate-title-pages" in page_opts else "page" if "title-page" in page_opts else "inline",
        calculated_hint=hint_option(args.calculated_instructions, t("calc_hint")),
        fillblanks_hint=hint_option(args.fill_blank_instructions, t("fill_hint")),
        multiple_hint=hint_option(args.multiple_answer_instructions, None),
    )
    job.update(fonts=fonts, family=family, layout=layout, builder=ExamBuilder(quiz, layout, fonts),
               shading=parse_shading(args.cell_shading), card_text=CardInstructions.load(args.answer_card_instructions),
               mbuilder=None, geo=answer_card.geometry(job.pagesize, answer_width=None if job.merged else job.answer_width))
    if job.merged:
        # the question hints default to none here: the header says how to fill in the answers
        job.mbuilder = merged_layout.MergedBuilder(
            job.builder, job.pagesize, spacing=layout.question_spacing,
            hints=(hint_option(args.calculated_instructions, "") if args.calculated_instructions is not None else None,
                   hint_option(args.fill_blank_instructions, "") if args.fill_blank_instructions is not None else None),
            pad_options=job.pad_to, shading=job.shading, columns=1 if job.one_column else 2,
            answer_width=job.answer_width, instructions=job.card_text,
            title_page="title-page" in page_opts, pad_title_page="pad-title-page" in page_opts, rules=job.rules)


# ------------------------------------------------------------------ booklets

def make_booklets(job):
    """Draws each person's questions; for booklet page sizes, builds the booklets (one per person,
    or one per variant). Returns [(file stem, pdf bytes, pages)]."""
    rng, selector, builder, n_variants, people = job.rng, job.selector, job.builder, job.n_variants, job.people
    booklets = []
    if job.single:  # only decide who gets which questions; each page is built with its answer area below
        if n_variants is None:
            for n, p in enumerate(people, 1):
                p["variant"], p["selection"] = n, selector.draw(rng)
        else:
            variants = {n: selector.draw(rng) for n in range(1, n_variants + 1)}
            order = [(i % n_variants) + 1 for i in range(len(people))]
            rng.shuffle(order)
            for p, n in zip(people, order):
                p["variant"], p["selection"] = n, variants[n]
    elif n_variants is None:
        for n, p in enumerate(people, 1):
            p["variant"] = n
            p["selection"] = selector.draw(rng)

        def one_booklet(p):
            label = t("blank_label", id=p["id"]) if p["blank"] else f"{p['number']}  {p['name']}"
            return builder.build(p["selection"], dict(person_vars(job, p), VARIANT=p["variant"]), label)

        for done, (p, (pdf, pages)) in enumerate(zip(people, parallel_map(one_booklet, people)), 1):
            progress("exam", done, len(people))
            stem = f"{safe_name(p['id'])}_{safe_name(p['name']) if not p['blank'] else 'blank'}_exam"
            booklets.append((stem, pdf, pages))
            p["exam_file"], p["pages"] = stem + ".pdf", pages
    else:
        variants = {n: selector.draw(rng) for n in range(1, n_variants + 1)}
        order = [(i % n_variants) + 1 for i in range(len(people))]
        rng.shuffle(order)
        pages_of = {}
        for n, selection in variants.items():
            pdf, pages = builder.build(selection, dict(job.empty_vars, VARIANT=n), f"Variant {n}")
            booklets.append((f"variant_{n}", pdf, pages))
            pages_of[n] = pages
        for p, n in zip(people, order):
            p["variant"], p["selection"] = n, variants[n]
            p["exam_file"], p["pages"] = f"variant_{n}.pdf", pages_of[n]
    return booklets


def write_booklets(job, booklets):
    page_opts, pagesize, out_dir = job.page_opts, job.pagesize, job.out_dir
    pad_title = "pad-title-page" in page_opts and job.layout.title_mode == "page"
    pad_exam = "pad-exam" in page_opts
    if job.single:
        pass
    elif "collate-exams" in page_opts:
        w = new_writer()
        for _stem, pdf, _pages in booklets:
            add_booklet(w, pdf, pagesize, pad_title, pad_exam, job.duplex)
        save(w, out_dir / "exams.pdf")
        job.written.append("exams.pdf")
        for p in job.people:
            p["exam_file"] = "exams.pdf"
    else:
        for stem, pdf, _pages in booklets:
            if pad_title or pad_exam or job.duplex:
                w = new_writer()
                add_booklet(w, pdf, pagesize, pad_title, pad_exam, job.duplex)
                save(w, out_dir / f"{stem}.pdf")
            else:
                (out_dir / f"{stem}.pdf").write_bytes(pdf)
        job.written.append(f"{len(booklets)} exam booklet(s)")

    # individual title pages in their own file
    if job.layout.title_mode == "separate" and not job.single:
        w = new_writer()
        for done, p in enumerate(job.people, 1):
            progress("title page", done, len(job.people))
            tv = dict(person_vars(job, p), VARIANT=p["variant"])
            tv["PAGE COUNT"], tv["QUESTION COUNT"] = p["pages"], len(p["selection"])
            w.append(PdfReader(io.BytesIO(job.builder.title_page(tv))))
            if "pad-title-page" in page_opts:
                w.add_blank_page(pagesize[0], pagesize[1])
        save(w, out_dir / "title_pages.pdf")
        job.written.append("title_pages.pdf")


# ------------------------------------------------------------------ answer cards

def row_kind(job, q):
    """What the card shows for a question: bubble count, or a written-answer box."""
    if q.kind == "numeric":
        return answer_card.NUMERIC
    if q.kind == "text":
        return answer_card.TEXT
    if q.kind == "match":
        return ("match", len(q.prompts), q.cells)
    return job.pad_to if job.pad_to is not None else q.printed_option_count


def card_entries(chunk):
    """(index, value, bits) per question for the card's QR code; see qr_payload.entry_field."""
    return [(q.index, *qr_payload.entry_field(q.kind, perm, len(q.value_sets))) for q, perm in chunk]


def card_chunks(job, sel):
    """(first question, questions, essays) per full-page card: as many questions as its rows hold
    (a matching question takes several rows and is never split between cards), then the essays,
    which come last: in the space left under the last card's rows, then on further cards."""
    geo = job.geo
    rpc = geo["answers"]["rows_per_column"]
    rest = [s for s in sel if s[0].kind != "essay"]
    chunks, start = [], 0
    while start < len(rest):
        end = start + 1
        while end < len(rest) and answer_card.row_layout([row_kind(job, q) for q, _ in rest[start:end + 1]], rpc)[1] <= job.per_card:
            end += 1
        chunks.append([start, rest[start:end], []])
        start = end
    page = answer_card.essay_page(geo)
    room = (answer_card.essay_top([row_kind(job, q) for q, _ in chunks[-1][1]], geo) - answer_card.ESSAY_BOTTOM
            if chunks else -1)
    for k, (q, perm) in enumerate(sel[len(rest):]):
        need = answer_card.essay_height(q.essay_quarters, page)
        if need > room + 0.5:                # on a card of its own
            chunks.append([len(rest) + k, [], []])
            room = page
        chunks[-1][2].append((q, perm))
        room -= need
    return chunks


def make_cards(job):
    """Every person's answer cards (or single-page quizzes, or merged sheets), built in memory:
    (manifest entries, answer_key.csv rows, [(file, pdf)]). A one-column merged sheet that runs out
    of sheets is tried again with narrower answers."""
    # one-column merged sheets: when the default answer width needs more sheets than a merged quiz can
    # have, the width steps down (to 90 pt at the least) until every exam fits
    width_steps = ([w for w in (160, 140, 120, 100, merged_layout.ANSWER_WIDTH) if w < job.answer_width]
                   if job.merged and job.one_column and job.width_defaulted and job.answer_width else [])
    while True:
        try:
            return person_cards(job)
        except merged_layout.SheetLimit as exc:
            if not width_steps:
                raise ExamError(f"{exc} Make the questions take less room: a narrower --answer-width (now "
                                f"{round(job.answer_width or merged_layout.ANSWER_WIDTH)} pt), a smaller --font-size or "
                                f"--question-spacing, more --option-columns, fewer questions (--max-items), two columns "
                                f"(if every question has at most four options), or a booklet --page-size.") from None
            narrower = width_steps.pop(0)
            warn(f"At {job.answer_width} pt answers some exams need more than {merged_layout.MAX_SHEETS} sheets; "
                 f"trying {narrower} pt (give --answer-width to choose the width yourself).")
            job.answer_width = None if narrower == merged_layout.ANSWER_WIDTH else narrower
            job.mbuilder.set_answer_width(job.answer_width)


def person_cards(job):
    args, quiz, pagesize, merged, single, duplex = job.args, job.quiz, job.pagesize, job.merged, job.single, job.duplex
    answer_width, shading, pad_options = job.answer_width, job.shading, job.pad_to is not None
    pool_size = len(quiz.questions)
    kind, collated_name = ("quiz", "quizzes.pdf") if single else ("answer", "answer_cards.pdf")
    manifest_cards, key_rows, card_pdfs = [], [], []
    # matching questions take several rows of a card, and essays may be on cards of their own,
    # so the cards say which number they start at
    numbered = any(q.kind in ("match", "essay") for q in quiz.questions)
    for p in job.people:
        sel = p["selection"]
        cards = []
        chunks = card_chunks(job, sel) if not merged else \
            [[0, [s for s in sel if s[0].kind != "essay"], [s for s in sel if s[0].kind == "essay"]]]
        if len(chunks) > answer_card.MAX_CARDS or (duplex and len(chunks) > DUPLEX_CARD_PAGES):
            raise ExamError(f"The answer card would need {len(chunks)} pages with the essay spaces; the limit is "
                            f"{DUPLEX_CARD_PAGES if duplex else answer_card.MAX_CARDS}. Use smaller --essay-space "
                            f"or fewer questions.")
        for k, (start, chunk, chunk_essays) in enumerate(chunks):  # long exams spill onto further cards
            first_essay = start + len(chunk) + 1
            cards.append({
                "payload": qr_payload.encode(quiz.ident, p["blank"], qr_fields(p), card_entries(chunk + chunk_essays),
                                             pool_size, index=k, a4=pagesize is A4, padded=pad_options,
                                             shaded=shading > 0, answer_width=answer_width,
                                             first_number=start + 1 if numbered else None, total=len(chunks)),
                "option_counts": [row_kind(job, q) for q, _ in chunk],
                "first_number": start + 1,
                "essays": [(first_essay + j, q.points, q.essay_quarters) for j, (q, _p) in enumerate(chunk_essays)],
            })
        show_variant = p["variant"] if job.n_variants is not None else ""
        details = dict(blank=p["blank"], name=p["name"], number=p["number"], seat=p["seat"],
                       show_name=not args.no_name, show_seat=not args.no_seat,
                       variant=show_variant, card_id=show_serial(p["serial"]), qr_quality=args.qr_quality)
        drawing = dict(details, shading=shading, answer_width=answer_width, instructions=job.card_text)
        if not merged and not single:
            progress("card", len(manifest_cards) + 1, len(job.people))
        if merged:
            progress("quiz", len(manifest_cards) + 1, len(job.people))
            who = f"blank {p['id']}" if p["blank"] else f"{p['name']} ({p['number']})"

            def payload_for(sheet, first, indices, spots, total, p=p, sel=sel):
                return qr_payload.encode(quiz.ident, p["blank"], qr_fields(p), card_entries([sel[i] for i in indices]),
                                         pool_size, index=sheet, kind=qr_payload.SHEETS, a4=pagesize is A4,
                                         padded=pad_options, shaded=shading > 0, answer_width=answer_width,
                                         first_number=first, spots=spots, total=total)

            mbuilder = job.mbuilder
            pdf, sheets = mbuilder.build(sel, dict(person_vars(job, p), VARIANT=p["variant"]), who, payload_for,
                                         quiz_title=quiz.title, **{k: v for k, v in details.items() if k != "qr_quality"},
                                         qr_quality=args.qr_quality)
            cards = [{"payload": sh["payload"]} for sh in sheets]
            page_geo = {"sheets": [sh["layout"] for sh in sheets]}
            p["pages"] = len(sheets) + ((2 if mbuilder.pad_title_page else 1) if mbuilder.cover else 0)
            p["cover"] = mbuilder.cover
        elif single:
            progress("quiz", len(manifest_cards) + 1, len(job.people))
            who = f"blank {p['id']}" if p["blank"] else f"{p['name']} ({p['number']})"
            if len(cards) != 1:
                raise ExamError(f"The quiz does not fit on a single page for {who}: it has {len(sel)} questions.")
            card = cards[0]
            card["payload"] = qr_payload.encode(quiz.ident, p["blank"], qr_fields(p), card_entries(sel), pool_size,
                                                kind=qr_payload.SINGLE_PAGE, a4=pagesize is A4, padded=pad_options,
                                                shaded=shading > 0, answer_width=answer_width,
                                                first_number=1 if numbered else None, total=1)
            # rows, not questions: a matching question takes several (the columns are those of a full card)
            columns = answer_card.geometry(pagesize, single=True, blank=p["blank"], questions=1,
                                           answer_width=answer_width)["answers"]["columns"]
            slots = answer_card.single_page_rows(card["option_counts"], columns) * columns
            page_geo = answer_card.geometry(pagesize, single=True, blank=p["blank"], questions=slots, answer_width=answer_width)

            def draw(canv, card=card, page_geo=page_geo, drawing=drawing):
                answer_card.draw_card(canv, pagesize, job.fonts, job.family, quiz.title, card["payload"],
                                      option_counts=card["option_counts"], geo=page_geo, **drawing)

            pdf = job.builder.build_single(sel, dict(person_vars(job, p), VARIANT=p["variant"]), page_geo, draw, who)
            p["pages"] = 1
        else:
            pdf = answer_card.cards_pdf(pagesize, job.fonts, job.family, quiz.title, cards, **drawing)
        stem = f"{safe_name(p['id'])}_{safe_name(p['name']) if not p['blank'] else 'blank'}_{kind}"
        card_file = collated_name if job.collate_cards else stem + ".pdf"
        card_pdfs.append((card_file, pdf))  # written only after every card has been built without error
        if single:
            p["exam_file"] = card_file
        keys = [correct_letters(q, perm) for q, perm in sel]
        key_rows.append([p["serial"], p["name"] or t("csv_blank"), p["number"], p["variant"], p["seat"], *keys])
        manifest_cards.append({
            "id": p["id"], "serial": p["serial"], "blank": p["blank"], "qr_fields": qr_fields(p), "name": p["name"], "seat": p["seat"], "variant": p["variant"],
            "exam_file": p["exam_file"], "card_file": card_file, "exam_pages": p["pages"],
            **({"cover_page": p.get("cover", False)} if merged else {}),
            "qr_payloads_hex": [c["payload"].hex() for c in cards],
            **({"card_layout": page_geo} if single else {}),
            "questions": [{"number": n, "index": q.index, "ident": q.ident, "kind": q.kind,
                           "option_order": perm if q.kind == "choice" else [],
                           **({"value_set": perm[0]} if q.kind == "numeric" else {}),
                           **({"items": len(q.prompts), "seed": perm[0], "matches": q.printed_answers(perm)[1]}
                              if q.kind == "match" else {}),
                           **({"space": f"{q.essay_quarters}/4"} if q.kind == "essay" else {}),
                           "printed_options": q.printed_option_count, "correct": k}
                          for n, ((q, perm), k) in enumerate(zip(sel, keys), 1)],
        })
    return manifest_cards, key_rows, card_pdfs


def write_cards(job, card_pdfs):
    pagesize, out_dir = job.pagesize, job.out_dir
    collated_name = "quizzes.pdf" if job.single else "answer_cards.pdf"
    card_writer = new_writer() if job.collate_cards else None
    for card_file, pdf in card_pdfs:
        if job.collate_cards:
            add_card(card_writer, pdf, pagesize, job.pad_cards, job.duplex, whole=job.single)
        elif job.pad_cards or job.duplex:
            w = new_writer()
            add_card(w, pdf, pagesize, job.pad_cards, job.duplex, whole=job.single)
            save(w, out_dir / card_file)
        else:
            (out_dir / card_file).write_bytes(pdf)
    if job.collate_cards:
        save(card_writer, out_dir / collated_name)
        job.written.append(collated_name)
    else:
        job.written.append(f"{len(job.people)} {'single-page quiz' if job.single else 'answer card'} file(s)")


# ------------------------------------------------------------------ answer key, attendance, manifest

def write_key(job, manifest_cards, key_rows):
    args, quiz, out_dir, pagesize = job.args, job.quiz, job.out_dir, job.pagesize
    # answer key: one page, one QR code
    (out_dir / "answer_key.pdf").write_bytes(answer_key_pdf(pagesize, job.fonts, job.family, quiz, job.key_qr, args.qr_quality,
                                                            protected=job.key_qr is not job.key_data))
    job.written.append("answer_key.pdf")
    if job.attendance is not None:
        headers, rows = job.attendance
        sheet = landscape(pagesize) if args.attendance_orientation == "landscape" else pagesize
        (out_dir / "attendance.pdf").write_bytes(attendance_pdf(sheet, job.fonts, job.family, quiz.title, headers, rows))
        job.written.append("attendance.pdf")

    # answer_key.csv and manifest.json (for marking)
    most = max(len(r) for r in key_rows) - 5
    semicolons = (args.csv_separator or ("semicolon" if i18n.usual_decimal_comma() else "comma")) == "semicolon"
    with open(out_dir / "answer_key.csv", "w", newline="", encoding="utf-8-sig") as fh:
        wr = csv.writer(fh, delimiter=";" if semicolons else ",")
        wr.writerow([t("csv_serial"), t("csv_name"), t("csv_number"), t("csv_variant"), t("csv_seat")] + [f"Q{i}" for i in range(1, most + 1)])
        for row in key_rows:
            # with semicolons, numbers take the decimal comma, as the spreadsheet expects
            wr.writerow([re.sub(r"(?<=\d)\.(?=\d)", ",", str(v)) if semicolons and i >= 5 else v for i, v in enumerate(row)])
    pad_to = job.pad_to
    manifest = {
        "builder": f"{__app_name__} {__version__}", "seed": job.seed,
        "quiz": {"ident": quiz.ident, "title": quiz.title, "hash": f"{qr_payload.quiz_hash(quiz.ident):08x}",
                 "question_index_bits": qr_payload.index_bits(len(quiz.questions))},
        "options": {"max-items": args.max_items, "ignore-item-banks": args.ignore_item_banks, "item-banks-followed": job.selector.mode == "useitembanks",
                    "title-map": args.title_map, "variants": args.variants, "page-size": job.page_name,
                    "page-options": sorted(job.page_opts), "columns": args.columns if job.merged else None,
                    "pad-options": pad_to is not None, "pad-to": pad_to, "qr-quality": args.qr_quality,
                    "cell-shading": round(job.shading * 100, 1), "answer-width": job.answer_width,
                    "cjk-region": job.cjk_region if job.cjk_found else None, "cjk-font": job.fonts.cjk_used},
        "student_number_column": job.list_info["number_column"],
        "qr_fields": job.list_info["qr_fields"],
        "answer_key_payload_hex": job.key_data.hex(),          # plain (schema 0x21), for checking
        "answer_key_qr_hex": job.key_qr.hex(),                 # as printed (schema 0x28 when password protected)
        "answer_key_protected": job.key_qr is not job.key_data,
        "questions": [{"index": q.index, "export_index": q.export_index, "ident": q.ident, "title": q.title,
                       "type": q.qtype, "kind": q.kind, "points": q.points, "options": len(q.options),
                       **({"answers": [a for _v, a in q.value_sets], "tolerance": q.tolerance,
                           "tolerance_percent": q.tolerance_percent} if q.kind == "numeric" else {}),
                       **({"accepted": q.accepted} if q.kind == "text" else {}),
                       "empty_options": [i for i, o in enumerate(q.options) if o.empty],
                       "correct_options": [i for i, o in enumerate(q.options) if o.correct],
                       **({"scoring": q.scoring} if q.scoring else {}),
                       **({"ordering": True, "scale": list(q.scale)} if q.ordering else {})}
                      for q in quiz.questions],
        "card_layout": None if job.single else job.geo,  # single-page layouts differ per card: see cards[].card_layout
        "cards": manifest_cards,
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    job.written += ["answer_key.csv", "manifest.json"]


def summary(job):
    quiz = job.quiz
    n_q = sorted({len(p["selection"]) for p in job.people})
    print(f"{__app_name__} {__version__}")
    say = lambda text: print(messages.translate(text))
    say(f"Quiz:      {quiz.title}")
    say(f"Questions: {'-'.join(map(str, (n_q[0], n_q[-1]))) if len(n_q) > 1 else n_q[0]} per exam (from {len(quiz.questions)} usable in the export"
        f"{'; following the item banks\' "pick N" rules' if job.selector.mode == 'useitembanks' else ''})")
    say(f"Cards:     {len(job.students)} student(s), {job.args.blank_cards} blank(s)")
    say(f"Seed:      {job.seed}")
    say(f"Output:    {job.out_dir}  ({', '.join(job.written)})")
    if word.is_word_folder(job.root):
        # a Word document is read by guessing at its layout: show what was read, to check against it
        say("Read from the Word document (check the answers before printing):")
        for q in sorted(quiz.questions, key=lambda q: q.export_index):
            kind, answer, text, points = word.describe(q, canvas)
            say(f"  {q.title}: {messages.translate(kind)}, {messages.translate(answer)}, {points} pt  {text}")


# ------------------------------------------------------------------ main

def run(argv=None):
    args = parse(argv)
    if args.list_fonts:
        list_fonts()
        return 0
    chosen = choose_quiz(args)
    if chosen is None:
        return 0
    job = Job(args=args, root=chosen[0], info=chosen[1], written=[])
    check_page_settings(job)
    password = ask_password() if args.password else None   # asked now, before the slow work starts
    job.seed = args.seed if args.seed is not None else random.SystemRandom().randrange(2 ** 32)
    job.rng = random.Random(job.seed)
    read_class_list(job)
    load_quiz(job)
    check_answer_width(job)
    make_answer_key(job, password)
    set_up_layout(job)

    job.out_dir = Path(args.output) if args.output else Path(safe_name(job.quiz.title, 120))
    job.out_dir.mkdir(parents=True, exist_ok=True)
    make_people(job)
    write_booklets(job, make_booklets(job))
    manifest_cards, key_rows, card_pdfs = make_cards(job)
    write_cards(job, card_pdfs)
    write_key(job, manifest_cards, key_rows)
    summary(job)
    return 0


def main(argv=None):
    try:
        return run(argv)
    except ExamError as exc:
        print(f"{messages.prefix('ERROR')} {messages.translate(str(exc))}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
