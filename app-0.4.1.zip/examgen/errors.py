import sys


class ExamError(Exception):
    """A problem that stops the program with a message for the user."""


_seen = set()


def warn(message, once=True):
    """Print a warning to stderr (each distinct message only once by default)."""
    if once:
        if message in _seen:
            return
        _seen.add(message)
    print(f"WARNING: {message}", file=sys.stderr)
