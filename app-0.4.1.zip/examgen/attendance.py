"""Attendance (sign-in) sheet."""

import io
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def attendance_pdf(pagesize, fonts, family, quiz_title, headers, rows):
    """headers: the column titles (Student Name, Student Number, then any seat and extra columns);
    rows: one list of values per student. A Signature column is added at the right."""
    face, bold = fonts.face(family), fonts.face(family, bold=True)

    def text(value, f=face):
        return "".join(f'<font name="{fn}">{escape(t)}</font>' for fn, t in fonts.runs(str(value), f))

    buf = io.BytesIO()
    margin = 40
    doc = SimpleDocTemplate(buf, pagesize=pagesize, leftMargin=margin, rightMargin=margin, topMargin=margin,
                            bottomMargin=margin, title=f"{quiz_title} - attendance", author="MasterTest Generator")
    cell = ParagraphStyle("cell", fontName=face, fontSize=9.5, leading=11.5)
    head = ParagraphStyle("head", fontName=bold, fontSize=9.5, leading=11.5)
    width = pagesize[0] - 2 * margin
    n_extra = len(headers) - 2
    # name and number as before; the extra columns share what is left with the signature, which
    # keeps at least a quarter of the width (more in landscape, where there is room)
    name_w, num_w = width * (0.28 if pagesize[0] < pagesize[1] else 0.22), width * (0.16 if pagesize[0] < pagesize[1] else 0.12)
    rest = width - name_w - num_w
    sign_w = max(width * 0.24, rest / (n_extra + 1.6) * 1.6) if n_extra else rest
    extra_w = (rest - sign_w) / n_extra if n_extra else 0
    table_rows = [[Paragraph(text(h, bold), head) for h in [*headers, "Signature"]]]
    for values in rows:
        table_rows.append([Paragraph(text(v), cell) for v in values] + [""])
    table = Table(table_rows, colWidths=[name_w, num_w] + [extra_w] * n_extra + [sign_w], repeatRows=1,
                  rowHeights=[None] + [26] * (len(table_rows) - 1))
    table.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.6, colors.black),
        ("BACKGROUND", (0, 0), (-1, 0), colors.Color(0.9, 0.9, 0.9)),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    title = Paragraph(text(f"Attendance - {quiz_title}", bold), ParagraphStyle("t", fontName=bold, fontSize=14, leading=18))
    doc.build([title, Spacer(1, 10), table])
    return buf.getvalue()
