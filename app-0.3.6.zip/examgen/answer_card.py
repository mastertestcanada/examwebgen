"""Draws the machine-readable answer card."""

import io

import segno
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas as rl_canvas

from . import __version__
from .card_instructions import CardInstructions, draw as draw_instructions, height as instruction_height
from .errors import ExamError

MAX_ANSWERS = 100   # per card at the default answer width (see capacity())
MAX_CARDS = 8       # the card index has 3 bits in the QR flags
ROWS_PER_COLUMN = 25
MAX_ROWS = 40       # rows per column when --answer-width makes the rows shorter
COLUMNS = 4
LETTERS = "ABCDEF"
ID_DIGITS = 9
SEAT_DIGITS = 3


def capacity(pagesize, answer_width=None):
    """Answers on one full-page card: columns x rows (100 at the default answer width)."""
    a = geometry(pagesize, answer_width=answer_width)["answers"]
    return a["columns"] * a["rows_per_column"]


def default_answer_width(pagesize):
    """Width of a written-answer box (the answer column, less 2 pt) on a full-page or single-page card when
    --answer-width is not given: six bubble pitches of the four-column layout."""
    W = pagesize[0]
    col_w = (W - 2 * 40.0) / COLUMNS
    return BOX_CELLS * min(16.5, (col_w - 26.0 - 10.0) / len(LETTERS)) - 2.0


def geometry(pagesize, single=False, blank=False, questions=0, answer_width=None):
    """All positions on the card, in points from the bottom-left corner of the page.
    The same numbers are written to manifest.json for the marking software.

    single=False: the full-page card (QR schema 0x02); the result depends only on
    the page size.
    single=True: the answer area printed above the questions of a single-page quiz
    (QR schema 0x04). The result depends only on the page size, whether the card is
    blank, and the number of questions - all of which a scanner learns from the QR
    code - so the layout can be reproduced exactly when marking.

    answer_width (--answer-width, whole points; None = the default): the width of a written-answer
    box. Bubble pitch, bubble size, row height and box height scale with it, and the number of
    columns (at most four) and of rows per column follow from what fits; the QR code carries the
    width so a scanner can repeat this."""
    W, H = pagesize
    M = 40.0
    fid, inset = 14.0, 32.0
    band_top = H - 54.0
    header = 13.0
    M0 = 40.0
    num_w = 26.0
    pitch_x0 = min(16.5, ((W - 2 * M0) / COLUMNS - num_w - 10.0) / len(LETTERS))
    if answer_width is None:
        k, columns, pitch_x = 1.0, COLUMNS, pitch_x0
    else:
        pitch_x = (answer_width + 2.0) / BOX_CELLS
        k = pitch_x / pitch_x0
        columns = max(1, min(COLUMNS, int((W - 2 * M0) // (num_w + 10.0 + BOX_CELLS * pitch_x))))
    if single:
        band_h = 168.0 if blank else 104.0   # blank cards need room for the ID bubbles
        qr = 140.0 if blank else 96.0
        rows = max(1, -(-questions // columns))
        pitch_y = 17.0 * k
        grid_top = band_top - band_h - 10.0
        fid_y = grid_top - header - rows * pitch_y - 6.0 - fid / 2
        zone_bottom = fid_y - fid / 2 - 4.0
        fiducials = [[inset, H - inset], [W - inset, H - inset], [inset, fid_y], [W - inset, fid_y]]
    else:
        band_h = 168.0
        qr = 140.0
        grid_top = band_top - band_h - 12.0
        pitch_y = min(19.0, (grid_top - header - 58.0) / ROWS_PER_COLUMN)
        if answer_width is None:
            rows = ROWS_PER_COLUMN
        else:
            pitch_y *= k
            rows = max(1, min(MAX_ROWS, int((grid_top - header - 58.0) // pitch_y)))
        zone_bottom = 0.0
        fiducials = [[inset, H - inset], [W - inset, H - inset], [inset, inset], [W - inset, inset]]
    col_w = (W - 2 * M) / columns
    idp_x, idp_y = 14.5, 13.0
    id_w = ID_DIGITS * idp_x + 16.0 + SEAT_DIGITS * idp_x
    id_x0 = W - M - qr - 18.0 - id_w
    return {
        "page": [W, H],
        "margin": M,
        "fiducial_size": fid,
        "single_page": single,
        "zone_bottom": zone_bottom,
        "fiducials": fiducials,
        "qr": {"x": W - M - qr, "y": band_top - qr, "size": qr},
        "band_top": band_top,
        "band_height": band_h,
        "answers": {
            "rows_per_column": rows, "columns": columns, "bubble_radius": 5.6 * k,
            "x0": M + num_w + pitch_x / 2, "column_pitch": col_w, "option_pitch": pitch_x,
            "y0": grid_top - header - pitch_y / 2, "row_pitch": pitch_y, "header_y": grid_top - 9.0,
            "number_width": num_w,
            # written answers: a box over the six bubble positions (see answer_box); numeric boxes
            # are split into box_cells equal cells, one character each
            "box_inset": 1.0, "box_cells": BOX_CELLS, "box_half_height_max": 8.0 * k,
            "answer_width": answer_width,
        },
        "student_id": {
            "digits": ID_DIGITS, "bubble_radius": 5.0, "x0": id_x0 + idp_x / 2, "digit_pitch": idp_x,
            "y0": band_top - 30.0 - idp_y / 2, "row_pitch": idp_y, "box_top": band_top - 10.0, "box_height": 16.0,
        },
        "seat": {
            "digits": SEAT_DIGITS, "bubble_radius": 5.0, "x0": id_x0 + ID_DIGITS * idp_x + 16.0 + idp_x / 2,
            "digit_pitch": idp_x, "y0": band_top - 30.0 - idp_y / 2, "row_pitch": idp_y,
            "box_top": band_top - 10.0, "box_height": 16.0,
        },
    }


NUMERIC = -1   # row kinds in option_counts: a numeric answer (digit boxes)
TEXT = -2      # a written text answer (one open box)
BOX_CELLS = 6
BOX_GREY = 0.55        # outline of written-answer boxes when cells are not shaded
SHADING = 0.15         # default darkness of shaded cells (--cell-shading 15)
SHADE_GAP = 1.6        # white gap between shaded cells, in points


def draw_cells(c, left, bottom, width, height, cells, shading):
    """A written-answer box split into `cells` equal cells. With `shading` (0-1, the darkness of the
    grey) each cell is a solid light-grey rectangle and the cells are separated by white gaps: in a
    phone photo an even tint is easy to tell from writing, whereas a thin printed line comes out
    about as dark as pencil. With shading 0 the box and cell dividers are outlined in light grey."""
    cw = width / cells
    if shading > 0:
        c.setFillGray(1 - shading)
        for k in range(cells):
            c.rect(left + k * cw + SHADE_GAP / 2, bottom, cw - SHADE_GAP, height, stroke=0, fill=1)
        c.setFillGray(0)
        return
    c.setStrokeGray(BOX_GREY)
    c.setLineWidth(0.6)
    c.rect(left, bottom, width, height, stroke=1, fill=0)
    for k in range(1, cells):
        c.line(left + k * cw, bottom, left + k * cw, bottom + height)
    c.setStrokeGray(0)


def answer_box(geo, question):
    """(left, bottom, width, height) of the written-answer box for a 0-based question: it sits
    where the row's six bubbles would be, inset 1 pt on each side."""
    a = geo["answers"]
    x, y = answer_bubble(geo, question, 0)
    left = x - a["option_pitch"] / 2 + 1.0
    width = BOX_CELLS * a["option_pitch"] - 2.0
    half = min(a["row_pitch"] / 2 - 1.5, a["box_half_height_max"])
    return left, y - half, width, 2 * half


def answer_bubble(geo, question, option):
    """Centre of the bubble for 0-based question and option numbers."""
    a = geo["answers"]
    col, row = divmod(question, a["rows_per_column"])
    return (a["x0"] + col * a["column_pitch"] + option * a["option_pitch"], a["y0"] - row * a["row_pitch"])


def draw_qr(c, data, x, y, size, quality="M"):
    """Draw `data` as a byte-mode QR code with error-correction level L, M, Q or H."""
    try:
        qr = segno.make(data, mode="byte", error=quality.lower(), micro=False, boost_error=False)
    except Exception:
        raise ExamError(
            f"{len(data)} bytes do not fit in one QR code at quality level {quality.upper()}. "
            f"Use a lower --qr-quality" + (" or fewer --add-qr-field columns." if data[0] != 0x03 else "."))
    matrix = qr.matrix
    n = len(matrix)
    module = size / (n + 8)  # 4-module quiet zone on every side
    c.setFillGray(0)
    for r, row in enumerate(matrix):
        run = None
        for col in range(n + 1):
            dark = col < n and row[col]
            if dark and run is None:
                run = col
            elif not dark and run is not None:
                c.rect(x + (run + 4) * module, y + size - (r + 5) * module, (col - run) * module, module, stroke=0, fill=1)
                run = None
    return qr.version


def _bubble(c, x, y, r, label, font, size=6.0):
    c.setLineWidth(0.7)
    c.setStrokeGray(0)
    c.circle(x, y, r, stroke=1, fill=0)
    c.setFillGray(0.5)
    c.setFont(font, size)
    c.drawCentredString(x, y - size * 0.35, label)
    c.setFillGray(0)


def _digit_grid(c, g, title, font, bold):
    n, px, py = g["digits"], g["digit_pitch"], g["row_pitch"]
    left = g["x0"] - px / 2
    c.setFont(bold, 6.5)
    c.setFillGray(0)
    c.drawString(left, g["box_top"] + 2.5, title)
    c.setLineWidth(0.7)
    for i in range(n):
        c.rect(left + i * px, g["box_top"] - g["box_height"], px, g["box_height"], stroke=1, fill=0)
        for d in range(10):
            _bubble(c, g["x0"] + i * px, g["y0"] - d * py, g["bubble_radius"], str(d), font, 6.0)


def draw_card(c, pagesize, fonts, family, quiz_title, payload, *, blank, name="", number="", seat="",
              variant="", card_id="", option_counts=(), first_number=1, card_number=1, card_total=1, geo=None,
              qr_quality="M", shading=SHADING, answer_width=None, instructions=None):
    """Draw one card on the current page of canvas `c`. `option_counts` lists the
    number of bubbles for each question on this card; they are numbered from
    `first_number`. NUMERIC and TEXT mark written-answer rows."""
    geo = geo or geometry(pagesize, answer_width=answer_width)
    room = geo["answers"]["columns"] * geo["answers"]["rows_per_column"]
    if len(option_counts) > room:
        raise ExamError(f"An answer card holds at most {room} answers.")
    compact = geo["single_page"] and not blank
    W, H = pagesize
    M = geo["margin"]
    font, bold = fonts.face(family), fonts.face(family, bold=True)

    def safe(text, face):
        return "".join(ch if ch.isspace() or fonts.has_glyph(face, ch) else "?" for ch in str(text))

    # corner registration marks
    s = geo["fiducial_size"]
    c.setFillGray(0)
    for x, y in geo["fiducials"]:
        c.rect(x - s / 2, y - s / 2, s, s, stroke=0, fill=1)

    # title
    title = safe(quiz_title, bold)
    size = 14.0
    room = W - 2 * (M + 16)
    while size > 7 and stringWidth(title, bold, size) > room:
        size -= 0.5
    c.setFont(bold, size)
    c.drawCentredString(W / 2, H - 37, title)

    # QR code
    q = geo["qr"]
    draw_qr(c, payload, q["x"], q["y"], q["size"], qr_quality)
    c.setFont(font, 7)
    c.drawCentredString(q["x"] + q["size"] / 2, q["y"] - 7, safe(card_id, font))

    top = geo["band_top"]
    left_w = (geo["student_id"]["x0"] - geo["student_id"]["digit_pitch"] / 2 - 14 - M) if blank else (q["x"] - 18 - M)
    c.setFont(bold, 11)
    c.drawString(M, top - 10, ("ANSWERS" if geo["single_page"] else "ANSWER CARD") + (f"  {card_number} of {card_total}" if card_total > 1 else ""))
    y = top - (26 if compact else 30)
    if blank:
        _digit_grid(c, geo["student_id"], "STUDENT NUMBER", font, bold)
        _digit_grid(c, geo["seat"], "SEAT", font, bold)
        c.setFont(bold, 7.5)
        c.drawString(M, y, "NAME (please print)")
        c.setLineWidth(0.7)
        c.rect(M, y - 34, left_w, 30, stroke=1, fill=0)
        y -= 50
        lines = []
        if variant:
            lines.append(("Variant", str(variant)))
        lines.append(("Card", str(card_id)))
    else:
        lines = [("Name", name), ("Student number", number), ("Seat", seat)]
        if variant:
            lines.append(("Variant", str(variant)))
    for label, value in lines:
        c.setFont(font, 8 if blank or compact else 9)
        c.drawString(M, y, f"{label}:")
        lw = 38 if blank else 70 if compact else 78
        vs = 10 if blank or compact else 12
        value = safe(value, bold)
        while vs > 6 and stringWidth(value, bold, vs) > left_w - lw:
            vs -= 0.5
        c.setFont(bold, vs)
        c.drawString(M + lw, y, value)
        y -= 15 if blank else 14 if compact else 19
    # instructions (--answer-card-instructions, including the "Correct / Incorrect" bubble examples), below the details
    conditions = {"single" if geo["single_page"] else "card", "blank" if blank else "named"}
    if compact:
        conditions.add("compact")
    if any(n < 0 for n in option_counts):
        conditions.add("written")
    flow = (instructions or CardInstructions.load()).flowables(fonts, family, 7.5, left_w, conditions)
    h = instruction_height(flow, left_w)
    floor = top - geo["band_height"] + 1       # just above the line under the header band
    text_top = min(y + 6, floor + h)
    if text_top - h < floor:
        raise ExamError(f"The answer-card instructions are {h:.0f} pt tall; the answer card has room for "
                        f"{max(0.0, y + 6 - floor):.0f} pt. Shorten the --answer-card-instructions file or its images.")
    draw_instructions(c, flow, M, text_top, left_w)

    # answer bubbles
    a = geo["answers"]
    c.setLineWidth(0.5)
    c.setStrokeGray(0.6)
    c.line(M, top - geo["band_height"] - 4, W - M, top - geo["band_height"] - 4)
    n_q = len(option_counts)
    for col in range((n_q + a["rows_per_column"] - 1) // a["rows_per_column"]):
        qs = range(col * a["rows_per_column"], min(n_q, (col + 1) * a["rows_per_column"]))
        c.setFont(bold, 7)
        c.setFillGray(0.3)
        for k in range(max([option_counts[i] for i in qs if option_counts[i] > 0], default=0)):
            c.drawCentredString(answer_bubble(geo, col * a["rows_per_column"], k)[0], a["header_y"], LETTERS[k])
        c.setFillGray(0)
        for i in qs:
            x, yq = answer_bubble(geo, i, 0)
            c.setFont(bold, 9)
            c.setFont(bold, 9 if first_number + i < 100 else 8)
            c.drawRightString(x - a["option_pitch"] / 2 - 4, yq - 3.2, str(first_number + i))
            if option_counts[i] < 0:
                # light grey so the student's writing stands out from the box when it is read
                left, bottom, width, height = answer_box(geo, i)
                draw_cells(c, left, bottom, width, height, BOX_CELLS if option_counts[i] == NUMERIC else 1, shading)
                continue
            for k in range(option_counts[i]):
                bx, by = answer_bubble(geo, i, k)
                _bubble(c, bx, by, a["bubble_radius"], LETTERS[k], font, 6.0 * a["bubble_radius"] / 5.6)

    c.setFont(font, 6)
    c.setFillGray(0.4)
    if not geo["single_page"]:
        c.drawCentredString(W / 2, 29, f"Exam Generator {__version__}  -  {safe(card_id, font)}"
                            + (f"  -  card {card_number} of {card_total}" if card_total > 1 else ""))
    c.setFillGray(0)
    return geo


def cards_pdf(pagesize, fonts, family, quiz_title, cards, **common):
    """One PDF with a page per card. `cards` is a list of dicts with the keys
    payload, option_counts and first_number; `common` holds the student details."""
    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=pagesize)
    c.setTitle(f"{quiz_title} - answer card")
    c.setAuthor("Exam Generator")
    for n, card in enumerate(cards, 1):
        draw_card(c, pagesize, fonts, family, quiz_title, card["payload"], option_counts=card["option_counts"],
                  first_number=card["first_number"], card_number=n, card_total=len(cards), **common)
        c.showPage()
    c.save()
    return buf.getvalue()
