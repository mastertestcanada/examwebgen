"""Font handling: built-in PDF fonts, TrueType/OpenType loading, automatic
bold/italic discovery, and fallback fonts for characters a font lacks."""

import atexit
import os
import shutil
import sys
import tempfile
from pathlib import Path

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont as RLTTFont

from .errors import ExamError, warn

BUILTIN = {
    "helvetica": {(0, 0): "Helvetica", (1, 0): "Helvetica-Bold", (0, 1): "Helvetica-Oblique", (1, 1): "Helvetica-BoldOblique"},
    "times": {(0, 0): "Times-Roman", (1, 0): "Times-Bold", (0, 1): "Times-Italic", (1, 1): "Times-BoldItalic"},
    "courier": {(0, 0): "Courier", (1, 0): "Courier-Bold", (0, 1): "Courier-Oblique", (1, 1): "Courier-BoldOblique"},
}
_BUILTIN_NAMES = {name for fam in BUILTIN.values() for name in fam.values()}

# CSS font-family names used by the Canvas editor -> (family, force bold)
CSS_FAMILIES = {
    "arial": ("helvetica", False), "helvetica": ("helvetica", False), "sans-serif": ("helvetica", False),
    "verdana": ("helvetica", False), "tahoma": ("helvetica", False), "trebuchet ms": ("helvetica", False),
    "arial black": ("helvetica", True), "impact": ("helvetica", True),
    "times new roman": ("times", False), "times": ("times", False), "georgia": ("times", False),
    "serif": ("times", False), "book antiqua": ("times", False), "palatino": ("times", False),
    "courier new": ("courier", False), "courier": ("courier", False), "monospace": ("courier", False),
    "andale mono": ("courier", False), "consolas": ("courier", False), "monaco": ("courier", False),
}

FONT_EXTENSIONS = (".ttf", ".otf", ".ttc")
_FALLBACK_FILES = [
    "DejaVuSans.ttf", "Arial Unicode.ttf", "arialuni.ttf", "seguisym.ttf", "NotoSans-Regular.ttf",
    "LiberationSans-Regular.ttf", "FreeSans.ttf", "segoeui.ttf", "Arial.ttf", "arial.ttf",
]


def system_font_dirs():
    dirs = []
    if sys.platform.startswith("win"):
        dirs.append(Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts")
        local = os.environ.get("LOCALAPPDATA")
        if local:
            dirs.append(Path(local) / "Microsoft" / "Windows" / "Fonts")
    elif sys.platform == "darwin":
        dirs += [Path("/System/Library/Fonts"), Path("/Library/Fonts"), Path.home() / "Library" / "Fonts"]
    else:
        dirs += [Path("/usr/share/fonts"), Path("/usr/local/share/fonts"), Path.home() / ".fonts",
                 Path.home() / ".local" / "share" / "fonts"]
    return [d for d in dirs if d.is_dir()]


def _font_files(directory, recursive):
    it = directory.rglob("*") if recursive else directory.iterdir()
    try:
        return sorted(p for p in it if p.suffix.lower() in FONT_EXTENSIONS and p.is_file())
    except OSError:
        return []


def _describe(path):
    """[(index, family, bold, italic, is_cff)] for each face in a font file."""
    from fontTools.ttLib import TTCollection, TTFont

    out = []
    try:
        if path.suffix.lower() == ".ttc":
            faces = list(enumerate(TTCollection(str(path), lazy=True).fonts))
        else:
            faces = [(0, TTFont(str(path), lazy=True))]
        for index, f in faces:
            name = f["name"]
            family = name.getDebugName(1) or name.getDebugName(16) or path.stem
            sub = (name.getDebugName(2) or name.getDebugName(17) or "").lower()
            sel = f["OS/2"].fsSelection if "OS/2" in f else 0
            mac = f["head"].macStyle if "head" in f else 0
            bold = bool(sel & 0x20 or mac & 1 or "bold" in sub)
            italic = bool(sel & 0x01 or mac & 2 or "italic" in sub or "oblique" in sub)
            out.append((index, family.strip(), bold, italic, "CFF " in f or "CFF2" in f))
    except Exception:
        return []
    return out


_tmpdir = None


def _convert_cff(path):
    """reportlab cannot embed PostScript-flavoured OpenType; convert the outlines to TrueType."""
    global _tmpdir
    from fontTools.pens.cu2quPen import Cu2QuPen
    from fontTools.pens.ttGlyphPen import TTGlyphPen
    from fontTools.ttLib import TTFont, newTable

    if _tmpdir is None:
        _tmpdir = Path(tempfile.mkdtemp(prefix="examgen_fonts_"))
        atexit.register(shutil.rmtree, _tmpdir, ignore_errors=True)
    target = _tmpdir / (path.stem + ".ttf")
    if target.exists():
        return target
    font = TTFont(str(path))
    order = font.getGlyphOrder()
    glyph_set = font.getGlyphSet()
    glyphs = {}
    for name in order:
        pen = TTGlyphPen(glyph_set)
        glyph_set[name].draw(Cu2QuPen(pen, 1.0, reverse_direction=True))
        glyphs[name] = pen.glyph()
    font["loca"] = newTable("loca")
    font["glyf"] = glyf = newTable("glyf")
    glyf.glyphOrder = order
    glyf.glyphs = glyphs
    for tag in ("CFF ", "CFF2", "VORG"):
        if tag in font:
            del font[tag]
    glyf.compile(font)
    for name, (advance, _lsb) in list(font["hmtx"].metrics.items()):
        g = glyf[name]
        font["hmtx"].metrics[name] = (advance, getattr(g, "xMin", 0) if g.numberOfContours else 0)
    font["maxp"] = maxp = newTable("maxp")
    maxp.tableVersion = 0x00010000
    maxp.numGlyphs = len(order)
    for attr in ("maxZones", "maxTwilightPoints", "maxStorage", "maxFunctionDefs", "maxInstructionDefs",
                 "maxStackElements", "maxSizeOfInstructions", "maxComponentElements", "maxPoints",
                 "maxContours", "maxCompositePoints", "maxCompositeContours", "maxComponentDepth"):
        setattr(maxp, attr, 0)
    maxp.maxZones = 1
    post = font["post"]
    post.formatType = 3.0
    post.extraNames, post.mapping = [], {}
    font.sfntVersion = "\000\001\000\000"
    font.save(str(target))
    return target


class FontManager:
    def __init__(self):
        self.families = {k: dict(v) for k, v in BUILTIN.items()}
        self._cmaps = {}
        self._fallback = None
        self._fallback_searched = False
        self._counter = 0

    # ------------------------------------------------------------ loading
    def load(self, spec):
        """Make a font available and return its family key. `spec` is Helvetica,
        Times, Courier, a path to a .ttf/.otf/.ttc file, or an installed family name."""
        key = spec.strip().lower()
        if key in ("times-roman", "times roman", "times new roman"):
            key = "times"
        if key in ("courier new",):
            key = "courier"
        if key in self.families:
            return key
        path = Path(spec).expanduser()
        if path.is_file():
            if path.suffix.lower() not in FONT_EXTENSIONS:
                raise ExamError(f"Unsupported font file type: {path.name} (use .ttf, .otf or .ttc)")
            faces = _describe(path)
            if not faces:
                raise ExamError(f"Could not read font file {path}")
            family = faces[0][1]
            prefix = path.stem[:3].lower()
            candidates = [p for p in _font_files(path.parent, False) if p.stem[:3].lower() == prefix]
            return self._register_family(family, candidates, preferred=path)
        if any(spec.lower().endswith(e) for e in FONT_EXTENSIONS) or os.sep in spec:
            raise ExamError(f"Font file not found: {spec}")
        # an installed family name
        wanted = key.replace(" ", "")
        candidates = []
        for d in system_font_dirs():
            for p in _font_files(d, True):
                stem = p.stem.lower().replace(" ", "").replace("-", "").replace("_", "")
                if stem.startswith(wanted[:4]):
                    candidates.append(p)
        fam = None
        for p in candidates:
            for _i, family, _b, _it, _c in _describe(p):
                if family.lower() == key:
                    fam = family
                    break
            if fam:
                break
        if not fam:
            raise ExamError(
                f"Font '{spec}' was not found. Use Helvetica, Times, Courier, the path to a "
                f"TrueType/OpenType file, or the name of an installed font family."
            )
        return self._register_family(fam, candidates)

    def _register_family(self, family, files, preferred=None):
        key = family.lower()
        if key in self.families:
            return key
        found = {}
        ordered = ([preferred] if preferred else []) + [f for f in files if f != preferred]
        for p in ordered:
            for index, fam, bold, italic, cff in _describe(p):
                if fam.lower() != key:
                    continue
                slot = (int(bold), int(italic))
                if slot not in found:
                    found[slot] = (p, index, cff)
        if preferred is not None and (0, 0) not in found:
            # the named file is e.g. a bold face: still use it as the regular font
            p0 = next(iter(_describe(preferred)))
            found[(0, 0)] = (preferred, p0[0], p0[4])
        if (0, 0) not in found:
            found[(0, 0)] = next(iter(found.values()))
        faces = {}
        for slot, (p, index, cff) in found.items():
            self._counter += 1
            name = f"EG{self._counter}-{family.replace(' ', '')}-{'B' if slot[0] else ''}{'I' if slot[1] else ''}R"[:60]
            try:
                src = _convert_cff(p) if cff else p
                pdfmetrics.registerFont(RLTTFont(name, str(src), subfontIndex=index))
            except Exception as exc:
                if slot == (0, 0):
                    raise ExamError(f"Could not load font {p}: {exc}")
                warn(f"Could not load font {p.name}: {exc}")
                continue
            faces[slot] = name
        missing = [n for s, n in (((1, 0), "bold"), ((0, 1), "italic"), ((1, 1), "bold-italic")) if s not in faces]
        if missing:
            warn(f"Font '{family}': no {', '.join(missing)} face was found; the closest available face is used instead.")
        reg = faces[(0, 0)]
        faces.setdefault((1, 0), reg)
        faces.setdefault((0, 1), reg)
        faces.setdefault((1, 1), faces[(1, 0)] if faces[(1, 0)] != reg else faces[(0, 1)])
        self.families[key] = faces
        return key

    # ------------------------------------------------------------ lookup
    def face(self, family, bold=False, italic=False):
        return self.families[family][(int(bool(bold)), int(bool(italic)))]

    def css_family(self, value, base_family):
        """Resolve a CSS font-family list to (family key, force_bold)."""
        for name in value.split(","):
            name = name.strip().strip("'\"").lower()
            if name in self.families:
                return name, False
            if name in CSS_FAMILIES:
                return CSS_FAMILIES[name]
        return base_family, False

    def has_glyph(self, fontname, ch):
        cp = ord(ch)
        if fontname in _BUILTIN_NAMES:
            if cp < 0x7F or 0xA0 <= cp <= 0xFF:
                return True
            try:
                ch.encode("cp1252")
                return True
            except UnicodeEncodeError:
                return False
        cmap = self._cmaps.get(fontname)
        if cmap is None:
            cmap = self._cmaps[fontname] = pdfmetrics.getFont(fontname).face.charToGlyph
        return cp in cmap or cp in (0x20, 0xA0)

    def _fallback_font(self):
        if not self._fallback_searched:
            self._fallback_searched = True
            for d in system_font_dirs():
                files = {p.name.lower(): p for p in _font_files(d, True)}
                for wanted in _FALLBACK_FILES:
                    p = files.get(wanted.lower())
                    if p is not None:
                        try:
                            pdfmetrics.registerFont(RLTTFont("EG-Fallback", str(p)))
                            self._fallback = "EG-Fallback"
                            return self._fallback
                        except Exception:
                            continue
        return self._fallback

    def runs(self, text, fontname):
        """Split text into [(fontname, chunk)], switching to a fallback font for
        characters the requested font cannot draw."""
        if text.isascii() and fontname in _BUILTIN_NAMES:
            return [(fontname, text)]
        out = []
        for ch in text:
            use = fontname
            if not self.has_glyph(fontname, ch) and not ch.isspace():
                fb = self._fallback_font()
                if fb and self.has_glyph(fb, ch):
                    use = fb
                else:
                    warn(f"No available font can draw the character {ch!r} (U+{ord(ch):04X}); it is printed as '?'.")
                    ch = "?"
            if out and out[-1][0] == use:
                out[-1][1] += ch
            else:
                out.append([use, ch])
        return [(f, t) for f, t in out]
