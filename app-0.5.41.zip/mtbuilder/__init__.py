"""MasterTest Builder - builds printable exams and answer cards from Canvas and D2L Brightspace quiz exports."""

__version__ = "0.5.41"
__app_name__ = "MasterTest Builder"
