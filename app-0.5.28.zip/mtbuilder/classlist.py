"""The class list: reading it, seats, card serials and the attendance sheet's rows."""

import csv
import io
import re
import unicodedata
from pathlib import Path


from . import qr_payload
from .errors import ExamError, warn
from .i18n import t
from .html_render import normalise_variable


def csv_delimiter(text):
    """The field separator of a CSV: the one of comma, semicolon and tab that occurs most often
    outside quotes in its first non-empty line. Spreadsheets set up for French (and other
    languages that write 0,5) save CSV files with semicolons."""
    line = next((l for l in text.splitlines() if l.strip()), "")
    counts, quoted = {",": 0, ";": 0, "\t": 0}, False
    for ch in line:
        if ch == '"':
            quoted = not quoted
        elif not quoted and ch in counts:
            counts[ch] += 1
    best = max(counts, key=lambda c: (counts[c], c == ","))
    return best if counts[best] else ","


def _read_csv(path, what):
    try:
        try:
            with open(path, newline="", encoding="utf-8-sig") as fh:
                text = fh.read()
        except UnicodeDecodeError:
            with open(path, newline="", encoding="cp1252") as fh:
                text = fh.read()
    except OSError as exc:
        raise ExamError(f"Could not read {what} '{path}': {exc}")
    return [row for row in csv.reader(io.StringIO(text, newline=""), delimiter=csv_delimiter(text))]


def inline_title_map(value):
    """--title-map written out instead of a file, 'title=count; title=count' (a ; inside a title is
    written \\;): its [title, count] rows, or None when the value names a file (or is not written so)."""
    if Path(value).is_file() or "=" not in value:
        return None
    rows = []
    for part in re.split(r"(?<!\\);", value):
        part = part.replace("\\;", ";").strip()
        if not part:
            continue
        if "=" not in part:
            raise ExamError(f"--title-map: '{part}' needs the form title=count.")
        title, count = part.rsplit("=", 1)
        rows.append([title.strip(), count.strip()])
    return rows


def split_list(text):
    """A comma-separated option value -> its non-empty items (double quotes protect commas inside an item)."""
    return [c.strip() for row in csv.reader([text or ""], skipinitialspace=True) for c in row if c.strip()]


def _key(text):
    return re.sub(r"[^a-z0-9]", "", text.lower())


NAME_HEADERS = ("studentname", "name", "fullname", "student")
NUMBER_HEADERS = ("studentnumber", "studentid", "studentno", "number", "id", "sisuserid", "sisid", "sisloginid",
                  "orgdefinedid", "username")
# Canvas gradebook exports have both Canvas's own ID and the institution's SIS columns, Brightspace
# grade exports the institution's OrgDefinedId and the Brightspace Username: these are preferred, in
# this order, when they hold data
SIS_HEADERS = ("sisuserid", "sisid", "sisloginid", "orgdefinedid", "username")
# Brightspace writes a # before each OrgDefinedId and Username (and puts one in the End-of-Line
# Indicator column), which its grade import needs: the Builder leaves it out, MasterTest Marker puts
# it back in its Brightspace grade file
BRIGHTSPACE_IDS = ("orgdefinedid", "username")


def _unmarked(value):
    return value[1:].strip() if value.startswith("#") else value


def find_number_column(header, rows):
    """Index of the student-number column: the first SIS column (SIS_HEADERS order) with a value
    in any row, else the left-most column whose header is a student-number name; None if none."""
    keys = [_key(h) for h in header]
    for k in SIS_HEADERS:
        if k in keys:
            i = keys.index(k)
            if any(len(r) > i and r[i].strip() for r in rows):
                return i
    return next((i for i, k in enumerate(keys) if k in NUMBER_HEADERS), None)
SEAT_HEADERS = ("seat", "seatnumber", "seatno")
SERIAL_FIELD = "Card serial"   # the last QR field of a class-list card (0.3.8); a blank card's only field


def luhn_digit(digits):
    """The Luhn check digit for a string of digits (as on payment cards): catches any single
    mistyped digit and most swaps of two neighbouring digits."""
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 0:          # every second digit from the right, starting next to the check digit
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return str((10 - total % 10) % 10)


def luhn_valid(serial):
    return serial.isdigit() and len(serial) > 1 and luhn_digit(serial[:-1]) == serial[-1]


def new_serial(rng, used):
    """A 12-digit card serial: 11 random digits (the first not 0) and a Luhn check digit,
    different from every serial already in `used`."""
    while True:
        body = str(rng.randrange(10 ** 10, 10 ** 11))
        serial = body + luhn_digit(body)
        if serial not in used:
            used.add(serial)
            return serial


def show_serial(serial):
    """A serial as printed: groups of four digits."""
    return " ".join(serial[i:i + 4] for i in range(0, len(serial), 4))


def read_classlist(path, prefer_id=None, add_to_qr=()):
    """Columns are recognised by their header names (case, spaces and punctuation
    are ignored), never by position."""
    rows = [r for r in _read_csv(path, "class list") if any(c.strip() for c in r)]
    if not rows:
        raise ExamError(f"Class list '{path}' is empty.")
    header = [h.strip() for h in rows[0]]
    keys = [_key(h) for h in header]
    listing = ", ".join(h for h in header if h)

    def find(*names):
        return next((keys.index(n) for n in names if n in keys), None)

    def column(name, option):
        k = _key(name)
        if not k or k not in keys:
            raise ExamError(f"{option}: the class list has no column named '{name}'. Its columns are: {listing}.")
        return keys.index(k)

    name_i = find(*NAME_HEADERS)
    seat_i = find(*SEAT_HEADERS)
    first_i, last_i = find("firstname", "first"), find("lastname", "last", "surname")
    if name_i is None and (first_i is None or last_i is None):
        raise ExamError(f"Class list '{path}' needs a 'student name' column.")
    if prefer_id:
        num_i = column(prefer_id, "--student-id-column")
    else:  # an SIS column with data, else the left-most column with a student-number header
        num_i = find_number_column(header, rows[1:])
        if num_i is None:
            raise ExamError(f"Class list '{path}' needs a 'student number' column (or name one with --student-id-column).")
    qr_cols = [column(name, "--add-qr-field") for name in add_to_qr]
    students, seen = [], set()
    for line, row in enumerate(rows[1:], 2):
        row = [c.strip() for c in row] + [""] * (len(header) - len(row))
        row = [_unmarked(c) if keys[i] in BRIGHTSPACE_IDS else c for i, c in enumerate(row[:len(header)])] + row[len(header):]
        name = row[name_i] if name_i is not None else f"{row[first_i]} {row[last_i]}".strip()
        number = row[num_i]
        if not number:
            # e.g. the "Test Student" and "Points Possible" rows of a Canvas gradebook export
            warn(f"Class list line {line} ({name or 'no name'}) was skipped: its '{header[num_i]}' column is empty.")
            continue
        if number in seen:
            raise ExamError(f"Class list line {line}: '{header[num_i]}' value {number} appears more than once.")
        seen.add(number)
        for i in [name_i, num_i, *qr_cols]:
            if i is not None and len(row[i].encode("utf-8")) > qr_payload.MAX_FIELD_BYTES:
                warn(f"Class list line {line}: '{header[i]}' is longer than {qr_payload.MAX_FIELD_BYTES} bytes "
                     f"and is cut short in the QR code.")
        students.append({
            "name": name, "number": number, "seat": row[seat_i] if seat_i is not None else "",
            "columns": {normalise_variable(h): row[i] for i, h in enumerate(header) if h},
            # every column by its header with case, spaces and punctuation removed (attendance sheet)
            "fields": {_key(h): row[i] for i, h in enumerate(header) if _key(h)},
            # extra QR values; None = the seat column, filled in later so --randomize-seats is honoured
            "qr_extra": [None if i == seat_i else row[i] for i in qr_cols],
        })
    if not students:
        raise ExamError(f"Class list '{path}' has no students.")
    name_header = header[name_i] if name_i is not None else "Student Name"
    info = {"number_column": header[num_i],
            "qr_fields": [name_header, header[num_i]] + [header[i] for i in qr_cols] + [SERIAL_FIELD]}
    return students, [normalise_variable(h) for h in header if h], info


def assign_seats(students, option, rng):
    """--randomize-seats (True): seats 1..N; --seat-labels: the comma-separated seat labels."""
    if option is True:
        seats = [str(i) for i in range(1, len(students) + 1)]
    else:
        seats = []
        for cell in split_list(option):
            if cell not in seats:
                seats.append(cell)
        if len(seats) < len(students):
            raise ExamError(f"--seat-labels lists {len(seats)} different seat(s) but the class list has "
                            f"{len(students)} students.")
    for student, seat in zip(students, rng.sample(seats, len(students))):
        student["seat"] = seat


def _natural(value):
    """Sort key that puts 'A2' before 'A10' and empty values last, and accented letters with
    their plain letter (Émilie with Emilie, not after Z), the plain one first."""
    text = value.strip().lower()
    plain = "".join(ch for ch in unicodedata.normalize("NFD", text) if not unicodedata.combining(ch))
    parts = re.findall(r"\d+|\D+", plain)
    return (not parts, [(0, int(p), "") if p.isdigit() else (1, 0, p) for p in parts], text)


def attendance_layout(students, fields, sort, seats_assigned, list_info):
    """The attendance sheet's column headers and rows (without the signature column).
    Student Name and Student Number always; the seat when --randomize-seats is used; then each
    --add-attendance-field: the class-list value when the class list has that column, else blank.
    Rows follow the class list unless --attendance-sort names columns to sort by."""
    name_keys = {"studentname", "name", "fullname"}
    number_keys = {"studentnumber", _key(list_info["number_column"] or "")}
    known = set().union(*(s["fields"] for s in students))

    def getter(label):
        k = _key(label)
        if k in name_keys:
            return lambda s: s["name"]
        if k in number_keys:
            return lambda s: s["number"]
        if k in SEAT_HEADERS:
            return lambda s: s["seat"]
        if k in known:
            return lambda s: s["fields"].get(k, "")
        return None

    columns = [("Student Name", getter("Student Name")), ("Student Number", getter("Student Number"))]
    if seats_assigned and not any(_key(f) in SEAT_HEADERS for f in fields):
        columns.append(("Seat", getter("Seat")))
    seen = {"studentname", "studentnumber"} | ({"seat"} if len(columns) == 3 else set())
    for label in fields:
        k = _key(label)
        if not k or k in seen or k in name_keys | number_keys:
            continue
        seen.add(k if k not in SEAT_HEADERS else "seat")
        columns.append((label, getter(label) or (lambda s: "")))
    keys = []
    for label in sort:
        # "Seat desc" or "-Seat": that column in reverse order
        m = re.match(r"^(-)?\s*(.*?)(?:\s+(desc|descending|asc|ascending))?$", label.strip(), re.I)
        descending = bool(m.group(1)) or (m.group(3) or "").lower().startswith("desc")
        label = m.group(2)
        g = getter(label)
        if g is None:
            shown = ", ".join(c for c, _ in columns)
            raise ExamError(f"--attendance-sort: there is no column '{label}' on the attendance sheet or in the class "
                            f"list. The sheet's columns are: {shown}.")
        keys.append((g, descending))
    ordered = list(students)
    for g, descending in reversed(keys):        # stable sorts, least important column first
        ordered.sort(key=lambda s: _natural(g(s)), reverse=descending)
        if descending:                           # empty values stay last
            ordered = [s for s in ordered if g(s).strip()] + [s for s in ordered if not g(s).strip()]
    shown = {"Student Name": t("student_name"), "Student Number": t("student_number_column"), "Seat": t("seat")}
    return [shown.get(c, c) for c, _ in columns], [[g(s) for _, g in columns] for s in ordered]
