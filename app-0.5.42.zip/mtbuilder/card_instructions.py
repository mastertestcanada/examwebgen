"""The instructions printed on answer cards and merged quiz sheets (--answer-card-instructions).

They come from an HTML file, rendered exactly like question text (the same tags, fonts, sizes,
colours and images; images are looked up next to the file). Parts that apply only to some cards
carry a data-show attribute naming when they are printed, for example

    <span data-show="blank">Write your student number ...</span>

data-show lists one or more conditions, all of which must hold; "!name" means "not name":
    card      a full-page answer card            single   the answer area of a single-page quiz
    merged    a merged quiz sheet                 compact  single-page quiz for a named student
    blank     a blank card (handwritten ID)       named    a card printed for a named student
    written   the card has number or text boxes
    seat      the card has seat boxes (not --no-seat)
"""
import base64
import io
from pathlib import Path

import lxml.html
from PIL import Image, ImageDraw

from . import i18n
from .errors import ExamError
from .html_render import HtmlRenderer

FILE_NAME = "answerCardInstructions.html"
DEFAULT_PATH = Path(__file__).resolve().parent.parent / FILE_NAME   # next to mastertest_builder.py


def default_path():
    """The shipped instructions for the print language: answerCardInstructions.fr.html for French."""
    lang = i18n.language()
    if lang != "en":
        p = DEFAULT_PATH.with_name(f"answerCardInstructions.{lang}.html")
        if p.is_file():
            return p
    return DEFAULT_PATH

# The example bubbles shown in the instructions ("Correct: (filled)  Incorrect: (x) (check) (dot)"),
# drawn like the card's own bubbles: radius 5.6 pt, 0.7 pt outline, centred on a 15 x 12 pt image
# (15 pt apart when placed side by side, as on the card).
BUBBLES = ("filled", "cross", "check", "dot")
BUBBLE_FOLDER = "images"        # next to answerCardInstructions.html


def bubble_png(kind, dpi=600):
    """PNG bytes of one example bubble."""
    k = 4 * dpi / 72                         # supersampled pixels per point
    wide, size = round(15 * k), round(12 * k)
    im = Image.new("L", (wide, size), 255)
    d = ImageDraw.Draw(im)
    c, r, lw = size / 2, 5.6 * k, 0.7 * k
    off = (wide - size) / 2
    d = _Shifted(d, off)
    d.ellipse((c - r - lw / 2, c - r - lw / 2, c + r + lw / 2, c + r + lw / 2), fill=0)
    if kind != "filled":
        d.ellipse((c - r + lw / 2, c - r + lw / 2, c + r - lw / 2, c + r - lw / 2), fill=255)
    a = 3.5 * k                               # y grows downward here
    if kind == "cross":
        d.line((c - a, c + a, c + a, c - a), fill=0, width=round(lw))
        d.line((c - a, c - a, c + a, c + a), fill=0, width=round(lw))
    elif kind == "check":
        d.line((c - a, c + 1 * k, c - 1 * k, c + a), fill=0, width=round(lw))
        d.line((c - 1 * k, c + a, c + 4 * k, c - a), fill=0, width=round(lw))
    elif kind == "dot":
        d.ellipse((c - 1.6 * k, c - 1.6 * k, c + 1.6 * k, c + 1.6 * k), fill=0)
    im = im.resize((wide // 4, size // 4), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "PNG", dpi=(dpi, dpi))
    return buf.getvalue()


class _Shifted:
    """Draws with every x moved right by `dx` (to centre a square drawing on a wider image)."""

    def __init__(self, draw, dx):
        self.draw, self.dx = draw, dx

    def _move(self, xy):
        return tuple(v + self.dx if i % 2 == 0 else v for i, v in enumerate(xy))

    def ellipse(self, xy, **kw):
        self.draw.ellipse(self._move(xy), **kw)

    def line(self, xy, **kw):
        self.draw.line(self._move(xy), **kw)


def examples_html(src):
    """The "Correct / Incorrect" line; `src(kind)` gives each image's src."""
    img = lambda kind, alt: f'<img src="{src(kind)}" width="15pt" height="12pt" alt="{alt}"/>'
    return ('<p>Correct: ' + img("filled", "filled bubble")
            + ' &#160; Incorrect: ' + img("cross", "crossed bubble") + img("check", "ticked bubble")
            + img("dot", "dotted bubble") + "</p>")


# Used when the default file is missing: the same text as the shipped answerCardInstructions.html,
# with the example bubbles built in.
BUILT_IN = (
    '<p data-show="!merged">'
    '<span data-show="blank seat">Write your student number and seat in the boxes and fill in the matching bubbles. </span>'
    '<span data-show="blank !seat">Write your student number in the boxes and fill in the matching bubbles. </span>'
    '<span data-show="!compact">Fill in bubbles completely with a dark pen or pencil. Erase changes cleanly. '
    'Do not fold the card or write on the QR code or the black squares.</span>'
    '<span data-show="compact">Fill in bubbles completely with a dark pen or pencil. '
    'Do not write on the QR code or the black squares.</span>'
    '<span data-show="written"> Print written answers inside their box; for numbers, one digit, - or [[DECIMAL MARK]] per cell.</span>'
    '</p>'
    + '<p data-show="merged"><span data-show="blank seat">Write your student number and seat in the boxes and fill in the '
    'matching bubbles. </span><span data-show="blank !seat">Write your student number in the boxes and fill in the matching '
    'bubbles. </span>Fill bubbles completely. Numbers: one digit, - or [[DECIMAL MARK]] per cell. Short answers inside the box. '
    'Keep the QR code and black squares clean.</p>'
    + examples_html(lambda kind: "data:image/png;base64," + base64.b64encode(bubble_png(kind)).decode("ascii"))
)


class CardInstructions:
    """The instruction HTML and the folder its images are found in."""

    def __init__(self, html, root):
        self.html = html.replace("[[DECIMAL MARK]]", "," if i18n.decimal_comma() else ".")
        self.root = Path(root) if root else None

    @classmethod
    def load(cls, path=None):
        """`path`: --answer-card-instructions, or None for answerCardInstructions.html next to the
        program (the built-in text if that file is missing). "None" or "" prints no instructions."""
        if path is not None and str(path).strip().lower() in ("", "none"):
            return cls("", None)
        if path is None:
            path = default_path()
            if not path.is_file():
                return cls(BUILT_IN, None)
        p = Path(path)
        if not p.is_file():
            raise ExamError(f"--answer-card-instructions: file not found: {path}")
        try:
            text = p.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeDecodeError) as exc:
            raise ExamError(f"--answer-card-instructions: cannot read {path}: {exc}")
        return cls(text, p.resolve().parent)

    def html_for(self, conditions):
        """The HTML with every element whose data-show does not hold for `conditions` removed."""
        if not self.html.strip():
            return ""
        try:
            root = lxml.html.fragment_fromstring(self.html, create_parent="div")
        except Exception:
            return self.html
        for el in list(root.iter()):
            if not isinstance(el.tag, str):
                continue
            show = el.get("data-show")
            if show is None:
                continue
            ok = all((w[1:] not in conditions) if w.startswith("!") else (w in conditions) for w in show.split())
            if not ok:
                _remove(el)
        out = (root.text or "") + "".join(lxml.html.tostring(ch, encoding="unicode") for ch in root)
        return out

    def flowables(self, fonts, family, size, width, conditions):
        if not self.html.strip():
            return []
        renderer = HtmlRenderer(fonts, family, size, self.root)
        return renderer.render(self.html_for(conditions), width)


def _remove(el):
    """Remove an element but keep the text that follows it."""
    parent = el.getparent()
    if parent is None:
        return
    tail = el.tail or ""
    prev = el.getprevious()
    if prev is not None:
        prev.tail = (prev.tail or "") + tail
    else:
        parent.text = (parent.text or "") + tail
    parent.remove(el)


def height(flowables, width):
    total = 0.0
    for i, f in enumerate(flowables):
        _w, h = f.wrap(width, 100000)
        total += h + (f.getSpaceBefore() if i else 0) + (f.getSpaceAfter() if i < len(flowables) - 1 else 0)
    return total


def draw(c, flowables, x, top, width):
    """Draws the flowables from `top` downward; returns the height used."""
    y = top
    for i, f in enumerate(flowables):
        _w, h = f.wrap(width, 100000)
        if i:
            y -= f.getSpaceBefore()
        f.drawOn(c, x, y - h)
        y -= h + (f.getSpaceAfter() if i < len(flowables) - 1 else 0)
    return top - y
