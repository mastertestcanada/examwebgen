"""Putting the PDFs together: booklets, imposed folded sheets, answer cards, and making the
booklets in parallel."""

import io
import re
import sys

from pypdf import PageObject, PdfReader, PdfWriter, Transformation

from . import __app_name__, __version__


_PARALLEL = None     # the function parallel_map's worker processes call (inherited when they fork)


def _parallel_call(i):
    return _PARALLEL[0](_PARALLEL[1][i])


def parallel_map(func, items):
    """[func(item) for item in items], in order, as a generator. On a desktop that can fork, several
    items are made at once in worker processes (each exam booklet is independent of the others);
    in the browser, on Windows, or for a few items, one after another. Results arrive in order."""
    global _PARALLEL
    import multiprocessing
    import os
    workers = min(os.cpu_count() or 1, 8, len(items) // 3)
    if workers < 2 or sys.platform == "emscripten" or "fork" not in multiprocessing.get_all_start_methods():
        for item in items:
            yield func(item)
        return
    _PARALLEL = (func, items)
    try:
        with multiprocessing.get_context("fork").Pool(workers) as pool:
            yield from pool.imap(_parallel_call, range(len(items)))
    finally:
        _PARALLEL = None


def safe_name(text, limit=80):
    text = re.sub(r"[^\w\-]+", "_", str(text), flags=re.UNICODE).strip("_")
    return text[:limit] or "untitled"


def new_writer():
    w = PdfWriter()
    w.add_metadata({"/Producer": f"{__app_name__} {__version__}"})
    return w


DUPLEX_CARD_PAGES = 4   # one folded sheet: the hard limit is 4 x 100 questions


def impose(writer, pages, pagesize):
    """Lay portrait pages two-up on landscape sheets of twice the width, in the order that
    makes a booklet when the printed sheets are stacked and folded down the middle.

    `pages` holds the booklet pages in reading order (None = blank) and its length is a
    multiple of four. Sheet s (counting from 0) of an N-page booklet carries
        front:  page N-2s      | page 1+2s
        back:   page 2+2s      | page N-1-2s
    so a 4-page booklet is  4|1  then  2|3.  Print double-sided, flipping on the short edge."""
    width, height = pagesize
    n = len(pages)
    for s in range(n // 4):
        for left, right in ((pages[n - 1 - 2 * s], pages[2 * s]), (pages[2 * s + 1], pages[n - 2 - 2 * s])):
            sheet = PageObject.create_blank_page(width=2 * width, height=height)
            if left is not None:
                sheet.merge_page(left)
            if right is not None:
                sheet.merge_transformed_page(right, Transformation().translate(width, 0))
            writer.add_page(sheet)


def add_booklet(writer, pdf, pagesize, pad_title, pad_exam, duplex=False):
    """Append an exam booklet, inserting the blank pages asked for by padTitlePage / padExam.
    With `duplex` the booklet is imposed on folded sheets and always ends on a blank page."""
    if duplex:
        pages = list(PdfReader(io.BytesIO(pdf)).pages)
        if pad_title:
            pages.insert(1, None)
        pages.append(None)                 # the back cover is always blank
        while len(pages) % 4:
            pages.append(None)
        impose(writer, pages, pagesize)
        return
    start = len(writer.pages)
    writer.append(PdfReader(io.BytesIO(pdf)))
    if pad_title:
        writer.insert_blank_page(pagesize[0], pagesize[1], start + 1)
    if pad_exam:
        count = len(writer.pages) - start
        for _ in range(2 if count % 2 == 0 else 1):
            writer.add_blank_page(pagesize[0], pagesize[1])


def add_card(writer, pdf, pagesize, pad, duplex=False, whole=False):
    """Append answer card(s); with `pad`, a blank page follows every card.
    With `whole` (a merged or single-page quiz, one student's pages), `pad` instead adds one blank
    page only when the quiz has an odd number of pages, so that printed double-sided every quiz
    starts on a new sheet and its own sheets are printed on both sides.
    With `duplex` the cards become one folded sheet, always four pages."""
    if duplex:
        pages = list(PdfReader(io.BytesIO(pdf)).pages)
        pages += [None] * (DUPLEX_CARD_PAGES - len(pages))
        impose(writer, pages, pagesize)
        return
    pages = PdfReader(io.BytesIO(pdf)).pages
    for page in pages:
        writer.add_page(page)
        if pad and not whole:
            writer.add_blank_page(pagesize[0], pagesize[1])
    if pad and whole and len(pages) % 2:
        writer.add_blank_page(pagesize[0], pagesize[1])


def save(writer, path):
    with open(path, "wb") as fh:
        writer.write(fh)


def progress(what, done, total):
    from .progress import report
    report(what, done, total)
