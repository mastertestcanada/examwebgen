"""Binary payloads of the QR codes, MasterTest QR format 1 (MasterTest Builder 0.4.6 and later;
all integers big-endian). Codes printed by MasterTest Builder use other schema numbers and
are not read.

ANSWER CARD - schema 0x10 (a full-page answer card, a single-page quiz, or one sheet of a merged quiz)
    1 byte   schema        0x10
    1 byte   flags         bit 0: 1 = blank card (the student fills in name and number)
                           bit 1: paper size, 0 = letter, 1 = A4
                           bit 2: 1 = padded: every multiple-choice question has as many bubbles
                                  as the quiz's question with the most printed options
                                  (the reader works the number out from the answer key)
                           bit 3: 1 = written-answer cells are shaded, not outlined
    4 bytes  hash          CRC-32 of the quiz identifier (UTF-8); at bytes 2-5 in every payload
    1 byte   kind          0 = full-page answer card, 1 = single-page quiz, 2 = merged sheet
    1 byte   answer width  width of the written-answer boxes in whole points (--answer-width);
                           0 = the default for the layout. On merged sheets bubble size and box
                           height scale with min(width, 120) / 90.
    1 byte   index         0 for the first card (or sheet) of an exam, 1 for the second, ...
                           A full-page card holds questions index x (answers per card) + 1 onward.
    1 byte   field count   number of data fields that follow
    variable data fields   each is 1 length byte followed by that many bytes of UTF-8.
                           Class-list cards: student name, student number, the --add-qr-field
                           columns in the order given, then the card serial ("Card serial").
                           Blank cards: a single field, the card's 12-digit serial.
                           The field names are in the answer key, in the same order.
    2 bytes  first number  merged sheets only: the number printed beside the sheet's first question
    2 bytes  questions     number of questions printed on this card or sheet
    variable question map  for each question, in printed order:
                             Q bits  index of the question in the pre-randomized order
                             then, depending on the question's kind in the answer key:
                               choice:  L bits  Lehmer code of the option shuffle
                               numeric: V bits  which worked example (value set) was printed;
                                        V = bits needed for (number of answers in the key - 1)
                               text:    nothing
                           packed most-significant bit first, zero padded to a byte.
    rest     positions     merged sheets only: 2 bytes per question, bit 15 the column (0 left,
                           1 right), bits 0-14 the height of the centre of its answer below the
                           top of the page in tenths of a point. The answer area of a column ends
                           at its right edge; bubbles end there too, boxes fill it.

Q is the number of bits needed for the largest question index in the export
(every usable question, including all item-bank questions).
L is the number of bits needed for n! - 1, where n is the number of options the
question has in the export (including options that are empty and not printed).
The shuffle is a permutation p of 0..n-1 where p[i] is the pre-randomized
position of the option in slot i; empty options keep their slot in p but are
skipped when lettering, so printed letter k is the k-th non-empty entry of p.

ANSWER KEY - schema 0x11
    1 byte   schema        0x11
    1 byte   flags         reserved, 0
    4 bytes  hash          CRC-32 of the quiz identifier (same value as on the cards)
    variable exam name     1 length byte followed by that many bytes of UTF-8
    1 byte   field count   number of field names that follow
    variable field names   the names of the data fields on class-list cards, in card order
    2 bytes  questions     number of questions N in the pre-randomized order
    N records, record j describing question j+1 (index j), starting with a kind byte:
      0 choice:  n options in the export (1), present mask (1: bit i = pre-randomized option i
                 is printed), correct mask (1), points x 100 (2)
      1 numeric: points x 100 (2), tolerance kind (1: 0 = absolute, 1 = percent),
                 tolerance (length byte + text), answer count (1), answers (length byte + text each);
                 the card says which answer applies to the student
      2 text:    points x 100 (2), answer count (1), accepted answers (length byte + text each)

PASSWORD-PROTECTED ANSWER KEY - schema 0x18   (--password)
    1 byte   schema        0x18
    1 byte   flags         reserved, 0
    4 bytes  hash          CRC-32 of the quiz identifier (same value as on the cards)
    variable exam name     1 length byte followed by that many bytes of UTF-8 (not secret:
                           it lets the marking app say which exam it wants a password for)
    12 bytes nonce
    rest     ciphertext    AES-256-GCM, 16-byte tag at the end

    associated data = all bytes before the nonce (schema, flags, hash, exam name)
    AES key    = PBKDF2-HMAC-SHA256( password as UTF-8, salt = the associated data,
                                     600,000 iterations, 32 bytes )
                 The salt contains the quiz hash and exam name, so the same password
                 gives a different key for every exam.
    plaintext  = everything in a schema 0x11 payload after the exam name
    nonce      = first 12 bytes of SHA-256( AES key || associated data || plaintext )
    Decrypting and putting 0x11, 0x00, hash and exam name in front of the plaintext gives an
    ordinary answer key. The GCM tag fails when the password is wrong.
"""

import hashlib
import zlib
from math import factorial

CARD_SCHEMA = 0x10
KEY_SCHEMA = 0x11
PROTECTED_KEY_SCHEMA = 0x18
CARD, SINGLE_PAGE, MERGED = 0, 1, 2      # the kind byte of a card
KINDS = {CARD: "card", SINGLE_PAGE: "single_page", MERGED: "merged"}
NONCE_BYTES = 12
KEY_FIXED_BYTES = 10   # schema, flags, hash, name length, field count, question count
MAX_FIELD_BYTES = 255
CARD_FIXED_BYTES = 12  # schema, flags, hash, kind, width, index, field count, question count


def index_bits(pool_size):
    """Bits used for an original question index (Q)."""
    return max(1, (max(pool_size, 1) - 1).bit_length())


def lehmer_bits(n):
    return (factorial(n) - 1).bit_length()


def lehmer_encode(perm):
    n, value = len(perm), 0
    for i, p in enumerate(perm):
        smaller = sum(1 for q in perm[i + 1:] if q < p)
        value += smaller * factorial(n - 1 - i)
    return value


def lehmer_decode(value, n):
    pool, perm = list(range(n)), []
    for i in range(n):
        f = factorial(n - 1 - i)
        perm.append(pool.pop(value // f))
        value %= f
    return perm


def quiz_hash(quiz_ident):
    return zlib.crc32(quiz_ident.encode("utf-8")) & 0xFFFFFFFF


def pack_field(text):
    """One length-prefixed string: a length byte, then up to 255 bytes of UTF-8."""
    raw = str(text).encode("utf-8")[:MAX_FIELD_BYTES]
    while True:  # never cut a multi-byte character in half
        try:
            raw.decode("utf-8")
            break
        except UnicodeDecodeError:
            raw = raw[:-1]
    return bytes([len(raw)]) + raw


def value_bits(count):
    """Bits used for the worked-example index of a calculated question with `count` examples."""
    return max(count - 1, 0).bit_length()


def entry_field(kind, perm, size):
    """(value, bit count) stored after the question index on a card.
    choice: Lehmer code of the option shuffle; numeric: index of the worked example; text: nothing."""
    if kind == "numeric":
        return perm[0], value_bits(size)
    if kind == "text":
        return 0, 0
    return lehmer_encode(perm), lehmer_bits(len(perm))


def encode(quiz_ident, blank, fields, entries, pool_size, index=0, kind=CARD, a4=False, padded=False,
           shaded=False, answer_width=None, first_number=None, spots=()):
    """One answer card or merged sheet. fields: the data-field values; entries: (pre-randomized
    question index, value, bit count) for each question printed (see entry_field); merged sheets:
    first_number and spots [(column, y from the top)] for every question."""
    if not 0 <= index <= 255:
        raise ValueError("card index must be 0-255")
    if len(fields) > 255:
        raise ValueError("at most 255 data fields fit in the QR code")
    width = 0 if answer_width is None else answer_width
    if not 0 <= width <= 255 or width != int(width):
        raise ValueError("the answer width must be a whole number of points, 1-255")
    flags = (1 if blank else 0) | (2 if a4 else 0) | (4 if padded else 0) | (8 if shaded else 0)
    out = bytes([CARD_SCHEMA, flags]) + quiz_hash(quiz_ident).to_bytes(4, "big") + bytes([kind, int(width), index])
    out += bytes([len(fields)]) + b"".join(pack_field(f) for f in fields)
    if kind == MERGED:
        out += int(first_number).to_bytes(2, "big")
    out += len(entries).to_bytes(2, "big")
    qbits = index_bits(pool_size)
    acc, nbits = 0, 0
    for q_index, value, bits in entries:
        acc = (acc << qbits) | q_index
        acc = (acc << bits) | value
        nbits += qbits + bits
    pad = (-nbits) % 8
    out += (acc << pad).to_bytes((nbits + pad) // 8, "big")
    if kind == MERGED:
        if len(spots) != len(entries):
            raise ValueError("a merged sheet needs one answer position per question")
        for col, y in spots:
            tenths = round(y * 10)
            if not 0 <= tenths < 0x8000 or col not in (0, 1):
                raise ValueError("answer position out of range")
            out += ((col << 15) | tenths).to_bytes(2, "big")
    return out


def decode(data, questions):
    """Inverse of encode(). questions: the answer key's question dicts (decode_key()["questions"])."""
    if len(data) < CARD_FIXED_BYTES or data[0] != CARD_SCHEMA or data[6] not in KINDS:
        raise ValueError("not a MasterTest answer-card payload (schema 0x10)")
    kind, flags = data[6], data[1]
    pos = 10
    fields = []
    for _ in range(data[9]):
        length = data[pos]
        fields.append(data[pos + 1:pos + 1 + length].decode("utf-8", "replace"))
        pos += 1 + length
    first_number = None
    if kind == MERGED:
        first_number = int.from_bytes(data[pos:pos + 2], "big")
        pos += 2
    count = int.from_bytes(data[pos:pos + 2], "big")
    pos += 2
    qbits = index_bits(len(questions))
    stream = int.from_bytes(data[pos:], "big")
    remaining = (len(data) - pos) * 8
    entries = []
    for _ in range(count):
        remaining -= qbits
        index = (stream >> remaining) & ((1 << qbits) - 1)
        q = questions[index]
        bits = (value_bits(len(q["answers"])) if q["kind"] == "numeric" else 0 if q["kind"] == "text"
                else lehmer_bits(q["options"]))
        remaining -= bits
        code = (stream >> remaining) & ((1 << bits) - 1)
        entries.append((index, [code] if q["kind"] == "numeric" else [] if q["kind"] == "text"
                        else lehmer_decode(code, q["options"])))
    spots = None
    if kind == MERGED:
        at = pos + ((len(data) - pos) * 8 - remaining + 7) // 8
        spots = []
        for k in range(count):
            v = int.from_bytes(data[at + 2 * k:at + 2 * k + 2], "big")
            spots.append((v >> 15, (v & 0x7FFF) / 10))
    return {
        "kind": KINDS[kind],
        "merged": kind == MERGED,
        "single_page": kind == SINGLE_PAGE,
        "first_number": first_number,
        "spots": spots,
        "answer_width": data[7] or None,
        "index": data[8],
        "blank": bool(flags & 1),
        "a4": bool(flags & 2),
        "padded": bool(flags & 4),
        "shaded": bool(flags & 8),
        "hash": int.from_bytes(data[2:6], "big"),
        "fields": fields,
        "entries": entries,
    }


KEY_DECIMAL_COMMA = 0x01   # key flags: the exam was printed with the decimal comma (display only)


def encode_key(quiz_ident, records, field_names=(), title="", decimal_comma=False):
    """records: ("choice", n, present, correct, points) | ("numeric", points, percent, tolerance,
    [answers]) | ("text", points, [answers]); field_names: the data fields on class-list cards."""
    if len(field_names) > 255:
        raise ValueError("at most 255 field names fit in the QR code")
    flags = KEY_DECIMAL_COMMA if decimal_comma else 0
    out = bytes([KEY_SCHEMA, flags]) + quiz_hash(quiz_ident).to_bytes(4, "big") + pack_field(title)
    out += bytes([len(field_names)]) + b"".join(pack_field(n) for n in field_names)
    out += len(records).to_bytes(2, "big")
    for rec in records:
        kind = rec[0]
        points = rec[1] if kind != "choice" else rec[4]
        hundredths = round((points or 0) * 100)
        if not 0 <= hundredths <= 0xFFFF:
            raise ValueError(f"point value {points} cannot be stored (0 to 655.35)")
        if kind == "choice":
            out += bytes([0, rec[1], rec[2], rec[3]]) + hundredths.to_bytes(2, "big")
        elif kind == "numeric":
            _, _, percent, tolerance, answers = rec
            out += bytes([1]) + hundredths.to_bytes(2, "big") + bytes([1 if percent else 0]) + pack_field(tolerance)
            out += bytes([len(answers)]) + b"".join(pack_field(a) for a in answers)
        else:
            answers = rec[2][:255]
            out += bytes([2]) + hundredths.to_bytes(2, "big") + bytes([len(answers)])
            out += b"".join(pack_field(a) for a in answers)
    return out


def decode_key(data):
    if len(data) < KEY_FIXED_BYTES or data[0] != KEY_SCHEMA:
        raise ValueError("not a MasterTest answer-key payload (schema 0x11)")
    pos = 6

    def byte():
        nonlocal pos
        pos += 1
        return data[pos - 1]

    def u16():
        nonlocal pos
        pos += 2
        return int.from_bytes(data[pos - 2:pos], "big")

    def string():
        nonlocal pos
        length = byte()
        pos += length
        return data[pos - length:pos].decode("utf-8", "replace")

    title = string()
    names = [string() for _ in range(byte())]
    questions = []
    for j in range(u16()):
        kind = byte()
        if kind == 0:
            n, present, correct = byte(), byte(), byte()
            questions.append({"number": j + 1, "kind": "choice", "options": n, "points": u16() / 100,
                              "present": [i for i in range(n) if present >> i & 1],
                              "correct": [i for i in range(n) if correct >> i & 1]})
        elif kind == 1:
            points = u16() / 100
            percent = bool(byte())
            tolerance = string()
            answers = [string() for _ in range(byte())]
            questions.append({"number": j + 1, "kind": "numeric", "options": 0, "points": points,
                              "percent": percent, "tolerance": tolerance, "answers": answers})
        else:
            points = u16() / 100
            answers = [string() for _ in range(byte())]
            questions.append({"number": j + 1, "kind": "text", "options": 0, "points": points, "answers": answers})
    return {"hash": int.from_bytes(data[2:6], "big"), "title": title, "field_names": names, "questions": questions,
            "decimal_comma": bool(data[1] & KEY_DECIMAL_COMMA)}


KDF_ITERATIONS = 600_000


def _aes_key(password, header):
    """Deliberately slow, so that guessing passwords against a photographed key is expensive."""
    if hasattr(hashlib, "pbkdf2_hmac"):
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), header, KDF_ITERATIONS, 32)
    # Python in the browser (Pyodide) has no hashlib.pbkdf2_hmac; the same derivation from cryptography
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=header, iterations=KDF_ITERATIONS).derive(
        password.encode("utf-8"))


def _aesgcm(key):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        raise RuntimeError("--password needs the 'cryptography' package: pip install cryptography")
    return AESGCM(key)


def protect_key(payload, password):
    """Encrypt a schema 0x11 answer-key payload into a schema 0x18 one."""
    if payload[0] != KEY_SCHEMA:
        raise ValueError("not a MasterTest answer-key payload (schema 0x11)")
    name_end = 7 + payload[6]
    header = bytes([PROTECTED_KEY_SCHEMA, 0]) + payload[2:name_end]
    plain = payload[name_end:]
    key = _aes_key(password, header)
    # Derived from the content, so the same key sheet is reproducible and a different
    # sheet under the same password never reuses a nonce.
    nonce = hashlib.sha256(key + header + plain).digest()[:NONCE_BYTES]
    return header + nonce + _aesgcm(key).encrypt(nonce, plain, header)


def unprotect_key(data, password):
    """Inverse of protect_key(); raises ValueError when the password is wrong."""
    if data[0] != PROTECTED_KEY_SCHEMA:
        raise ValueError("not a password-protected MasterTest answer key (schema 0x18)")
    name_end = 7 + data[6]
    header = data[:name_end]
    nonce = data[name_end:name_end + NONCE_BYTES]
    try:
        plain = _aesgcm(_aes_key(password, header)).decrypt(nonce, data[name_end + NONCE_BYTES:], header)
    except Exception:
        raise ValueError("wrong password, or the answer key is damaged")
    return bytes([KEY_SCHEMA, 0]) + data[2:name_end] + plain
