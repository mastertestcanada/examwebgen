"""Glue for the in-browser version (web/): describes the command-line options so the page can
build its form from them, runs the program on files held in memory, and zips the result.

Everything here runs inside the visitor's browser (Pyodide). Input and output live in the
in-memory file system under /work, which disappears when the page is closed.
"""
import argparse
import io
import json
import os
import re
import contextlib
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

from . import __version__, canvas, cli, errors
from .errors import ExamError

WORK = Path("/work")
INPUT = WORK / "in"
OUTPUT = WORK / "out"
# options the page handles itself or does not show
HIDDEN = {"-h", "--help", "--version", "--list-quizzes", "--output", "-o", "--password"}


def _kind(action):
    if isinstance(action, argparse.BooleanOptionalAction):
        return "bool"
    if isinstance(action, argparse._StoreTrueAction):
        return "flag"
    if action.choices:
        return "choice"
    if action.metavar and "filename" in str(action.metavar):
        return "file"
    if action.type in (int, float):
        return "number"
    return "text"


def spec():
    """The options as JSON, grouped as in --help, for building the form."""
    parser = cli.build_parser()
    exclusive = {}
    for n, group in enumerate(parser._mutually_exclusive_groups):
        for a in group._group_actions:
            exclusive[id(a)] = n
    groups = []
    for group in parser._action_groups:
        options = []
        for a in group._group_actions:
            names = a.option_strings
            if not names:          # the export, chosen separately
                continue
            name = next((s for s in names if s.startswith("--")), names[0])
            if name in HIDDEN or a.help == argparse.SUPPRESS:
                continue
            kind, choices = _kind(a), [str(c) for c in a.choices] if a.choices else None
            if name == "--page-size":   # accepts many spellings; the form offers the canonical names
                kind, choices = "choice", list(dict.fromkeys(v[0] for v in cli.PAGE_SIZES.values()))
            options.append({
                "name": name, "kind": kind, "help": (a.help or "").replace("%%", "%"),
                "default": a.default if isinstance(a.default, (str, int, float, bool)) else None,
                "choices": choices,
                "metavar": str(a.metavar) if a.metavar else None,
                "exclusive": exclusive.get(id(a)),
            })
        if options:
            groups.append({"title": group.title, "options": options})
    return json.dumps({"version": __version__, "groups": groups})


def reset():
    """Empties /work (the files of the last run) and makes it ready for the next. Also removes the
    folders exports were unpacked into (on the desktop they go when the program exits, but the
    browser's worker keeps running) and forgets which warnings were shown, so each run shows its own."""
    global _export
    _export = None
    os.chdir("/")
    shutil.rmtree(WORK, ignore_errors=True)
    for tmp in Path(tempfile.gettempdir()).glob("examgen_*"):
        shutil.rmtree(tmp, ignore_errors=True)
    errors._seen.clear()
    INPUT.mkdir(parents=True, exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    os.chdir(INPUT)


def run(argv, password=""):
    """Runs MasterTest Generator on the files in /work/in; returns the exit code. The password, if
    --password is used, is read from standard input as in a script."""
    os.chdir(INPUT)
    old_stdin = sys.stdin
    sys.stdin = io.StringIO(password + "\n")
    try:
        return cli.main(list(argv) + ["--output", str(OUTPUT)])
    except SystemExit as exc:          # argparse after --help and the like
        return exc.code if isinstance(exc.code, int) else 1
    finally:
        sys.stdin = old_stdin


def output_zip():
    """(file name, zip bytes) of everything the run wrote."""
    title = "exam_generator_output"
    manifest = OUTPUT / "manifest.json"
    if manifest.exists():
        title = cli.safe_name(json.loads(manifest.read_text(encoding="utf-8"))["quiz"]["title"], 80)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(OUTPUT.rglob("*")):
            if path.is_file():
                z.write(path, f"{title}/{path.relative_to(OUTPUT)}")
    seed = json.loads(manifest.read_text(encoding="utf-8")).get("seed") if manifest.exists() else None
    return f"{title}.zip", buf.getvalue(), "" if seed is None else str(seed)


# ---------------------------------------------------------------- reading a class list before a run

def classlist(path, student_id_column="", add_qr=""):
    """JSON: what the class list at `path` holds and how the program reads it with these options:
    its columns, the student-name and student-number columns, the QR fields, the number of
    students and the rows skipped; {"error": ..., "columns": [...]} when it cannot be used."""
    stderr = io.StringIO()
    try:
        rows = [r for r in cli._read_csv(path, "class list") if any(c.strip() for c in r)]
    except ExamError as exc:
        return json.dumps({"error": str(exc), "columns": []})
    except Exception as exc:  # not text at all
        return json.dumps({"error": f"This file could not be read as a class list ({exc}).", "columns": []})
    if not rows:
        return json.dumps({"error": "The class list is empty.", "columns": []})
    header = [h.strip() for h in rows[0]]
    columns = [h for h in header if h]
    keys = [cli._key(h) for h in header]
    found = cli.find_number_column(header, rows[1:])
    detected = header[found] if found is not None else None
    name = next((header[keys.index(n)] for n in cli.NAME_HEADERS if n in keys), None)
    if name is None and any(k in keys for k in ("firstname", "first")) and any(k in keys for k in ("lastname", "last", "surname")):
        first = header[keys.index(next(k for k in ("firstname", "first") if k in keys))]
        last = header[keys.index(next(k for k in ("lastname", "last", "surname") if k in keys))]
        name = f"{first} + {last}"
    seat = next((header[keys.index(n)] for n in cli.SEAT_HEADERS if n in keys), None)
    base = {"columns": columns, "detected_number_column": detected, "name_column": name, "seat_column": seat,
            "rows": len(rows) - 1}
    try:
        with contextlib.redirect_stderr(stderr):
            students, _cols, info = cli.read_classlist(path, student_id_column or None, cli.split_list(add_qr))
    except ExamError as exc:
        return json.dumps({**base, "error": str(exc).replace(f"Class list '{path}'", "The class list")
                           .replace("(or name one with --student-id-column)", "(choose its student ID column under Class list options)"),
                           "warnings": _warnings(stderr)})
    warnings = _warnings(stderr)
    return json.dumps({**base, "students": len(students), "number_column": info["number_column"],
                       "qr_fields": info["qr_fields"], "warnings": warnings,
                       "skipped": sum(1 for w in warnings if "was skipped" in w),
                       "seats_in_list": sum(1 for s in students if s["seat"])})


# ---------------------------------------------------------------- reading an export before a run

_export = None     # (file name, unpacked folder, [QuizInfo]) of the export last inspected


def _open(name):
    global _export
    if _export is None or _export[0] != name:
        root = canvas.open_export(INPUT / name)
        _export = (name, root, canvas.list_quizzes(root))
    return _export


def quizzes(name):
    """JSON: the quizzes in the export /work/in/<name>, or {"error": message}."""
    try:
        _name, _root, found = _open(name)
    except ExamError as exc:
        message = str(exc)
        if "neither a folder nor a zip file" in message:
            message = "This is not a .zip file. In Canvas, export the quiz as a QTI .zip file."
        elif "No quizzes were found" in message:
            message = "This .zip file holds no Canvas quiz. In Canvas, export the quiz as a QTI .zip file."
        return json.dumps({"error": message})
    except Exception as exc:  # a damaged zip and the like
        return json.dumps({"error": f"This file could not be read as a Canvas quiz export ({exc})."})
    return json.dumps({"quizzes": [{"number": q.number, "title": q.title} for q in found]})


def summary(name, number):
    """JSON: what quiz `number` of the export holds, for the page to show before Generate:
    question count and types, questions left out (with the program's warnings), the largest
    number of options, and how many questions a student gets when item banks are used."""
    stderr = io.StringIO()
    try:
        _name, root, found = _open(name)
        info = found[number - 1]
        with contextlib.redirect_stderr(stderr):
            quiz = canvas.load_quiz(root, info)
    except ExamError as exc:
        return json.dumps({"error": str(exc), "warnings": _warnings(stderr)})
    kinds = {"multiple choice": 0, "multiple answer": 0, "true/false": 0, "calculated": 0, "fill in the blank": 0}
    for q in quiz.questions:
        if q.kind == "numeric":
            kinds["calculated"] += 1
        elif q.kind == "text":
            kinds["fill in the blank"] += 1
        elif q.qtype == "true_false_question":
            kinds["true/false"] += 1
        elif q.qtype == "multiple_answers_question":
            kinds["multiple answer"] += 1
        else:
            kinds["multiple choice"] += 1
    choice = [q.printed_option_count for q in quiz.questions if q.kind == "choice"]
    drawn = [g for g in quiz.groups if g.select is not None]
    per_exam_banks = sum(len(g.indices) if g.select is None else g.select for g in quiz.groups) if drawn else None
    warnings = _warnings(stderr)
    titles = {}
    for q in quiz.questions:
        titles[q.title.strip()] = titles.get(q.title.strip(), 0) + 1
    return json.dumps({
        "engine": _engine(info.path),
        "named": any(t for t in titles),
        "titles": [{"title": t, "count": titles[t]} for t in sorted(titles, key=cli._natural)],
        "title": quiz.title, "questions": len(quiz.questions),
        "kinds": {k: v for k, v in kinds.items() if v},
        "omitted": sum(1 for w in warnings if "omitted" in w),
        "warnings": warnings,
        "max_options": max(choice) if choice else 0,
        "merged_ok": all(n <= 4 for n in choice),           # two columns: A-D
        "merged1_ok": all(n <= 6 for n in choice),          # one column: A-F
        "per_exam_with_banks": per_exam_banks,
    })


# New Quizzes exports name the assignment they belong to on the <assessment> element; Classic
# Quizzes exports do not (both carry the same question metadata, so that cannot tell them apart)
_NEW_QUIZZES = re.compile(rb"<assessment\b[^>]*\bexternal_assignment_id\s*=")


def _engine(quiz_path):
    """'new' for a New Quizzes export, otherwise 'classic'."""
    return "new" if _NEW_QUIZZES.search(quiz_path.read_bytes()[:20000]) else "classic"


def _warnings(buffer):
    return [line[len("WARNING: "):] for line in buffer.getvalue().splitlines() if line.startswith("WARNING: ")]
