"""AES-256-GCM in plain Python, for password-protected answer keys (qr_payload.protect_key).

An answer key is a few hundred bytes, so speed does not matter; what matters is that MasterTest
Web needs no compiled cryptography library (about 2.3 MB less to download), and that the result is
exactly the standard AES-GCM that MasterTest Marker decrypts with the phone's own crypto. The
smoke test checks it against the `cryptography` package when that is installed.
"""

_SBOX = bytes.fromhex(
    "637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0"
    "b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b275"
    "09832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cf"
    "d0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2"
    "cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdb"
    "e0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08"
    "ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9e"
    "e1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16")
_RCON = (0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40)


def _xtime(a):
    return ((a << 1) ^ 0x1B) & 0xFF if a & 0x80 else a << 1


def _expand(key):
    """The 15 round keys of AES-256, each 16 bytes."""
    if len(key) != 32:
        raise ValueError("AES-256 needs a 32-byte key")
    w = [list(key[i:i + 4]) for i in range(0, 32, 4)]
    for i in range(8, 60):
        t = list(w[i - 1])
        if i % 8 == 0:
            t = [_SBOX[b] for b in t[1:] + t[:1]]
            t[0] ^= _RCON[i // 8 - 1]
        elif i % 8 == 4:
            t = [_SBOX[b] for b in t]
        w.append([a ^ b for a, b in zip(w[i - 8], t)])
    return [bytes(sum(w[4 * r:4 * r + 4], [])) for r in range(15)]


def _encrypt_block(rounds, block):
    s = [b ^ k for b, k in zip(block, rounds[0])]
    for r in range(1, 15):
        s = [_SBOX[b] for b in s]
        s = [s[(i + 4 * (i % 4)) % 16] for i in range(16)]          # ShiftRows (column-major state)
        if r != 14:
            out = []
            for c in range(4):
                a = s[4 * c:4 * c + 4]
                t = a[0] ^ a[1] ^ a[2] ^ a[3]
                out += [a[i] ^ t ^ _xtime(a[i] ^ a[(i + 1) % 4]) for i in range(4)]
            s = out
        s = [b ^ k for b, k in zip(s, rounds[r])]
    return bytes(s)


_R = 0xE1 << 120


def _gmul(x, y):
    """Multiplication in GF(2^128) as GCM defines it (bits taken most significant first)."""
    z, v = 0, x
    for i in range(127, -1, -1):
        if y >> i & 1:
            z ^= v
        v = (v >> 1) ^ _R if v & 1 else v >> 1
    return z


def _ghash(h, aad, data):
    def blocks(b):
        for i in range(0, len(b), 16):
            yield int.from_bytes(b[i:i + 16].ljust(16, b"\0"), "big")
    y = 0
    for blk in list(blocks(aad)) + list(blocks(data)):
        y = _gmul(y ^ blk, h)
    lengths = (len(aad) * 8 << 64) | (len(data) * 8)
    return _gmul(y ^ lengths, h)


def _ctr(rounds, j0, data):
    out = bytearray()
    counter = int.from_bytes(j0[12:], "big")
    for i in range(0, len(data), 16):
        counter = (counter + 1) & 0xFFFFFFFF
        stream = _encrypt_block(rounds, j0[:12] + counter.to_bytes(4, "big"))
        out += bytes(a ^ b for a, b in zip(data[i:i + 16], stream))
    return bytes(out)


def encrypt(key, nonce, plaintext, aad=b""):
    """Ciphertext followed by the 16-byte tag, as AESGCM(key).encrypt(nonce, plaintext, aad)."""
    if len(nonce) != 12:
        raise ValueError("the nonce must be 12 bytes")
    rounds = _expand(key)
    h = int.from_bytes(_encrypt_block(rounds, bytes(16)), "big")
    j0 = nonce + b"\0\0\0\1"
    ct = _ctr(rounds, j0, plaintext)
    tag = (_ghash(h, aad, ct) ^ int.from_bytes(_encrypt_block(rounds, j0), "big")).to_bytes(16, "big")
    return ct + tag


def decrypt(key, nonce, data, aad=b""):
    """The plaintext; ValueError when the tag does not match (wrong key, or the data was changed)."""
    if len(data) < 16 or len(nonce) != 12:
        raise ValueError("the data is too short")
    rounds = _expand(key)
    h = int.from_bytes(_encrypt_block(rounds, bytes(16)), "big")
    j0 = nonce + b"\0\0\0\1"
    ct, tag = data[:-16], data[-16:]
    want = (_ghash(h, aad, ct) ^ int.from_bytes(_encrypt_block(rounds, j0), "big")).to_bytes(16, "big")
    diff = 0
    for a, b in zip(want, tag):
        diff |= a ^ b
    if diff:
        raise ValueError("the authentication tag does not match")
    return _ctr(rounds, j0, ct)
