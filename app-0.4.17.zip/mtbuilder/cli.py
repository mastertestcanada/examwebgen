"""Command-line interface for MasterTest Builder."""

import argparse
import csv
import difflib
import getpass
import io
import json
import random
import re
import unicodedata
import shlex
import sys
from pathlib import Path

import reportlab.rl_config
from pypdf import PageObject, PdfReader, PdfWriter, Transformation
from reportlab.lib.pagesizes import A4, landscape, letter

from . import __app_name__, __version__
from . import answer_card, canvas, qr_payload, word
from .answer_key import answer_key_pdf, key_payload
from .attendance import attendance_pdf
from .errors import ExamError, warn
from . import merged as merged_layout
from .card_instructions import CardInstructions
from . import i18n, messages
from .exam_pdf import LETTERS, ExamBuilder, Layout
from .i18n import t
from .fonts import FontManager, detect_cjk
from .html_render import normalise_variable

PAGE_OPTIONS = ("collate-answer-cards", "pad-answer-cards", "collate-exams", "title-page", "pad-title-page",
                "pad-exam", "collate-title-pages")

# --page-size values: (paper, kind)
PAGE_SIZES = {
    "letter": ("letter", "booklet"), "a4": ("a4", "booklet"),
    "letter-single-page": ("letter", "single"), "a4-single-page": ("a4", "single"),
    "letter-merged": ("letter", "merged"), "a4-merged": ("a4", "merged"),
    "tabloid-booklet": ("letter", "duplex"), "a3-booklet": ("a4", "duplex"),
}


# ------------------------------------------------------------------ parsing


def hint_option(value, default):
    """--calculated-instructions / --fill-blank-instructions / --fill-blank-text: None (not
    given) keeps the default; "none" (any case) or an empty string means print nothing."""
    if value is None:
        return default
    value = value.strip()
    return "" if value.lower() == "none" else value


class Parser(argparse.ArgumentParser):
    """argparse with "did you mean" suggestions and our error format."""

    def error(self, message):
        m = re.search(r"unrecognized arguments: (.*)", message)
        if m:
            known = [o for a in self._actions for o in a.option_strings]
            hints = []
            for word in m.group(1).split():
                if word.startswith("--"):
                    name = word.split("=")[0]
                    close = difflib.get_close_matches(name.lower(), known, n=1, cutoff=0.6)
                    hints.append(f"unknown option {name}" + (f"; did you mean {close[0]}?" if close else ""))
            if hints:
                message = "; ".join(hints)
        raise ExamError(message + "  (see --help)")


def build_parser():
    p = Parser(
        prog="mastertest_builder", allow_abbrev=False,
        description="Create printable exams and machine-readable answer cards from a Canvas quiz export. "
                    "Options can also be read from a text file: mastertest_builder.py export.zip @options.txt",
    )
    g = p.add_argument_group("input")
    g.add_argument("export", nargs="?", help="Canvas quiz export (.zip file or unpacked folder), or a Word document (.docx) written for Akindi's importer")
    g.add_argument("--list-quizzes", action="store_true", help="list the quizzes in the export and exit")
    g.add_argument("--quiz", type=int, metavar="#", help="which quiz to use when the export holds several")

    g = p.add_argument_group("question selection (default: every usable question, drawing \"pick N\" from item banks and question groups)")
    x = g.add_mutually_exclusive_group()
    x.add_argument("--max-items", type=int, metavar="#", help="a random subset of # questions per exam")
    x.add_argument("--ignore-item-banks", action="store_true",
                   help="print every question of the item banks and question groups instead of following their "
                        "\"pick N\" rules (followed by default)")
    x.add_argument("--title-map", metavar="<filename>",
                   help="CSV of 'question title,count': count questions are drawn from the questions with each title; "
                        "or the same written in place of a file as 'title=count; title=count' (\\; for a ; in a title)")
    g.add_argument("--variants", default="all", metavar="#|all",
                   help="number of randomized exam variants, or 'all' (default) for one per student")

    g = p.add_argument_group("students and answer cards")
    g.add_argument("--class-list", metavar="<filename>", help="CSV with student name, student number and optional seat")
    g.add_argument("--student-id-column", metavar="<column>",
                   help="class-list column to use as the student number (default: SIS User ID, SIS ID or SIS Login ID "
                        "when the class list has one with data, else the first column with a recognised "
                        "student-number header)")
    g.add_argument("--add-qr-field", default="", metavar="<columns>",
                   help="comma-separated class-list columns to store in each card's QR code after the name and number")
    g.add_argument("--blank-cards", type=int, default=0, metavar="#", help="number of blank (bubble-in ID) answer cards")
    g.add_argument("--randomize-seats", action="store_true", help="assign random seats 1..N (replaces the class-list seat)")
    g.add_argument("--seat-labels", metavar="<seats>",
                   help='assign random seats drawn from this comma-separated list, e.g. "A1,A2,A3,B1,B2,B3"')
    g.add_argument("--qr-quality", default="M", type=str.upper, choices=["L", "M", "Q", "H"],
                   help="QR error-correction level: L (7%%), M (15%%, default), Q (25%%) or H (30%%)")
    g.add_argument("--password", action="store_true",
                   help="encrypt the answer-key QR code; you are asked to type a password, and the marking app "
                        "asks for it when it scans the key")

    g = p.add_argument_group("page layout and fonts (a length without a unit is in points)")
    g.add_argument("--page-size", default="letter", metavar="<size>",
                   help="letter (default) or a4; letter-single-page or a4-single-page (questions and answer area on "
                        "one page); letter-merged or a4-merged (each answer beside its question, one or more sheets); "
                        "tabloid-booklet or a3-booklet (folded booklets, two letter/A4 pages per side of a "
                        "tabloid/A3 sheet)")
    g.add_argument("--page-options", default="", metavar="<list>",
                   help="comma-separated: " + ", ".join(PAGE_OPTIONS))
    g.add_argument("--columns", type=int, choices=[1, 2], default=2,
                   help="merged page sizes: questions in 1 full-width column or 2 columns (default)")
    g.add_argument("--margin", default="0.75in", metavar="<len>", help="page margins, e.g. 0.75in (default), 2cm, 20mm, 54pt")
    for side in ("left", "right", "top", "bottom"):
        g.add_argument(f"--margin-{side}", default=None, metavar="<len>", help=f"{side} margin (overrides --margin)")
    g.add_argument("--font", default="Helvetica", metavar="<font>",
                   help="Helvetica (default), Times, Courier, a font supplied with the program, a font file or an installed font name (see --list-fonts)")
    g.add_argument("--font-size", type=float, default=None, metavar="<pt>",
                   help="base font size in points (default 11; 9 for the merged page sizes)")
    g.add_argument("--question-spacing", default=None, metavar="<len>",
                   help="space between one question and the next, e.g. 12pt, 0.25in, 5mm "
                        "(default 0.9 x the font size: 9.9pt at 11pt)")
    g.add_argument("--option-font", default=None, metavar="<font>",
                   help="font for the option letters (A, B, ...), chosen like --font (default: the question font)")
    g.add_argument("--print-language", default="en", type=str.lower, choices=sorted(i18n.LANGUAGES),
                   help="language of the printed text: instructions, headings, labels and the answer-card "
                        "instructions (en, the default, or fr); the quiz itself is printed as written")
    g.add_argument("--decimal-mark", type=str.lower, choices=["point", "comma"],
                   help="decimal mark for numbers the program prints and asks for: point (0.5) or comma (0,5); "
                        "default: the print language's (comma for fr). Marking accepts either")
    g.add_argument("--csv-separator", type=str.lower, choices=["comma", "semicolon"],
                   help="field separator of answer_key.csv: comma (with 0.5) or semicolon (with 0,5), as the "
                        "spreadsheet that opens it expects; default: semicolon for --print-language fr. "
                        "Class lists and title maps are read with either")
    g.add_argument("--cjk-region", default="auto", type=str.lower, choices=["auto", "sc", "tc", "jp", "kr"],
                   help="Chinese, Japanese and Korean text: whose writing style to print it in, Simplified (sc) or "
                        "Traditional (tc) Chinese, Japanese (jp) or Korean (kr); auto (default): Japanese when the "
                        "quiz has kana, Korean when it has Hangul, else Simplified Chinese")
    g.add_argument("--cjk-font", metavar="<font>",
                   help="font for Chinese, Japanese and Korean characters, chosen like --font (default: one "
                        "installed on the computer for the region)")
    g.add_argument("--option-letters", default="circled", type=str.lower, choices=["circled", "filled", "plain"],
                   help="option letters as enclosed characters, circled (Ⓐ, the default) or filled (🅐), or plain (A)")
    g.add_argument("--option-font-size", type=float, default=None, metavar="<pt>", help="font size for the option letters")
    g.add_argument("--option-dot", action=argparse.BooleanOptionalAction, default=False,
                   help="print a period after each option letter (default: --no-option-dot)")
    g.add_argument("--option-columns", type=int, default=1, metavar="#", help="lay options out in this many columns (default 1)")
    g.add_argument("--show-points", action="store_true", help="print each question's point value")
    g.add_argument("--no-quiz-instructions", action="store_true", help="do not print the quiz instructions")
    g.add_argument("--no-option-pad", action="store_true",
                   help="print one bubble per printed option; by default every multiple-choice question gets as "
                        "many bubbles as the quiz's question with the most options")

    g = p.add_argument_group("answer cards")
    g.add_argument("--answer-width", default=None, metavar="<len>",
                   help="width of the written-answer boxes, e.g. 1.5in or 110pt; bubbles, cells and rows scale with "
                        "it, so fewer or more questions fit. Default: 180 pt on one-column merged sheets, 90 pt on "
                        "two-column merged sheets, about 95 pt (letter) / 91 pt (A4) on answer cards")
    g.add_argument("--cell-shading", default="15", metavar="<percent>",
                   help="darkness of the shaded cells of number, short-answer, student-number and seat boxes, "
                        "as a percentage of black (default 15); 0 or none prints outlined boxes instead")
    g.add_argument("--answer-card-instructions", default=None, metavar="<filename>",
                   help="HTML file with the instructions printed on answer cards and merged sheets (same tags and "
                        "images as question text; default: answerCardInstructions.html next to mastertest_builder.py); "
                        "none prints no instructions")

    g = p.add_argument_group('question text ("none" or "" prints nothing)')
    g.add_argument("--calculated-instructions", default=None, metavar="<text>",
                   help="text printed under every calculated (formula) question in place of the standard instructions")
    g.add_argument("--fill-blank-text", default=None, metavar="<text>",
                   help="what is printed in place of the blank in fill-in-the-blank questions (default __________)")
    g.add_argument("--fill-blank-instructions", default=None, metavar="<text>",
                   help="text printed under every fill-in-the-blank question in place of the standard instructions")

    g = p.add_argument_group("attendance sheet (attendance.pdf, made whenever there is a class list)")
    g.add_argument("--add-attendance-field", default=None, metavar="<fields>",
                   help="comma-separated extra columns; a column of the class list shows its value, any other name "
                        "is left blank. The seat is included when seats are randomized")
    g.add_argument("--attendance-sort", default=None, metavar="<fields>",
                   help='comma-separated columns to sort by, e.g. "Seat" or "Section,Student Name"; add " desc" '
                        'to a column to reverse it (default: class-list order)')
    g.add_argument("--attendance-orientation", default="portrait", type=str.lower,
                   choices=["portrait", "landscape"], help="portrait (default) or landscape")

    g = p.add_argument_group("output")
    g.add_argument("-o", "--output", metavar="<folder>", help="output folder (default: the exam title)")
    g.add_argument("--seed", type=int, metavar="#", help="random seed, for reproducible runs")
    g.add_argument("--messages-language", type=str.lower, choices=list(messages.LANGUAGES), metavar="en/fr",
                   help="language of the program's messages (errors, warnings, the summary): en or fr; default: "
                        "the computer's language. --print-language sets the language of the exams")
    g.add_argument("--list-fonts", action="store_true",
                   help="list the fonts --font and --option-font can use (built in, supplied, installed) and stop")
    g.add_argument("--version", action="version", version=f"{__app_name__} {__version__}")
    return p


def expand_option_files(argv):
    """@<file> arguments: the file's lines are read as more arguments. Each line is split like a
    command line (quotes group words); blank lines and lines starting with # are skipped."""
    out = []
    for arg in argv:
        if arg.startswith("@") and len(arg) > 1:
            path = Path(arg[1:])
            try:
                text = path.read_text(encoding="utf-8-sig")
            except OSError as exc:
                raise ExamError(f"Could not read options file '{path}': {exc}")
            for line in text.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    try:
                        out += expand_option_files(shlex.split(line, posix=True))
                    except ValueError as exc:
                        raise ExamError(f"Options file '{path}': {exc} in: {line}")
        else:
            out.append(arg)
    return out


def parse_page_size(text):
    """--page-size -> (name, pagesize, kind) with kind booklet / single / merged / duplex."""
    name = text.strip().lower()
    if name not in PAGE_SIZES:
        raise ExamError(f"Unknown --page-size '{text}'. Choose from: {', '.join(PAGE_SIZES)}.")
    paper, kind = PAGE_SIZES[name]
    return name, letter if paper == "letter" else A4, kind


def parse_shading(text):
    """--cell-shading: a percentage of black, 0 (or off/none) for outlined boxes."""
    t = str(text).strip().lower().rstrip("%")
    if t in ("off", "none", "no", "false"):
        return 0.0
    try:
        v = float(t)
    except ValueError:
        raise ExamError(f"--cell-shading must be a percentage such as 15, or none; got '{text}'.")
    if not 0 <= v <= 40:
        raise ExamError(f"--cell-shading must be between 0 and 40 (percent); got {text}. "
                        "Darker shading hides pencil from the marking app.")
    return v / 100.0


ONE_COLUMN_ANSWER_WIDTH = 180   # default --answer-width on one-column merged sheets (two columns and cards: as before)


def parse_answer_width(text, pagesize, merged, one_column=False):
    """--answer-width: whole points, or None for the default layout (also when the default is given)."""
    if text is None:
        return None
    width = round(parse_length(text, "--answer-width"))
    if merged:
        default, low = merged_layout.ANSWER_WIDTH, 60
        if one_column:   # the QR code holds the width in one byte
            high = min(255, int(pagesize[0] - 2 * merged_layout.MARGIN - merged_layout.NUMBER_WIDTH
                                - merged_layout.GUTTER_AIR - 6 - 80))
            where = "on a one-column merged sheet"
        else:
            high = int(merged_layout.column_width(pagesize[0]) - merged_layout.NUMBER_WIDTH - merged_layout.GUTTER_AIR - 6 - 80)
            where = ("on a two-column merged sheet (the question text needs at least 80 pt; "
                     "--columns 1 allows up to 255 pt)")
    else:
        default, low = answer_card.default_answer_width(pagesize), 50
        high = int(pagesize[0] - 2 * 40 - 26 - 10 - 2)
        where = "on an answer card (one column of answers at the widest)"
    if not low <= width <= high:
        raise ExamError(f"--answer-width must be between {low} and {high} pt {where}; got {width} pt.")
    return None if abs(width - default) < 0.01 else width


def parse_length(text, what, minimum_bare=None):
    """A length in points; a number without a unit is in points. `minimum_bare`: a bare number
    below it is refused as a probable inch value (margins were inches before 0.3.5)."""
    m = re.match(r"^\s*([\d.]+)\s*(in|cm|mm|pt|)\s*$", str(text).lower())
    if not m:
        raise ExamError(f"Invalid {what} '{text}'. Use a number with in, cm, mm or pt (e.g. 0.75in, 2cm).")
    try:
        n = float(m.group(1))
    except ValueError:
        raise ExamError(f"Invalid {what} '{text}'.")
    if not m.group(2) and minimum_bare is not None and n < minimum_bare:
        raise ExamError(f"{what} {text} would be {text} points; a length without a unit is in points. "
                        f"Did you mean {text}in?")
    return n * {"": 1.0, "in": 72.0, "cm": 72 / 2.54, "mm": 72 / 25.4, "pt": 1.0}[m.group(2)]


def parse_page_options(text):
    chosen = set()
    for item in split_list(text):
        name = item.strip().lower()
        if name not in PAGE_OPTIONS:
            raise ExamError(f"Unknown page option '{item}'. Choose from: {', '.join(PAGE_OPTIONS)}.")
        chosen.add(name)
    return chosen


def ask_password():
    """Prompt for the answer-key password. At a terminal it is typed twice without being shown;
    when input is piped in (a script), one line is read instead."""
    if sys.stdin.isatty():
        for _ in range(3):
            first = getpass.getpass(messages.translate("Answer-key password: "))
            if not first:
                print(messages.translate("The password cannot be empty."), file=sys.stderr)
                continue
            if getpass.getpass(messages.translate("Type it again: ")) == first:
                password = first
                break
            print(messages.translate("The two entries did not match."), file=sys.stderr)
        else:
            raise ExamError("No password was set.")
    else:
        password = sys.stdin.readline().rstrip("\r\n")
        if not password:
            raise ExamError("--password: no password was supplied on standard input.")
    if len(password) < 12:
        warn("The password is short. Anyone who photographs the answer-key code can try passwords on "
             "their own computer; use a long passphrase (four or more random words).")
    return password


def csv_delimiter(text):
    """The field separator of a CSV: the one of comma, semicolon and tab that occurs most often
    outside quotes in its first non-empty line. Spreadsheets set up for French (and other
    languages that write 0,5) save CSV files with semicolons."""
    line = next((l for l in text.splitlines() if l.strip()), "")
    counts, quoted = {",": 0, ";": 0, "\t": 0}, False
    for ch in line:
        if ch == '"':
            quoted = not quoted
        elif not quoted and ch in counts:
            counts[ch] += 1
    best = max(counts, key=lambda c: (counts[c], c == ","))
    return best if counts[best] else ","


def _read_csv(path, what):
    try:
        try:
            with open(path, newline="", encoding="utf-8-sig") as fh:
                text = fh.read()
        except UnicodeDecodeError:
            with open(path, newline="", encoding="cp1252") as fh:
                text = fh.read()
    except OSError as exc:
        raise ExamError(f"Could not read {what} '{path}': {exc}")
    return [row for row in csv.reader(io.StringIO(text, newline=""), delimiter=csv_delimiter(text))]


def inline_title_map(value):
    """--title-map written out instead of a file, 'title=count; title=count' (a ; inside a title is
    written \\;): its [title, count] rows, or None when the value names a file (or is not written so)."""
    if Path(value).is_file() or "=" not in value:
        return None
    rows = []
    for part in re.split(r"(?<!\\);", value):
        part = part.replace("\\;", ";").strip()
        if not part:
            continue
        if "=" not in part:
            raise ExamError(f"--title-map: '{part}' needs the form title=count.")
        title, count = part.rsplit("=", 1)
        rows.append([title.strip(), count.strip()])
    return rows


def split_list(text):
    """A comma-separated option value -> its non-empty items (double quotes protect commas inside an item)."""
    return [c.strip() for row in csv.reader([text or ""], skipinitialspace=True) for c in row if c.strip()]


def _key(text):
    return re.sub(r"[^a-z0-9]", "", text.lower())


NAME_HEADERS = ("studentname", "name", "fullname", "student")
NUMBER_HEADERS = ("studentnumber", "studentid", "studentno", "number", "id", "sisuserid", "sisid", "sisloginid")
# Canvas gradebook exports have both Canvas's own ID and the institution's SIS columns: the SIS
# columns are preferred, in this order, when they hold data
SIS_HEADERS = ("sisuserid", "sisid", "sisloginid")


def find_number_column(header, rows):
    """Index of the student-number column: the first SIS column (SIS_HEADERS order) with a value
    in any row, else the left-most column whose header is a student-number name; None if none."""
    keys = [_key(h) for h in header]
    for k in SIS_HEADERS:
        if k in keys:
            i = keys.index(k)
            if any(len(r) > i and r[i].strip() for r in rows):
                return i
    return next((i for i, k in enumerate(keys) if k in NUMBER_HEADERS), None)
SEAT_HEADERS = ("seat", "seatnumber", "seatno")
SERIAL_FIELD = "Card serial"   # the last QR field of a class-list card (0.3.8); a blank card's only field


def luhn_digit(digits):
    """The Luhn check digit for a string of digits (as on payment cards): catches any single
    mistyped digit and most swaps of two neighbouring digits."""
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 0:          # every second digit from the right, starting next to the check digit
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return str((10 - total % 10) % 10)


def luhn_valid(serial):
    return serial.isdigit() and len(serial) > 1 and luhn_digit(serial[:-1]) == serial[-1]


def new_serial(rng, used):
    """A 12-digit card serial: 11 random digits (the first not 0) and a Luhn check digit,
    different from every serial already in `used`."""
    while True:
        body = str(rng.randrange(10 ** 10, 10 ** 11))
        serial = body + luhn_digit(body)
        if serial not in used:
            used.add(serial)
            return serial


def show_serial(serial):
    """A serial as printed: groups of four digits."""
    return " ".join(serial[i:i + 4] for i in range(0, len(serial), 4))


def read_classlist(path, prefer_id=None, add_to_qr=()):
    """Columns are recognised by their header names (case, spaces and punctuation
    are ignored), never by position."""
    rows = [r for r in _read_csv(path, "class list") if any(c.strip() for c in r)]
    if not rows:
        raise ExamError(f"Class list '{path}' is empty.")
    header = [h.strip() for h in rows[0]]
    keys = [_key(h) for h in header]
    listing = ", ".join(h for h in header if h)

    def find(*names):
        return next((keys.index(n) for n in names if n in keys), None)

    def column(name, option):
        k = _key(name)
        if not k or k not in keys:
            raise ExamError(f"{option}: the class list has no column named '{name}'. Its columns are: {listing}.")
        return keys.index(k)

    name_i = find(*NAME_HEADERS)
    seat_i = find(*SEAT_HEADERS)
    first_i, last_i = find("firstname", "first"), find("lastname", "last", "surname")
    if name_i is None and (first_i is None or last_i is None):
        raise ExamError(f"Class list '{path}' needs a 'student name' column.")
    if prefer_id:
        num_i = column(prefer_id, "--student-id-column")
    else:  # an SIS column with data, else the left-most column with a student-number header
        num_i = find_number_column(header, rows[1:])
        if num_i is None:
            raise ExamError(f"Class list '{path}' needs a 'student number' column (or name one with --student-id-column).")
    qr_cols = [column(name, "--add-qr-field") for name in add_to_qr]
    students, seen = [], set()
    for line, row in enumerate(rows[1:], 2):
        row = [c.strip() for c in row] + [""] * (len(header) - len(row))
        name = row[name_i] if name_i is not None else f"{row[first_i]} {row[last_i]}".strip()
        number = row[num_i]
        if not number:
            # e.g. the "Test Student" and "Points Possible" rows of a Canvas gradebook export
            warn(f"Class list line {line} ({name or 'no name'}) was skipped: its '{header[num_i]}' column is empty.")
            continue
        if number in seen:
            raise ExamError(f"Class list line {line}: '{header[num_i]}' value {number} appears more than once.")
        seen.add(number)
        for i in [name_i, num_i, *qr_cols]:
            if i is not None and len(row[i].encode("utf-8")) > qr_payload.MAX_FIELD_BYTES:
                warn(f"Class list line {line}: '{header[i]}' is longer than {qr_payload.MAX_FIELD_BYTES} bytes "
                     f"and is cut short in the QR code.")
        students.append({
            "name": name, "number": number, "seat": row[seat_i] if seat_i is not None else "",
            "columns": {normalise_variable(h): row[i] for i, h in enumerate(header) if h},
            # every column by its header with case, spaces and punctuation removed (attendance sheet)
            "fields": {_key(h): row[i] for i, h in enumerate(header) if _key(h)},
            # extra QR values; None = the seat column, filled in later so --randomize-seats is honoured
            "qr_extra": [None if i == seat_i else row[i] for i in qr_cols],
        })
    if not students:
        raise ExamError(f"Class list '{path}' has no students.")
    name_header = header[name_i] if name_i is not None else "Student Name"
    info = {"number_column": header[num_i],
            "qr_fields": [name_header, header[num_i]] + [header[i] for i in qr_cols] + [SERIAL_FIELD]}
    return students, [normalise_variable(h) for h in header if h], info


def assign_seats(students, option, rng):
    """--randomize-seats (True): seats 1..N; --seat-labels: the comma-separated seat labels."""
    if option is True:
        seats = [str(i) for i in range(1, len(students) + 1)]
    else:
        seats = []
        for cell in split_list(option):
            if cell not in seats:
                seats.append(cell)
        if len(seats) < len(students):
            raise ExamError(f"--seat-labels lists {len(seats)} different seat(s) but the class list has "
                            f"{len(students)} students.")
    for student, seat in zip(students, rng.sample(seats, len(students))):
        student["seat"] = seat


def _natural(value):
    """Sort key that puts 'A2' before 'A10' and empty values last, and accented letters with
    their plain letter (Émilie with Emilie, not after Z), the plain one first."""
    text = value.strip().lower()
    plain = "".join(ch for ch in unicodedata.normalize("NFD", text) if not unicodedata.combining(ch))
    parts = re.findall(r"\d+|\D+", plain)
    return (not parts, [(0, int(p), "") if p.isdigit() else (1, 0, p) for p in parts], text)


def attendance_layout(students, fields, sort, seats_assigned, list_info):
    """The attendance sheet's column headers and rows (without the signature column).
    Student Name and Student Number always; the seat when --randomize-seats is used; then each
    --add-attendance-field: the class-list value when the class list has that column, else blank.
    Rows follow the class list unless --attendance-sort names columns to sort by."""
    name_keys = {"studentname", "name", "fullname"}
    number_keys = {"studentnumber", _key(list_info["number_column"] or "")}
    known = set().union(*(s["fields"] for s in students))

    def getter(label):
        k = _key(label)
        if k in name_keys:
            return lambda s: s["name"]
        if k in number_keys:
            return lambda s: s["number"]
        if k in SEAT_HEADERS:
            return lambda s: s["seat"]
        if k in known:
            return lambda s: s["fields"].get(k, "")
        return None

    columns = [("Student Name", getter("Student Name")), ("Student Number", getter("Student Number"))]
    if seats_assigned and not any(_key(f) in SEAT_HEADERS for f in fields):
        columns.append(("Seat", getter("Seat")))
    seen = {"studentname", "studentnumber"} | ({"seat"} if len(columns) == 3 else set())
    for label in fields:
        k = _key(label)
        if not k or k in seen or k in name_keys | number_keys:
            continue
        seen.add(k if k not in SEAT_HEADERS else "seat")
        columns.append((label, getter(label) or (lambda s: "")))
    keys = []
    for label in sort:
        # "Seat desc" or "-Seat": that column in reverse order
        m = re.match(r"^(-)?\s*(.*?)(?:\s+(desc|descending|asc|ascending))?$", label.strip(), re.I)
        descending = bool(m.group(1)) or (m.group(3) or "").lower().startswith("desc")
        label = m.group(2)
        g = getter(label)
        if g is None:
            shown = ", ".join(c for c, _ in columns)
            raise ExamError(f"--attendance-sort: there is no column '{label}' on the attendance sheet or in the class "
                            f"list. The sheet's columns are: {shown}.")
        keys.append((g, descending))
    ordered = list(students)
    for g, descending in reversed(keys):        # stable sorts, least important column first
        ordered.sort(key=lambda s: _natural(g(s)), reverse=descending)
        if descending:                           # empty values stay last
            ordered = [s for s in ordered if g(s).strip()] + [s for s in ordered if not g(s).strip()]
    shown = {"Student Name": t("student_name"), "Student Number": t("student_number_column"), "Seat": t("seat")}
    return [shown.get(c, c) for c, _ in columns], [[g(s) for _, g in columns] for s in ordered]


# ---------------------------------------------------------------- selection

class Selector:
    """Chooses and shuffles the questions of one exam variant."""

    def __init__(self, quiz, max_items=None, item_banks=True, title_map=None):
        """At most one of --max-items, --ignore-item-banks (item_banks=False) and --title-map. By default
        (item_banks=True) item banks and question groups with a "pick N" rule give N questions each;
        every other question is printed."""
        self.quiz = quiz
        self.mode, self.max_items, self.title_counts = "none", None, None
        pool = len(quiz.questions)
        if max_items is not None:
            if not 1 <= max_items <= pool:
                raise ExamError(f"--max-items must be a number from 1 to {pool} (the usable questions in the export).")
            self.mode, self.max_items = "maxitems", max_items
        elif title_map is not None:
            self.mode = "titlemap"
            self.title_counts = self._read_title_map(title_map.strip())
        elif item_banks and any(g.select is not None for g in quiz.groups):
            self.mode = "useitembanks"

    def _read_title_map(self, path):
        if not path:
            raise ExamError("--title-map needs a filename.")
        by_title = {}
        for q in self.quiz.questions:
            by_title.setdefault(q.title.strip(), []).append(q.index)
        counts = {}
        inline = inline_title_map(path)
        if inline is not None:
            rows, where = inline, "--title-map"
        else:
            rows = [r for r in _read_csv(path, "title map") if any(c.strip() for c in r)]
            where = f"Title map '{path}'"
        for n, row in enumerate(rows):
            title = row[0].strip()
            count = row[1].strip() if len(row) > 1 else ""
            if not count.isdigit():
                if n == 0 and inline is None:
                    continue  # header row
                raise ExamError(f"{where}: '{title}' needs a whole number of questions, not '{count}'.")
            if title not in by_title:
                raise ExamError(f"{where}: no usable question in the export has the title '{title}'.")
            if int(count) > len(by_title[title]):
                raise ExamError(f"{where}: '{title}' asks for {count} questions but only {len(by_title[title])} exist.")
            counts[title] = (int(count), by_title[title])
        unused = sorted(t for t in by_title if t not in counts)
        if unused:
            warn("Question titles not listed in the title map are left out of the exam: " + ", ".join(repr(t) for t in unused))
        if not sum(c for c, _ in counts.values()):
            raise ExamError(f"{where} selects no questions.")
        return counts

    def max_questions(self):
        if self.mode == "maxitems":
            return self.max_items
        if self.mode == "useitembanks":
            return sum(len(g.indices) if g.select is None else g.select for g in self.quiz.groups)
        if self.mode == "titlemap":
            return sum(c for c, _ in self.title_counts.values())
        return len(self.quiz.questions)

    def draw(self, rng):
        """Returns [(Question, option permutation)] in printed order."""
        qs = self.quiz.questions
        if self.mode == "maxitems":
            chosen = rng.sample(range(len(qs)), self.max_items)
        elif self.mode == "useitembanks":
            chosen = []
            for g in self.quiz.groups:
                avail = [i for i in g.indices if i not in chosen]
                chosen += avail if g.select is None else rng.sample(avail, min(g.select, len(avail)))
        elif self.mode == "titlemap":
            chosen = []
            for count, indices in self.title_counts.values():
                chosen += rng.sample(indices, count)
        else:
            chosen = list(range(len(qs)))
        rng.shuffle(chosen)
        selection = []
        for i in chosen:
            q = qs[i]
            if q.kind == "numeric":         # which worked example (value set) this exam prints
                selection.append((q, [rng.randrange(len(q.value_sets))]))
                continue
            if q.kind in ("text", "match"):     # matching: the answers' numbering is the same on every exam
                selection.append((q, []))
                continue
            # perm[i] = pre-randomized position of the option printed in slot i
            perm = list(range(len(q.options)))
            if q.qtype == "true_false_question":  # always printed as written: True, then False
                perm.sort(key=lambda i: q.options[i].export_pos)
            else:
                rng.shuffle(perm)
            selection.append((q, perm))
        return selection


def correct_letters(question, perm):
    """The correct answer as printed: letters for multiple choice, the number for a calculated
    question, accepted answers separated by | for fill-in-the-blank."""
    if question.kind == "numeric":
        return question.value_sets[perm[0]][1]
    if question.kind == "text":
        return "|".join(question.accepted)
    if question.kind == "match":         # a3 b1 c4: each item's letter and the number of its answer
        return " ".join(f"{'abcdefghijklmnopqrstuvwxyz'[k]}{m + 1}" for k, m in enumerate(question.matches))
    printed = [i for i in perm if not question.options[i].empty]
    return "".join(LETTERS[k] for k, i in enumerate(printed) if question.options[i].correct)


# ----------------------------------------------------------------- assembly

def safe_name(text, limit=80):
    text = re.sub(r"[^\w\-]+", "_", str(text), flags=re.UNICODE).strip("_")
    return text[:limit] or "untitled"


def _writer():
    w = PdfWriter()
    w.add_metadata({"/Producer": f"{__app_name__} {__version__}"})
    return w


DUPLEX_CARD_PAGES = 4   # one folded sheet: the hard limit is 4 x 100 questions


def impose(writer, pages, pagesize):
    """Lay portrait pages two-up on landscape sheets of twice the width, in the order that
    makes a booklet when the printed sheets are stacked and folded down the middle.

    `pages` holds the booklet pages in reading order (None = blank) and its length is a
    multiple of four. Sheet s (counting from 0) of an N-page booklet carries
        front:  page N-2s      | page 1+2s
        back:   page 2+2s      | page N-1-2s
    so a 4-page booklet is  4|1  then  2|3.  Print double-sided, flipping on the short edge."""
    width, height = pagesize
    n = len(pages)
    for s in range(n // 4):
        for left, right in ((pages[n - 1 - 2 * s], pages[2 * s]), (pages[2 * s + 1], pages[n - 2 - 2 * s])):
            sheet = PageObject.create_blank_page(width=2 * width, height=height)
            if left is not None:
                sheet.merge_page(left)
            if right is not None:
                sheet.merge_transformed_page(right, Transformation().translate(width, 0))
            writer.add_page(sheet)


def add_booklet(writer, pdf, pagesize, pad_title, pad_exam, duplex=False):
    """Append an exam booklet, inserting the blank pages asked for by padTitlePage / padExam.
    With `duplex` the booklet is imposed on folded sheets and always ends on a blank page."""
    if duplex:
        pages = list(PdfReader(io.BytesIO(pdf)).pages)
        if pad_title:
            pages.insert(1, None)
        pages.append(None)                 # the back cover is always blank
        while len(pages) % 4:
            pages.append(None)
        impose(writer, pages, pagesize)
        return
    start = len(writer.pages)
    writer.append(PdfReader(io.BytesIO(pdf)))
    if pad_title:
        writer.insert_blank_page(pagesize[0], pagesize[1], start + 1)
    if pad_exam:
        count = len(writer.pages) - start
        for _ in range(2 if count % 2 == 0 else 1):
            writer.add_blank_page(pagesize[0], pagesize[1])


def add_card(writer, pdf, pagesize, pad, duplex=False):
    """Append answer card(s); with `pad`, a blank page follows every card.
    With `duplex` the cards become one folded sheet, always four pages."""
    if duplex:
        pages = list(PdfReader(io.BytesIO(pdf)).pages)
        pages += [None] * (DUPLEX_CARD_PAGES - len(pages))
        impose(writer, pages, pagesize)
        return
    for page in PdfReader(io.BytesIO(pdf)).pages:
        writer.add_page(page)
        if pad:
            writer.add_blank_page(pagesize[0], pagesize[1])


def _save(writer, path):
    with open(path, "wb") as fh:
        writer.write(fh)


def _progress(what, done, total):
    if total >= 20 and (done % 10 == 0 or done == total):
        print(f"  {what} {done}/{total}", file=sys.stderr, flush=True)


# --------------------------------------------------------------------- main

def run(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    # the messages' language first, so that even a mistake in the options is explained in it
    messages.set_language(messages.default_language())
    for i, a in enumerate(argv):
        if a == "--messages-language" and i + 1 < len(argv):
            messages.set_language(argv[i + 1].lower())
        elif a.startswith("--messages-language="):
            messages.set_language(a.split("=", 1)[1].lower())
    argv = expand_option_files(argv)
    args = build_parser().parse_args(argv)
    i18n.set_language(args.print_language, args.decimal_mark)
    reportlab.rl_config.invariant = 1  # identical input + seed -> identical PDFs
    if args.list_fonts:
        from .fonts import bundled_fonts, installed_families
        print(messages.translate("Built into every PDF reader: Helvetica, Times, Courier"))
        print(messages.translate("Supplied with MasterTest Builder: " + ", ".join(sorted(bundled_fonts(), key=str.lower))))
        installed = installed_families()
        print(messages.translate(f"Installed on this computer ({len(installed)}):"))
        for name in installed:
            print("  " + name)
        print(messages.translate("Or give the path of a .ttf, .otf or .ttc file."))
        return 0
    if not args.export:
        raise ExamError("Give the Canvas quiz export (.zip file or unpacked folder) or Word document (.docx) to build from.")

    root = canvas.open_export(args.export)
    quizzes = canvas.list_quizzes(root)
    if args.list_quizzes:
        for q in quizzes:
            print(f"{q.number}: {q.title}")
        return 0
    if args.quiz is None:
        if len(quizzes) > 1:
            listing = "\n".join(f"  {q.number}: {q.title}" for q in quizzes)
            raise ExamError(f"The export contains {len(quizzes)} quizzes; choose one with --quiz <#>:\n{listing}")
        info = quizzes[0]
    else:
        if not 1 <= args.quiz <= len(quizzes):
            raise ExamError(f"--quiz must be between 1 and {len(quizzes)} (see --list-quizzes).")
        info = quizzes[args.quiz - 1]

    # ---- validate options before doing any heavy work
    page_opts = parse_page_options(args.page_options)
    # `pagesize` is always the portrait letter/A4 page everything is laid out on; in the booklet
    # sizes two of them are placed side by side on each tabloid/A3 sheet at the very end.
    page_name, pagesize, page_kind = parse_page_size(args.page_size)
    merged = page_kind == "merged"
    single = page_kind in ("single", "merged")   # one document is both quiz and answer card
    if args.font_size is None:
        args.font_size = 9.0 if merged else 11.0
    duplex = page_kind == "duplex"
    if duplex:
        if "collate-title-pages" in page_opts:
            raise ExamError("collate-title-pages cannot be used with a booklet --page-size: "
                            "the title page is always the first page of the booklet.")
        page_opts.add("title-page")                      # always: booklet page 1 is the title page
        page_opts -= {"pad-exam", "pad-answer-cards"}    # no effect: booklets and cards are always padded
    if "pad-title-page" in page_opts and not single and not page_opts & {"title-page", "collate-title-pages"}:
        raise ExamError("pad-title-page can only be used together with title-page or collate-title-pages.")
    one_column = args.columns == 1
    if one_column and not merged:
        raise ExamError("--columns applies only to the merged page sizes (letter-merged, a4-merged).")
    if single:
        banned = sorted(page_opts & {"title-page", "pad-title-page", "collate-title-pages"})
        if banned:
            raise ExamError(f"{', '.join(banned)} cannot be used with a single-page or merged --page-size: "
                            f"the quiz and its answers start on the first page.")
    margin = parse_length(args.margin, "--margin", minimum_bare=5)
    margins = {s: (parse_length(getattr(args, f"margin_{s}"), f"--margin-{s}", minimum_bare=5) if getattr(args, f"margin_{s}") is not None else margin)
               for s in ("left", "right", "top", "bottom")}
    if margins["left"] + margins["right"] > pagesize[0] - 144 or margins["top"] + margins["bottom"] > pagesize[1] - 144:
        raise ExamError("The margins leave too little room on the page.")
    if not 4 <= args.font_size <= 72:
        raise ExamError("--font-size must be between 4 and 72 points.")
    if args.option_columns < 1:
        raise ExamError("--option-columns must be 1 or more.")
    if args.blank_cards < 0:
        raise ExamError("--blank-cards cannot be negative.")
    if not args.class_list and not args.blank_cards:
        raise ExamError("Nothing to generate: give --class-list <filename>, --blank-cards <#>, or both.")
    if args.variants.strip().lower() == "all":
        n_variants = None
    elif args.variants.strip().isdigit() and int(args.variants) >= 1:
        n_variants = int(args.variants)
    else:
        raise ExamError("--variants must be a number (1 or more) or 'all'.")

    password = ask_password() if args.password else None   # asked now, before the slow work starts

    seed = args.seed if args.seed is not None else random.SystemRandom().randrange(2 ** 32)
    rng = random.Random(seed)

    add_to_qr = split_list(args.add_qr_field)
    if (args.student_id_column or add_to_qr) and not args.class_list:
        raise ExamError("--student-id-column and --add-qr-field need a class list.")
    students, columns, list_info = (read_classlist(args.class_list, args.student_id_column, add_to_qr) if args.class_list
                                    else ([], [], {"number_column": None, "qr_fields": []}))
    seats_randomized = args.randomize_seats or args.seat_labels is not None
    if seats_randomized:
        if students:
            assign_seats(students, True if args.seat_labels is None else args.seat_labels, rng)
        else:
            warn("--randomize-seats / --seat-labels was ignored because there is no class list.")
    if (args.add_attendance_field is not None or args.attendance_sort is not None) and not students:
        raise ExamError("--add-attendance-field and --attendance-sort need a class list.")
    attendance = (attendance_layout(students, split_list(args.add_attendance_field), split_list(args.attendance_sort),
                                    seats_randomized, list_info) if students else None)

    quiz = canvas.load_quiz(root, info, blank=canvas.BLANK if args.fill_blank_text is None else hint_option(args.fill_blank_text, ""))
    if merged:
        merged_layout.check_choices(quiz.questions, 1 if one_column else 2)
    # padding (the default from 0.4.3): every multiple-choice question gets as many bubbles as the
    # question of the quiz with the most printed options; the marking app works the number out from the key
    choice_counts = [q.printed_option_count for q in quiz.questions if q.kind == "choice"]
    pad_to = None if args.no_option_pad or not choice_counts else max(choice_counts)
    if args.ignore_item_banks and not any(g.select is not None and g.select < len(g.indices) for g in quiz.groups):
        warn("This quiz has no item banks or question groups that pick fewer than all their questions; "
             "--ignore-item-banks changes nothing.")
    selector = Selector(quiz, max_items=args.max_items, item_banks=not args.ignore_item_banks, title_map=args.title_map)
    width_defaulted = args.answer_width is None
    if merged and one_column and args.answer_width is None:
        args.answer_width = f"{ONE_COLUMN_ANSWER_WIDTH}pt"   # one column has room for wider written answers (0.3.17)
    answer_width = parse_answer_width(args.answer_width, pagesize, merged, one_column=one_column)
    per_card = answer_card.capacity(pagesize, None if merged else answer_width)
    if duplex and selector.max_questions() > per_card * DUPLEX_CARD_PAGES:
        raise ExamError(
            f"The exam would have {selector.max_questions()} questions; with a booklet --page-size the answer "
            f"card is one folded sheet of {DUPLEX_CARD_PAGES} pages, so the limit is {per_card * DUPLEX_CARD_PAGES}. "
            f"Use --max-items or --title-map to print fewer questions."
        )
    if selector.max_questions() > per_card * answer_card.MAX_CARDS:
        raise ExamError(
            f"The exam would have {selector.max_questions()} questions; the limit is "
            f"{per_card * answer_card.MAX_CARDS} ({answer_card.MAX_CARDS} answer cards of {per_card}). "
            f"Use --max-items or --title-map to print fewer questions."
        )
    key_data = key_payload(quiz, list_info["qr_fields"])   # the plain answer key
    key_qr = key_data                                        # what is printed
    if password is not None:
        try:
            key_qr = qr_payload.protect_key(key_data, password)
        except RuntimeError as exc:
            raise ExamError(str(exc))

    fonts = FontManager()
    quiz_text = " ".join([quiz.title, quiz.description] + [q.html for q in quiz.questions] +
                         [o.text for q in quiz.questions for o in q.options])
    cjk_found = detect_cjk(quiz_text)
    cjk_region = cjk_found if args.cjk_region == "auto" else args.cjk_region
    fonts.set_cjk(cjk_region, args.cjk_font)
    family = fonts.load(args.font)
    same = not args.option_font or args.option_font.strip().lower() == "same"
    option_family = family if same else fonts.load(args.option_font, quiet=True)
    layout = Layout(
        pagesize=pagesize, margin_left=margins["left"], margin_right=margins["right"],
        margin_top=margins["top"], margin_bottom=margins["bottom"], family=family, font_size=args.font_size,
        option_family=option_family, option_size=args.option_font_size or args.font_size,
        option_dot=args.option_dot, option_letters=args.option_letters, option_columns=args.option_columns,
        show_points=args.show_points,
        question_spacing=None if args.question_spacing is None else parse_length(args.question_spacing, "--question-spacing"),
        instructions=not args.no_quiz_instructions,
        title_mode="separate" if "collate-title-pages" in page_opts else "page" if "title-page" in page_opts else "inline",
        calculated_hint=hint_option(args.calculated_instructions, t("calc_hint")),
        fillblanks_hint=hint_option(args.fill_blank_instructions, t("fill_hint")),
    )
    builder = ExamBuilder(quiz, layout, fonts)
    shading = parse_shading(args.cell_shading)
    card_text = CardInstructions.load(args.answer_card_instructions)
    if merged:
        # the question hints default to none here: the header says how to fill in the answers
        mbuilder = merged_layout.MergedBuilder(
            builder, pagesize, spacing=layout.question_spacing,
            hints=(hint_option(args.calculated_instructions, "") if args.calculated_instructions is not None else None,
                   hint_option(args.fill_blank_instructions, "") if args.fill_blank_instructions is not None else None),
            pad_options=pad_to, shading=shading, columns=1 if one_column else 2,
            answer_width=answer_width, instructions=card_text)

    out_dir = Path(args.output) if args.output else Path(safe_name(quiz.title, 120))
    out_dir.mkdir(parents=True, exist_ok=True)

    # ---- people who get a card: students first, then blanks. Every card has a 12-digit serial
    # (identifying it without naming the student, e.g. to support); a blank card is filed under it.
    # The serials come from their own generator, so they do not change which questions are drawn.
    serial_rng = random.Random(f"card serials {seed}")
    used = set()
    people = [dict(s, blank=False, id=s["number"], serial=new_serial(serial_rng, used)) for s in students]
    for _ in range(args.blank_cards):
        serial = new_serial(serial_rng, used)
        people.append({"name": "", "number": "", "seat": "", "columns": {}, "blank": True, "id": serial, "serial": serial})

    def qr_fields(p):
        """Data-field values stored in the card's QR code. Their names, in the
        same order, are list_info["qr_fields"] and go in the answer key."""
        if p["blank"]:
            return [p["serial"]]  # ties the card to its booklet and to its other cards
        return [p["name"], p["number"]] + [p["seat"] if v is None else v for v in p["qr_extra"]] + [p["serial"]]

    empty_vars = {k: "" for k in ["STUDENT NAME", "STUDENT NUMBER", "SEAT NUMBER", "SEAT", *columns]}

    def person_vars(p):
        v = dict(empty_vars)
        if not p["blank"]:
            v.update(p["columns"])
            v.update({"STUDENT NAME": p["name"], "STUDENT NUMBER": p["number"], "SEAT NUMBER": p["seat"], "SEAT": p["seat"]})
        return v

    # ---- build the exam booklets
    booklets = []  # (file stem, pdf bytes, pages)
    if single:  # only decide who gets which questions; each page is built with its answer area below
        if n_variants is None:
            for n, p in enumerate(people, 1):
                p["variant"], p["selection"] = n, selector.draw(rng)
        else:
            variants = {n: selector.draw(rng) for n in range(1, n_variants + 1)}
            order = [(i % n_variants) + 1 for i in range(len(people))]
            rng.shuffle(order)
            for p, n in zip(people, order):
                p["variant"], p["selection"] = n, variants[n]
    elif n_variants is None:
        for n, p in enumerate(people, 1):
            p["variant"] = n
            p["selection"] = selector.draw(rng)
        for done, p in enumerate(people, 1):
            _progress("exam", done, len(people))
            label = t("blank_label", id=p["id"]) if p["blank"] else f"{p['number']}  {p['name']}"
            pdf, pages = builder.build(p["selection"], dict(person_vars(p), VARIANT=p["variant"]), label)
            stem = f"{safe_name(p['id'])}_{safe_name(p['name']) if not p['blank'] else 'blank'}_exam"
            booklets.append((stem, pdf, pages))
            p["exam_file"], p["pages"] = stem + ".pdf", pages
    else:
        variants = {n: selector.draw(rng) for n in range(1, n_variants + 1)}
        order = [(i % n_variants) + 1 for i in range(len(people))]
        rng.shuffle(order)
        pages_of = {}
        for n, selection in variants.items():
            pdf, pages = builder.build(selection, dict(empty_vars, VARIANT=n), f"Variant {n}")
            booklets.append((f"variant_{n}", pdf, pages))
            pages_of[n] = pages
        for p, n in zip(people, order):
            p["variant"], p["selection"] = n, variants[n]
            p["exam_file"], p["pages"] = f"variant_{n}.pdf", pages_of[n]

    pad_title = "pad-title-page" in page_opts and layout.title_mode == "page"
    pad_exam = "pad-exam" in page_opts
    written = []
    if single:
        pass
    elif "collate-exams" in page_opts:
        w = _writer()
        for _stem, pdf, _pages in booklets:
            add_booklet(w, pdf, pagesize, pad_title, pad_exam, duplex)
        _save(w, out_dir / "exams.pdf")
        written.append("exams.pdf")
        for p in people:
            p["exam_file"] = "exams.pdf"
    else:
        for stem, pdf, _pages in booklets:
            if pad_title or pad_exam or duplex:
                w = _writer()
                add_booklet(w, pdf, pagesize, pad_title, pad_exam, duplex)
                _save(w, out_dir / f"{stem}.pdf")
            else:
                (out_dir / f"{stem}.pdf").write_bytes(pdf)
        written.append(f"{len(booklets)} exam booklet(s)")

    # ---- individual title pages in their own file
    if layout.title_mode == "separate" and not single:
        w = _writer()
        for done, p in enumerate(people, 1):
            _progress("title page", done, len(people))
            tv = dict(person_vars(p), VARIANT=p["variant"])
            tv["PAGE COUNT"], tv["QUESTION COUNT"] = p["pages"], len(p["selection"])
            w.append(PdfReader(io.BytesIO(builder.title_page(tv))))
            if "pad-title-page" in page_opts:
                w.add_blank_page(pagesize[0], pagesize[1])
        _save(w, out_dir / "title_pages.pdf")
        written.append("title_pages.pdf")

    # ---- answer cards
    pool_size = len(quiz.questions)
    collate_cards, pad_cards = "collate-answer-cards" in page_opts, "pad-answer-cards" in page_opts
    if single:  # one page is both exam and card, so the exam options mean the same as the card options
        collate_cards = collate_cards or "collate-exams" in page_opts
        pad_cards = pad_cards or "pad-exam" in page_opts
    kind, collated_name = ("quiz", "quizzes.pdf") if single else ("answer", "answer_cards.pdf")
    pad_options = pad_to is not None
    card_writer = _writer() if collate_cards else None
    geo = answer_card.geometry(pagesize, answer_width=None if merged else answer_width)
    # one-column merged sheets: when the default answer width needs more sheets than a merged quiz can
    # have, the width steps down (to 90 pt at the least) until every exam fits
    width_steps = ([w for w in (160, 140, 120, 100, merged_layout.ANSWER_WIDTH) if w < answer_width]
                   if merged and one_column and width_defaulted and answer_width else [])
    while True:
        try:
            manifest_cards, key_rows, card_pdfs = [], [], []

            def card_entries(chunk):
                """(index, value, bits) per question for the card's QR code; see qr_payload.entry_field."""
                return [(q.index, *qr_payload.entry_field(q.kind, perm, len(q.value_sets))) for q, perm in chunk]

            def row_kind(q):
                """What the card shows for a question: bubble count, or a written-answer box."""
                if q.kind == "numeric":
                    return answer_card.NUMERIC
                if q.kind == "text":
                    return answer_card.TEXT
                if q.kind == "match":
                    return ("match", len(q.prompts), q.cells)
                return pad_to if pad_options else q.printed_option_count

            def card_chunks(sel):
                """(first question, questions) per full-page card: as many as its rows hold (a matching
                question takes several rows and is never split between cards)."""
                rpc = geo["answers"]["rows_per_column"]
                chunks, start = [], 0
                while start < len(sel):
                    end = start + 1
                    while end < len(sel) and answer_card.row_layout([row_kind(q) for q, _ in sel[start:end + 1]], rpc)[1] <= per_card:
                        end += 1
                    chunks.append((start, sel[start:end]))
                    start = end
                return chunks
            # matching questions take several rows of a card, so the cards say which number they start at
            numbered = any(q.kind == "match" for q in quiz.questions)
            for p in people:
                sel = p["selection"]
                cards = []
                for k, (start, chunk) in enumerate(card_chunks(sel)):  # long exams spill onto further cards
                    cards.append({
                        "payload": qr_payload.encode(quiz.ident, p["blank"], qr_fields(p), card_entries(chunk), pool_size,
                                                     index=k, a4=pagesize is A4, padded=pad_options,
                                                     shaded=shading > 0, answer_width=answer_width,
                                                     first_number=start + 1 if numbered else None),
                        "option_counts": [row_kind(q) for q, _ in chunk],
                        "first_number": start + 1,
                    })
                show_variant = p["variant"] if n_variants is not None else ""
                details = dict(blank=p["blank"], name=p["name"], number=p["number"], seat=p["seat"],
                               variant=show_variant, card_id=show_serial(p["serial"]), qr_quality=args.qr_quality)
                drawing = dict(details, shading=shading, answer_width=answer_width, instructions=card_text)
                if merged:
                    _progress("quiz", len(manifest_cards) + 1, len(people))
                    who = f"blank {p['id']}" if p["blank"] else f"{p['name']} ({p['number']})"

                    def payload_for(sheet, first, indices, spots, p=p, sel=sel):
                        return qr_payload.encode(quiz.ident, p["blank"], qr_fields(p), card_entries([sel[i] for i in indices]),
                                                 pool_size, index=sheet, kind=qr_payload.MERGED, a4=pagesize is A4,
                                                 padded=pad_options, shaded=shading > 0, answer_width=answer_width,
                                                 first_number=first, spots=spots)

                    pdf, sheets = mbuilder.build(sel, dict(person_vars(p), VARIANT=p["variant"]), who, payload_for,
                                                 quiz_title=quiz.title, **{k: v for k, v in details.items() if k != "qr_quality"},
                                                 qr_quality=args.qr_quality)
                    cards = [{"payload": sh["payload"]} for sh in sheets]
                    page_geo = {"sheets": [sh["layout"] for sh in sheets]}
                    p["pages"] = len(sheets) + (1 if mbuilder.cover else 0)
                    p["cover"] = mbuilder.cover
                elif single:
                    _progress("quiz", len(manifest_cards) + 1, len(people))
                    who = f"blank {p['id']}" if p["blank"] else f"{p['name']} ({p['number']})"
                    if len(cards) != 1:
                        raise ExamError(f"The quiz does not fit on a single page for {who}: it has {len(sel)} questions.")
                    card = cards[0]
                    card["payload"] = qr_payload.encode(quiz.ident, p["blank"], qr_fields(p), card_entries(sel), pool_size,
                                                        kind=qr_payload.SINGLE_PAGE, a4=pagesize is A4, padded=pad_options,
                                                        shaded=shading > 0, answer_width=answer_width,
                                                        first_number=1 if numbered else None)
                    # rows, not questions: a matching question takes several (the columns are those of a full card)
                    columns = answer_card.geometry(pagesize, single=True, blank=p["blank"], questions=1,
                                                   answer_width=answer_width)["answers"]["columns"]
                    slots = answer_card.single_page_rows(card["option_counts"], columns) * columns
                    page_geo = answer_card.geometry(pagesize, single=True, blank=p["blank"], questions=slots, answer_width=answer_width)

                    def draw(canv, card=card, page_geo=page_geo, drawing=drawing):
                        answer_card.draw_card(canv, pagesize, fonts, family, quiz.title, card["payload"],
                                              option_counts=card["option_counts"], geo=page_geo, **drawing)

                    pdf = builder.build_single(sel, dict(person_vars(p), VARIANT=p["variant"]), page_geo, draw, who)
                    p["pages"] = 1
                else:
                    pdf = answer_card.cards_pdf(pagesize, fonts, family, quiz.title, cards, **drawing)
                stem = f"{safe_name(p['id'])}_{safe_name(p['name']) if not p['blank'] else 'blank'}_{kind}"
                card_file = collated_name if collate_cards else stem + ".pdf"
                card_pdfs.append((card_file, pdf))  # written only after every card has been built without error
                if single:
                    p["exam_file"] = card_file
                keys = [correct_letters(q, perm) for q, perm in sel]
                key_rows.append([p["serial"], p["name"] or t("csv_blank"), p["number"], p["variant"], p["seat"], *keys])
                manifest_cards.append({
                    "id": p["id"], "serial": p["serial"], "blank": p["blank"], "qr_fields": qr_fields(p), "name": p["name"], "seat": p["seat"], "variant": p["variant"],
                    "exam_file": p["exam_file"], "card_file": card_file, "exam_pages": p["pages"],
            **({"cover_page": p.get("cover", False)} if merged else {}),
                    "qr_payloads_hex": [c["payload"].hex() for c in cards],
                    **({"card_layout": page_geo} if single else {}),
                    "questions": [{"number": n, "index": q.index, "ident": q.ident, "kind": q.kind,
                                   "option_order": perm if q.kind == "choice" else [],
                                   **({"value_set": perm[0]} if q.kind == "numeric" else {}),
                                   **({"items": len(q.prompts), "matches": [m + 1 for m in q.matches]} if q.kind == "match" else {}),
                                   "printed_options": q.printed_option_count, "correct": k}
                                  for n, ((q, perm), k) in enumerate(zip(sel, keys), 1)],
                })
        except merged_layout.SheetLimit as exc:
            if not width_steps:
                raise ExamError(f"{exc} Make the questions take less room: a narrower --answer-width (now "
                                f"{round(answer_width or merged_layout.ANSWER_WIDTH)} pt), a smaller --font-size or "
                                f"--question-spacing, more --option-columns, fewer questions (--max-items), two columns "
                                f"(if every question has at most four options), or a booklet --page-size.") from None
            narrower = width_steps.pop(0)
            warn(f"At {answer_width} pt answers some exams need more than {merged_layout.MAX_SHEETS} sheets; "
                 f"trying {narrower} pt (give --answer-width to choose the width yourself).")
            answer_width = None if narrower == merged_layout.ANSWER_WIDTH else narrower
            mbuilder.set_answer_width(answer_width)
            continue
        break
    for card_file, pdf in card_pdfs:
        if collate_cards:
            add_card(card_writer, pdf, pagesize, pad_cards, duplex)
        elif pad_cards or duplex:
            w = _writer()
            add_card(w, pdf, pagesize, pad_cards, duplex)
            _save(w, out_dir / card_file)
        else:
            (out_dir / card_file).write_bytes(pdf)
    if collate_cards:
        _save(card_writer, out_dir / collated_name)
        written.append(collated_name)
    else:
        written.append(f"{len(people)} {'single-page quiz' if single else 'answer card'} file(s)")

    # ---- answer key: one page, one QR code
    (out_dir / "answer_key.pdf").write_bytes(answer_key_pdf(pagesize, fonts, family, quiz, key_qr, args.qr_quality, protected=key_qr is not key_data))
    written.append("answer_key.pdf")

    # ---- attendance sheet
    if attendance is not None:
        headers, rows = attendance
        sheet = landscape(pagesize) if args.attendance_orientation == "landscape" else pagesize
        (out_dir / "attendance.pdf").write_bytes(attendance_pdf(sheet, fonts, family, quiz.title, headers, rows))
        written.append("attendance.pdf")

    # ---- answer key + manifest (for marking)
    most = max(len(r) for r in key_rows) - 5
    semicolons = (args.csv_separator or ("semicolon" if args.print_language == "fr" else "comma")) == "semicolon"
    with open(out_dir / "answer_key.csv", "w", newline="", encoding="utf-8-sig") as fh:
        wr = csv.writer(fh, delimiter=";" if semicolons else ",")
        wr.writerow([t("csv_serial"), t("csv_name"), t("csv_number"), t("csv_variant"), t("csv_seat")] + [f"Q{i}" for i in range(1, most + 1)])
        for row in key_rows:
            # with semicolons, numbers take the decimal comma, as the spreadsheet expects
            wr.writerow([re.sub(r"(?<=\d)\.(?=\d)", ",", str(v)) if semicolons and i >= 5 else v for i, v in enumerate(row)])
    manifest = {
        "builder": f"{__app_name__} {__version__}", "seed": seed,
        "quiz": {"ident": quiz.ident, "title": quiz.title, "hash": f"{qr_payload.quiz_hash(quiz.ident):08x}",
                 "question_index_bits": qr_payload.index_bits(pool_size)},
        "options": {"max-items": args.max_items, "ignore-item-banks": args.ignore_item_banks, "item-banks-followed": selector.mode == "useitembanks",
                    "title-map": args.title_map, "variants": args.variants, "page-size": page_name,
                    "page-options": sorted(page_opts), "columns": args.columns if merged else None,
                    "pad-options": pad_to is not None, "pad-to": pad_to, "qr-quality": args.qr_quality,
                    "cell-shading": round(shading * 100, 1), "answer-width": answer_width,
                    "cjk-region": cjk_region if cjk_found else None, "cjk-font": fonts.cjk_used},
        "student_number_column": list_info["number_column"],
        "qr_fields": list_info["qr_fields"],
        "answer_key_payload_hex": key_data.hex(),          # plain (schema 0x11), for checking
        "answer_key_qr_hex": key_qr.hex(),                 # as printed (schema 0x18 when password protected)
        "answer_key_protected": key_qr is not key_data,
        "questions": [{"index": q.index, "export_index": q.export_index, "ident": q.ident, "title": q.title,
                                "type": q.qtype, "kind": q.kind, "points": q.points, "options": len(q.options),
                                **({"answers": [a for _v, a in q.value_sets], "tolerance": q.tolerance,
                                    "tolerance_percent": q.tolerance_percent} if q.kind == "numeric" else {}),
                                **({"accepted": q.accepted} if q.kind == "text" else {}),
                                "empty_options": [i for i, o in enumerate(q.options) if o.empty],
                                "correct_options": [i for i, o in enumerate(q.options) if o.correct]}
                               for q in quiz.questions],
        "card_layout": None if single else geo,  # single-page layouts differ per card: see cards[].card_layout
        "cards": manifest_cards,
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    written += ["answer_key.csv", "manifest.json"]

    n_q = sorted({len(p["selection"]) for p in people})
    print(f"{__app_name__} {__version__}")
    say = lambda text: print(messages.translate(text))
    say(f"Quiz:      {quiz.title}")
    say(f"Questions: {'-'.join(map(str, (n_q[0], n_q[-1]))) if len(n_q) > 1 else n_q[0]} per exam (from {pool_size} usable in the export"
        f"{'; following the item banks\' "pick N" rules' if selector.mode == 'useitembanks' else ''})")
    say(f"Cards:     {len(students)} student(s), {args.blank_cards} blank(s)")
    say(f"Seed:      {seed}")
    say(f"Output:    {out_dir}  ({', '.join(written)})")
    if word.is_word_folder(root):
        # a Word document is read by guessing at its layout: show what was read, to check against it
        say("Read from the Word document (check the answers before printing):")
        for q in sorted(quiz.questions, key=lambda q: q.export_index):
            kind, answer, text, points = word.describe(q, canvas)
            say(f"  {q.title}: {messages.translate(kind)}, {messages.translate(answer)}, {points} pt  {text}")
    return 0


def main(argv=None):
    try:
        return run(argv)
    except ExamError as exc:
        print(f"{messages.prefix('ERROR')} {messages.translate(str(exc))}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
