"""MasterTest Builder - builds printable exams and answer cards from Canvas quiz exports."""

__version__ = "0.4.17"
__app_name__ = "MasterTest Builder"
