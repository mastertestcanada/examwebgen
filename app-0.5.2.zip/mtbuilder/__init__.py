"""MasterTest Builder - builds printable exams and answer cards from Canvas quiz exports."""

__version__ = "0.5.2"
__app_name__ = "MasterTest Builder"
