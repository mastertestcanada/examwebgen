"""The command line: the options, how they are read, and the checks of their values."""

import argparse
import difflib
import getpass
import re
import shlex
import sys
from pathlib import Path

from reportlab.lib.pagesizes import A4, letter

from . import __app_name__, __version__
from . import answer_card, canvas
from .errors import ExamError, warn
from . import merged as merged_layout
from . import i18n, messages
from .classlist import split_list


PAGE_OPTIONS = ("collate-answer-cards", "pad-answer-cards", "collate-exams", "title-page", "pad-title-page",
                "pad-exam", "collate-title-pages")

# --page-size values: (paper, kind)
PAGE_SIZES = {
    "letter": ("letter", "booklet"), "a4": ("a4", "booklet"),
    "letter-single-page": ("letter", "single"), "a4-single-page": ("a4", "single"),
    "letter-merged": ("letter", "merged"), "a4-merged": ("a4", "merged"),
    "tabloid-booklet": ("letter", "duplex"), "a3-booklet": ("a4", "duplex"),
}


# ------------------------------------------------------------------ parsing


def hint_option(value, default):
    """--calculated-instructions / --fill-blank-instructions / --fill-blank-text: None (not
    given) keeps the default; "none" (any case) or an empty string means print nothing."""
    if value is None:
        return default
    value = value.strip()
    return "" if value.lower() == "none" else value


class Parser(argparse.ArgumentParser):
    """argparse with "did you mean" suggestions and our error format."""

    def error(self, message):
        m = re.search(r"unrecognized arguments: (.*)", message)
        if m:
            known = [o for a in self._actions for o in a.option_strings]
            hints = []
            for word in m.group(1).split():
                if word.startswith("--"):
                    name = word.split("=")[0]
                    close = difflib.get_close_matches(name.lower(), known, n=1, cutoff=0.6)
                    hints.append(f"unknown option {name}" + (f"; did you mean {close[0]}?" if close else ""))
            if hints:
                message = "; ".join(hints)
        raise ExamError(message + "  (see --help)")


def build_parser():
    p = Parser(
        prog="mastertest_builder", allow_abbrev=False,
        description="Create printable exams and machine-readable answer cards from a Canvas or D2L Brightspace quiz export. "
                    "Options can also be read from a text file: mastertest_builder.py export.zip @options.txt",
    )
    g = p.add_argument_group("input")
    g.add_argument("export", nargs="?", help="Canvas or D2L Brightspace quiz export (.zip file or unpacked folder), or a Word document (.docx) written for Akindi's importer")
    g.add_argument("--list-quizzes", action="store_true", help="list the quizzes in the export and exit")
    g.add_argument("--quiz", type=int, metavar="#", help="which quiz to use when the export holds several")
    g.add_argument("--title", metavar="<text>",
                   help="the exam's name as printed (exams, answer cards, answer key, output folder) instead of the "
                        "quiz's name in the export or document")

    g = p.add_argument_group("question selection (default: every usable question, drawing \"pick N\" from item banks and question groups)")
    x = g.add_mutually_exclusive_group()
    x.add_argument("--max-items", type=int, metavar="#", help="a random subset of # questions per exam")
    x.add_argument("--ignore-item-banks", action="store_true",
                   help="print every question of the item banks and question groups instead of following their "
                        "\"pick N\" rules (followed by default)")
    x.add_argument("--title-map", metavar="<filename>",
                   help="CSV of 'question title,count': count questions are drawn from the questions with each title; "
                        "or the same written in place of a file as 'title=count; title=count' (\\; for a ; in a title)")
    g.add_argument("--variants", default="all", metavar="#|all",
                   help="number of randomized exam variants, or 'all' (default) for one per student")

    g = p.add_argument_group("students and answer cards")
    g.add_argument("--class-list", metavar="<filename>", help="CSV with student name, student number and optional seat")
    g.add_argument("--student-id-column", metavar="<column>",
                   help="class-list column to use as the student number (default: SIS User ID, SIS ID, SIS Login ID, OrgDefinedId or Username "
                        "when the class list has one with data, else the first column with a recognised "
                        "student-number header)")
    g.add_argument("--add-qr-field", default="", metavar="<columns>",
                   help="comma-separated class-list columns to store in each card's QR code after the name and number")
    g.add_argument("--blank-cards", type=int, default=0, metavar="#", help="number of blank (bubble-in ID) answer cards")
    g.add_argument("--no-name", action="store_true",
                   help="blank cards and sheets: no box for the student's name (the student number identifies them)")
    g.add_argument("--no-seat", action="store_true", help="blank cards and sheets: no seat boxes and bubbles")
    g.add_argument("--randomize-seats", action="store_true", help="assign random seats 1..N (replaces the class-list seat)")
    g.add_argument("--seat-labels", metavar="<seats>",
                   help='assign random seats drawn from this comma-separated list, e.g. "A1,A2,A3,B1,B2,B3"')
    g.add_argument("--qr-quality", default="M", type=str.upper, choices=["L", "M", "Q", "H"],
                   help="QR error-correction level: L (7%%), M (15%%, default), Q (25%%) or H (30%%)")
    g.add_argument("--password", action="store_true",
                   help="encrypt the answer-key QR code; you are asked to type a password, and the marking app "
                        "asks for it when it scans the key")

    g = p.add_argument_group("page layout and fonts (a length without a unit is in points)")
    g.add_argument("--page-size", default="letter", metavar="<size>",
                   help="letter (default) or a4; letter-single-page or a4-single-page (questions and answer area on "
                        "one page); letter-merged or a4-merged (each answer beside its question, one or more sheets); "
                        "tabloid-booklet or a3-booklet (folded booklets, two letter/A4 pages per side of a "
                        "tabloid/A3 sheet)")
    g.add_argument("--page-options", default="", metavar="<list>",
                   help="comma-separated: " + ", ".join(PAGE_OPTIONS))
    g.add_argument("--columns", type=int, choices=[1, 2], default=2,
                   help="merged page sizes: questions in 1 full-width column or 2 columns (default)")
    g.add_argument("--margin", default="0.75in", metavar="<len>", help="page margins, e.g. 0.75in (default), 2cm, 20mm, 54pt")
    for side in ("left", "right", "top", "bottom"):
        g.add_argument(f"--margin-{side}", default=None, metavar="<len>", help=f"{side} margin (overrides --margin)")
    g.add_argument("--font", default="Helvetica", metavar="<font>",
                   help="Helvetica (default), Times, Courier, a font supplied with the program, a font file or an installed font name (see --list-fonts)")
    g.add_argument("--font-size", type=float, default=None, metavar="<pt>",
                   help="base font size in points (default 11; 9 for the merged page sizes)")
    g.add_argument("--question-spacing", default=None, metavar="<len>",
                   help="space between one question and the next, e.g. 12pt, 0.25in, 5mm "
                        "(default 0.9 x the font size: 9.9pt at 11pt)")
    g.add_argument("--question-rules", choices=("on", "off"), default=None, type=str.lower,
                   help="a thin grey line between one question and the next, so each question is easy to "
                        "follow across to its answer (default: on for one-column merged sheets, off otherwise)")
    g.add_argument("--option-font", default=None, metavar="<font>",
                   help="font for the option letters (A, B, ...), chosen like --font (default: the question font)")
    g.add_argument("--print-language", default="en", type=str.lower, choices=sorted(i18n.LANGUAGES),
                   help="language of the printed text: instructions, headings, labels and the answer-card "
                        "instructions (en, the default, or fr); the quiz itself is printed as written")
    g.add_argument("--decimal-mark", type=str.lower, choices=["point", "comma"],
                   help="decimal mark for numbers the program prints and asks for: point (0.5) or comma (0,5); "
                        "default: the print language's (comma for fr). Marking accepts either")
    g.add_argument("--csv-separator", type=str.lower, choices=["comma", "semicolon"],
                   help="field separator of answer_key.csv: comma (with 0.5) or semicolon (with 0,5), as the "
                        "spreadsheet that opens it expects; default: semicolon for a print language that uses the decimal comma (fr). "
                        "Class lists and title maps are read with either")
    g.add_argument("--cjk-region", default="auto", type=str.lower, choices=["auto", "sc", "tc", "jp", "kr"],
                   help="Chinese, Japanese and Korean text: whose writing style to print it in, Simplified (sc) or "
                        "Traditional (tc) Chinese, Japanese (jp) or Korean (kr); auto (default): Japanese when the "
                        "quiz has kana, Korean when it has Hangul, else Simplified Chinese")
    g.add_argument("--cjk-font", metavar="<font>",
                   help="font for Chinese, Japanese and Korean characters, chosen like --font (default: one "
                        "installed on the computer for the region)")
    g.add_argument("--option-letters", default="circled", type=str.lower, choices=["circled", "filled", "plain"],
                   help="option letters as enclosed characters, circled (Ⓐ, the default) or filled (🅐), or plain (A)")
    g.add_argument("--option-font-size", type=float, default=None, metavar="<pt>", help="font size for the option letters")
    g.add_argument("--option-dot", action=argparse.BooleanOptionalAction, default=False,
                   help="print a period after each option letter (default: --no-option-dot)")
    g.add_argument("--option-columns", type=int, default=1, metavar="#", help="lay options out in this many columns (default 1)")
    g.add_argument("--show-points", action="store_true", help="print each question's point value")
    g.add_argument("--no-quiz-instructions", action="store_true", help="do not print the quiz instructions")
    g.add_argument("--no-option-pad", action="store_true",
                   help="print one bubble per printed option; by default every multiple-choice question gets as "
                        "many bubbles as the quiz's question with the most options")

    g.add_argument("--essay-space", default="1/4", choices=sorted(canvas.ESSAY_SIZES), metavar="1/4|1/2|3/4|1",
                   help="the space for an essay question's answer, as a fraction of a page, when its name in Canvas "
                        "does not give one such as \"(1/2 page)\" (default 1/4)")
    g.add_argument("--essay-space-all", action="store_true",
                   help="give every essay question the --essay-space, whatever its name says")

    g = p.add_argument_group("answer cards")
    g.add_argument("--answer-width", default=None, metavar="<len>",
                   help="width of the written-answer boxes, e.g. 1.5in or 110pt; bubbles, cells and rows scale with "
                        "it, so fewer or more questions fit. Default: 180 pt on one-column merged sheets, 90 pt on "
                        "two-column merged sheets, about 95 pt (letter) / 91 pt (A4) on answer cards")
    g.add_argument("--cell-shading", default="15", metavar="<percent>",
                   help="darkness of the shaded cells of number, short-answer, student-number and seat boxes, "
                        "as a percentage of black (default 15); 0 or none prints outlined boxes instead")
    g.add_argument("--answer-card-instructions", default=None, metavar="<filename>",
                   help="HTML file with the instructions printed on answer cards and merged sheets (same tags and "
                        "images as question text; default: answerCardInstructions.html next to mastertest_builder.py); "
                        "none prints no instructions")

    g = p.add_argument_group('question text ("none" or "" prints nothing)')
    g.add_argument("--calculated-instructions", default=None, metavar="<text>",
                   help="text printed under every calculated (formula) question in place of the standard instructions")
    g.add_argument("--fill-blank-text", default=None, metavar="<text>",
                   help="what is printed in place of the blank in fill-in-the-blank questions (default __________)")
    g.add_argument("--fill-blank-instructions", default=None, metavar="<text>",
                   help="text printed under every fill-in-the-blank question in place of the standard instructions")
    g.add_argument("--multiple-answer-instructions", default=None, metavar="<text>",
                   help='text printed under every multiple-answer question in place of "Select all that apply." '
                        '(questions limited to a number of answers keep "Select only N answers." unless none)')

    g = p.add_argument_group("attendance sheet (attendance.pdf, made whenever there is a class list)")
    g.add_argument("--add-attendance-field", default=None, metavar="<fields>",
                   help="comma-separated extra columns; a column of the class list shows its value, any other name "
                        "is left blank. The seat is included when seats are randomized")
    g.add_argument("--attendance-sort", default=None, metavar="<fields>",
                   help='comma-separated columns to sort by, e.g. "Seat" or "Section,Student Name"; add " desc" '
                        'to a column to reverse it (default: class-list order)')
    g.add_argument("--attendance-orientation", default="portrait", type=str.lower,
                   choices=["portrait", "landscape"], help="portrait (default) or landscape")

    g = p.add_argument_group("output")
    g.add_argument("-o", "--output", metavar="<folder>", help="output folder (default: the exam title)")
    g.add_argument("--seed", type=int, metavar="#", help="random seed, for reproducible runs")
    g.add_argument("--messages-language", type=str.lower, choices=list(messages.LANGUAGES), metavar="/".join(messages.LANGUAGES),
                   help="language of the program's messages (errors, warnings, the summary): en or fr; default: "
                        "the computer's language. --print-language sets the language of the exams")
    g.add_argument("--list-fonts", action="store_true",
                   help="list the fonts --font and --option-font can use (built in, supplied, installed) and stop")
    g.add_argument("--version", action="version", version=f"{__app_name__} {__version__}")
    return p


def expand_option_files(argv):
    """@<file> arguments: the file's lines are read as more arguments. Each line is split like a
    command line (quotes group words); blank lines and lines starting with # are skipped."""
    out = []
    for arg in argv:
        if arg.startswith("@") and len(arg) > 1:
            path = Path(arg[1:])
            try:
                text = path.read_text(encoding="utf-8-sig")
            except OSError as exc:
                raise ExamError(f"Could not read options file '{path}': {exc}")
            for line in text.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    try:
                        out += expand_option_files(shlex.split(line, posix=True))
                    except ValueError as exc:
                        raise ExamError(f"Options file '{path}': {exc} in: {line}")
        else:
            out.append(arg)
    return out


def parse_page_size(text):
    """--page-size -> (name, pagesize, kind) with kind booklet / single / merged / duplex."""
    name = text.strip().lower()
    if name not in PAGE_SIZES:
        raise ExamError(f"Unknown --page-size '{text}'. Choose from: {', '.join(PAGE_SIZES)}.")
    paper, kind = PAGE_SIZES[name]
    return name, letter if paper == "letter" else A4, kind


def parse_shading(text):
    """--cell-shading: a percentage of black, 0 (or off/none) for outlined boxes."""
    t = str(text).strip().lower().rstrip("%")
    if t in ("off", "none", "no", "false"):
        return 0.0
    try:
        v = float(t)
    except ValueError:
        raise ExamError(f"--cell-shading must be a percentage such as 15, or none; got '{text}'.")
    if not 0 <= v <= 40:
        raise ExamError(f"--cell-shading must be between 0 and 40 (percent); got {text}. "
                        "Darker shading hides pencil from the marking app.")
    return v / 100.0


ONE_COLUMN_ANSWER_WIDTH = 180   # default --answer-width on one-column merged sheets (two columns and cards: as before)


def parse_answer_width(text, pagesize, merged, one_column=False):
    """--answer-width: whole points, or None for the default layout (also when the default is given)."""
    if text is None:
        return None
    width = round(parse_length(text, "--answer-width"))
    if merged:
        default, low = merged_layout.ANSWER_WIDTH, 60
        if one_column:   # the QR code holds the width in one byte
            high = min(255, int(pagesize[0] - 2 * merged_layout.MARGIN - merged_layout.NUMBER_WIDTH
                                - merged_layout.GUTTER_AIR - 6 - 80))
            where = "on a one-column merged sheet"
        else:
            high = int(merged_layout.column_width(pagesize[0]) - merged_layout.NUMBER_WIDTH - merged_layout.GUTTER_AIR - 6 - 80)
            where = ("on a two-column merged sheet (the question text needs at least 80 pt; "
                     "--columns 1 allows up to 255 pt)")
    else:
        default, low = answer_card.default_answer_width(pagesize), 50
        high = int(pagesize[0] - 2 * 40 - 26 - 10 - 2)
        where = "on an answer card (one column of answers at the widest)"
    if not low <= width <= high:
        raise ExamError(f"--answer-width must be between {low} and {high} pt {where}; got {width} pt.")
    return None if abs(width - default) < 0.01 else width


def parse_length(text, what, minimum_bare=None):
    """A length in points; a number without a unit is in points. `minimum_bare`: a bare number
    below it is refused as a probable inch value (margins were inches before 0.3.5)."""
    m = re.match(r"^\s*([\d.]+)\s*(in|cm|mm|pt|)\s*$", str(text).lower())
    if not m:
        raise ExamError(f"Invalid {what} '{text}'. Use a number with in, cm, mm or pt (e.g. 0.75in, 2cm).")
    try:
        n = float(m.group(1))
    except ValueError:
        raise ExamError(f"Invalid {what} '{text}'.")
    if not m.group(2) and minimum_bare is not None and n < minimum_bare:
        raise ExamError(f"{what} {text} would be {text} points; a length without a unit is in points. "
                        f"Did you mean {text}in?")
    return n * {"": 1.0, "in": 72.0, "cm": 72 / 2.54, "mm": 72 / 25.4, "pt": 1.0}[m.group(2)]


def parse_page_options(text):
    chosen = set()
    for item in split_list(text):
        name = item.strip().lower()
        if name not in PAGE_OPTIONS:
            raise ExamError(f"Unknown page option '{item}'. Choose from: {', '.join(PAGE_OPTIONS)}.")
        chosen.add(name)
    return chosen


def ask_password():
    """Prompt for the answer-key password. At a terminal it is typed twice without being shown;
    when input is piped in (a script), one line is read instead."""
    if sys.stdin.isatty():
        for _ in range(3):
            first = getpass.getpass(messages.translate("Answer-key password: "))
            if not first:
                print(messages.translate("The password cannot be empty."), file=sys.stderr)
                continue
            if getpass.getpass(messages.translate("Type it again: ")) == first:
                password = first
                break
            print(messages.translate("The two entries did not match."), file=sys.stderr)
        else:
            raise ExamError("No password was set.")
    else:
        password = sys.stdin.readline().rstrip("\r\n")
        if not password:
            raise ExamError("--password: no password was supplied on standard input.")
    if len(password) < 12:
        warn("The password is short. Anyone who photographs the answer-key code can try passwords on "
             "their own computer; use a long passphrase (four or more random words).")
    return password
