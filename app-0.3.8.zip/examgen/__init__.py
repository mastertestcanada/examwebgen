"""Exam Generator - builds printable exams and answer cards from Canvas quiz exports."""

__version__ = "0.3.8"
__app_name__ = "Exam Generator"
