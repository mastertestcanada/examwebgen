"""Binary payloads of the QR codes (all integers big-endian).

ANSWER CARD - schema 0x02 (full-page card) or 0x04 (single-page quiz)
    1 byte   schema        0x02, or 0x04 when the answer area shares the page with
                           the questions (--page-size letter-single-page / a4-single-page);
                           the fields are identical, only the printed layout differs
    1 byte   flags         bit 0: 1 = blank card
                           bit 1: paper size, 0 = letter, 1 = A4
                           bit 2: 1 = every question has six bubbles (--pad-options)
                           bit 3: 1 = written-answer cells are shaded (--cell-shading),
                                  not outlined
                           bit 4: schema 0x07 only: 1 = large answer cells (15 x 19 pt,
                                  MasterTest Generator 0.2.3 and later); 0 = 13.2 x 16 pt
                           bits 5-7: card index, 0 for the first card of an exam;
                                     the card holds questions index * (answers per card) + 1
                                     onward (100 per card at the default answer width)
    4 bytes  hash          CRC-32 of the quiz identifier (UTF-8)
    1 byte   field count   number of data fields that follow
    variable data fields   each is 1 length byte followed by that many bytes of UTF-8.
                           Class-list cards: field 1 is the student name, field 2 the
                           student number, then the --add-qr-field columns in the order given.
                           The names of these fields are not on the card; they are
                           listed, in the same order, in the answer key.
                           Blank cards: a single field holding the card's 9-digit serial.
    2 bytes  questions     number of questions printed on this card
    rest     question map  for each question on this card, in printed order:
                             Q bits  index of the question in the pre-randomized order
                             then, depending on the question's kind in the answer key:
                               choice:  L bits  Lehmer code of the option shuffle
                               numeric: V bits  which worked example (value set) was printed;
                                        V = bits needed for (number of answers in the key - 1)
                               text:    nothing
                           packed most-significant bit first, zero padded to a byte.

Q is the number of bits needed for the largest question index in the export
(every usable question, including all item-bank questions).
L is the number of bits needed for n! - 1, where n is the number of options the
question has in the export (including options that are empty and not printed).
The shuffle is a permutation p of 0..n-1 where p[i] is the pre-randomized
position of the option in slot i; empty options keep their slot in p but are
skipped when lettering, so printed letter k is the k-th non-empty entry of p.

ANSWER KEY - schema 0x03
    1 byte   schema        always 0x03
    1 byte   flags         reserved, 0
    4 bytes  hash          CRC-32 of the quiz identifier (same value as on the cards)
    variable exam name     1 length byte followed by that many bytes of UTF-8
    1 byte   field count   number of field names that follow (0 without a class list)
    variable field names   each is 1 length byte followed by that many bytes of UTF-8:
                           the names of the data fields on class-list cards, in the
                           order the values appear there (name i describes field i)
    2 bytes  questions     number of questions N in the pre-randomized order
    N x 5    one record per question; record j is question number j+1 (index j):
               1 byte   n        number of options in the export (2-8)
               1 byte   present  bit i set = pre-randomized option i is printed (not empty)
               1 byte   correct  bit i set = pre-randomized option i is a correct answer
               2 bytes  points   point value x 100

ANSWER KEY WITH WRITTEN ANSWERS - schema 0x06
    Used when the exam has calculated or fill-in-the-blank questions; otherwise 0x03 is used.
    Header exactly as 0x03 (schema 0x06, flags, hash, exam name, field names, question count);
    then one record per question, starting with a kind byte:
      0 choice:  n, present mask, correct mask (1 byte each), points x 100 (2 bytes)
      1 numeric: points x 100 (2), tolerance kind (1: 0 = absolute, 1 = percent),
                 tolerance (length byte + text), answer count (1), answers (length byte + text each);
                 the card says which answer applies to the student
      2 text:    points x 100 (2), answer count (1), accepted answers (length byte + text each)

PASSWORD-PROTECTED ANSWER KEY - schema 0x05   (--password)
    1 byte   schema        always 0x05
    1 byte   flags         bit 0: 1 = key derived with PBKDF2 as below (always set; a
                           value of 0 is the single-SHA-256 scheme of version 0.1.11 only)
                           bit 1: 1 = the decrypted key is schema 0x06, 0 = schema 0x03
    4 bytes  hash          CRC-32 of the quiz identifier (same value as on the cards)
    variable exam name     1 length byte followed by that many bytes of UTF-8 (not secret:
                           it lets the marking app say which exam it wants a password for)
    12 bytes nonce
    rest     ciphertext    AES-256-GCM, 16-byte tag at the end

    associated data = all bytes before the nonce (schema, flags, hash, exam name)
    AES key    = PBKDF2-HMAC-SHA256( password as UTF-8, salt = the associated data,
                                     600,000 iterations, 32 bytes )
                 The salt contains the quiz hash and exam name, so the same password
                 gives a different key for every exam.
    plaintext  = everything in a schema 0x03 / 0x06 payload after the exam name
                 (field count, field names, question count, records)
    nonce      = first 12 bytes of SHA-256( AES key || associated data || plaintext )
    Decrypting and putting 0x03 (0x06 when flag bit 1 is set), 0x00, hash and exam name in
    front of the plaintext gives an ordinary answer key. The GCM tag fails when the password is wrong.
"""

import hashlib
import zlib
from math import factorial

SCHEMA = 0x02
PROTECTED_KEY_SCHEMA = 0x05
NONCE_BYTES = 12
SINGLE_PAGE_SCHEMA = 0x04
KEY_SCHEMA = 0x03
MERGED_SCHEMA = 0x07     # a sheet of a merged quiz: the answer positions follow the question map
KEY_SCHEMA_EXT = 0x06   # answer key that also holds numeric and text questions
FLAG_EXT = 0x02         # protected key: the encrypted payload is a schema 0x06 key
KEY_FIXED_BYTES = 10  # schema, flags, hash, name length, field count, question count
KEY_RECORD_BYTES = 5
MAX_FIELD_BYTES = 255
FIXED_BYTES = 9  # schema, flags, hash, field count, question count
WIDTH_FLAG = 0x80  # in the schema byte of a card: a 1-byte answer width (whole points, --answer-width) follows the hash
SCALE_FLAG = 0x40  # with WIDTH_FLAG: a 1-byte scale width follows the answer width; bubbles and box heights scale
                   # with it instead of with the answer width (merged sheets with answers wider than 120 pt)
CARD_FLAGS = WIDTH_FLAG | SCALE_FLAG


def index_bits(pool_size):
    """Bits used for an original question index (Q)."""
    return max(1, (max(pool_size, 1) - 1).bit_length())


def lehmer_bits(n):
    return (factorial(n) - 1).bit_length()


def lehmer_encode(perm):
    n, value = len(perm), 0
    for i, p in enumerate(perm):
        smaller = sum(1 for q in perm[i + 1:] if q < p)
        value += smaller * factorial(n - 1 - i)
    return value


def lehmer_decode(value, n):
    pool, perm = list(range(n)), []
    for i in range(n):
        f = factorial(n - 1 - i)
        perm.append(pool.pop(value // f))
        value %= f
    return perm


def quiz_hash(quiz_ident):
    return zlib.crc32(quiz_ident.encode("utf-8")) & 0xFFFFFFFF


def pack_field(text):
    """One length-prefixed string: a length byte, then up to 255 bytes of UTF-8."""
    raw = str(text).encode("utf-8")[:MAX_FIELD_BYTES]
    while True:  # never cut a multi-byte character in half
        try:
            raw.decode("utf-8")
            break
        except UnicodeDecodeError:
            raw = raw[:-1]
    return bytes([len(raw)]) + raw


def value_bits(count):
    """Bits used for the worked-example index of a calculated question with `count` examples."""
    return max(count - 1, 0).bit_length()


def entry_field(kind, perm, size):
    """(value, bit count) stored after the question index on a card.
    choice: Lehmer code of the option shuffle; numeric: index of the worked example; text: nothing."""
    if kind == "numeric":
        return perm[0], value_bits(size)
    if kind == "text":
        return 0, 0
    return lehmer_encode(perm), lehmer_bits(len(perm))


def encode(quiz_ident, blank, fields, entries, pool_size, card_index=0, single_page=False,
           a4=False, pad_options=False, shaded=False, large_cells=False, answer_width=None, answer_scale=None):
    """fields: the data-field values; entries: (pre-randomized question index, value, bit count)
    for each question printed on the card (see entry_field), or (index, permutation) for
    multiple-choice-only use."""
    if not 0 <= card_index <= 7:
        raise ValueError("card index must be 0-7")
    if len(fields) > 255:
        raise ValueError("at most 255 data fields fit in the QR code")
    flags = ((1 if blank else 0) | (2 if a4 else 0) | (4 if pad_options else 0) | (8 if shaded else 0)
             | (16 if large_cells else 0) | (card_index << 5))
    schema = SINGLE_PAGE_SCHEMA if single_page else SCHEMA
    scaled = answer_width is not None and answer_scale is not None and answer_scale != answer_width
    head = bytes([schema | (WIDTH_FLAG if answer_width is not None else 0) | (SCALE_FLAG if scaled else 0), flags])
    head += quiz_hash(quiz_ident).to_bytes(4, "big")
    for value in ([answer_width] if answer_width is not None else []) + ([answer_scale] if scaled else []):
        if not 1 <= value <= 255 or value != int(value):
            raise ValueError("answer width and scale must be whole numbers of points, 1-255")
        head += bytes([int(value)])
    head += bytes([len(fields)]) + b"".join(pack_field(f) for f in fields)
    head += len(entries).to_bytes(2, "big")
    qbits = index_bits(pool_size)
    acc, nbits = 0, 0
    for entry in entries:
        index, value, bits = entry if len(entry) == 3 else (entry[0], *entry_field("choice", entry[1], 0))
        acc = (acc << qbits) | index
        nbits += qbits
        acc = (acc << bits) | value
        nbits += bits
    pad = (-nbits) % 8
    acc <<= pad
    return head + acc.to_bytes((nbits + pad) // 8, "big")


def encode_merged(quiz_ident, blank, fields, entries, pool_size, sheet_index, first_number, spots,
                  a4=False, pad_options=False, shaded=False, large_cells=True, answer_width=None, answer_scale=None):
    """Schema 0x07, one sheet of a merged quiz: as schema 0x04, with the first question number on
    the sheet (2 bytes) before the question count, and after the (byte-padded) question map one
    2-byte value per question: bit 15 the column (0 left, 1 right), bits 0-14 the height of the
    centre of its answer below the top of the page, in tenths of a point."""
    body = encode(quiz_ident, blank, fields, entries, pool_size, card_index=sheet_index, a4=a4, pad_options=pad_options,
                  shaded=shaded, large_cells=large_cells, answer_width=answer_width, answer_scale=answer_scale)
    pos = _fields_end(body)
    out = bytes([MERGED_SCHEMA | (body[0] & CARD_FLAGS)]) + body[1:pos] + int(first_number).to_bytes(2, "big") + body[pos:]
    for col, y in spots:
        tenths = round(y * 10)
        if not 0 <= tenths < 0x8000 or col not in (0, 1):
            raise ValueError("answer position out of range")
        out += ((col << 15) | tenths).to_bytes(2, "big")
    return out


def _fields_end(data):
    """Position just after the data fields of a card payload."""
    pos = 6 + (1 if data[0] & WIDTH_FLAG else 0) + (1 if data[0] & SCALE_FLAG else 0)
    count = data[pos]
    pos += 1
    for _ in range(count):
        pos += 1 + data[pos]
    return pos


def decode(data, option_counts):
    """Inverse of encode(). option_counts[i] describes pre-randomized question i: its option count
    (an int) for a choice question, or the key's question dict (with "kind")."""
    schema = data[0] & ~CARD_FLAGS if data else -1
    if len(data) < FIXED_BYTES or schema not in (SCHEMA, SINGLE_PAGE_SCHEMA, MERGED_SCHEMA):
        raise ValueError("not a schema 0x02 / 0x04 / 0x07 answer-card payload")
    flags = data[1]
    answer_width = data[6] if data[0] & WIDTH_FLAG else None
    answer_scale = data[7] if answer_width is not None and data[0] & SCALE_FLAG else answer_width
    pos = 7 + (1 if answer_width is not None else 0) + (1 if data[0] & SCALE_FLAG else 0)
    fields = []
    for _ in range(data[pos - 1]):
        length = data[pos]
        fields.append(data[pos + 1:pos + 1 + length].decode("utf-8", "replace"))
        pos += 1 + length
    first_number = None
    if schema == MERGED_SCHEMA:
        first_number = int.from_bytes(data[pos:pos + 2], "big")
        pos += 2
    count = int.from_bytes(data[pos:pos + 2], "big")
    pos += 2
    qbits = index_bits(len(option_counts))
    stream = int.from_bytes(data[pos:], "big")
    remaining = (len(data) - pos) * 8
    entries = []
    for _ in range(count):
        remaining -= qbits
        index = (stream >> remaining) & ((1 << qbits) - 1)
        q = option_counts[index]
        kind = q.get("kind", "choice") if isinstance(q, dict) else "choice"
        n = q.get("options", 0) if isinstance(q, dict) else q
        bits = (value_bits(len(q["answers"])) if kind == "numeric" else 0 if kind == "text" else lehmer_bits(n))
        remaining -= bits
        code = (stream >> remaining) & ((1 << bits) - 1)
        entries.append((index, [code] if kind == "numeric" else [] if kind == "text" else lehmer_decode(code, n)))
    spots = None
    if schema == MERGED_SCHEMA:
        at = pos + ((len(data) - pos) * 8 - remaining + 7) // 8
        spots = []
        for k in range(count):
            v = int.from_bytes(data[at + 2 * k:at + 2 * k + 2], "big")
            spots.append((v >> 15, (v & 0x7FFF) / 10))
    return {
        "merged": schema == MERGED_SCHEMA,
        "first_number": first_number,
        "spots": spots,
        "single_page": schema == SINGLE_PAGE_SCHEMA,
        "answer_width": answer_width,
        "answer_scale": answer_scale,
        "blank": bool(flags & 1),
        "a4": bool(flags & 2),
        "pad_options": bool(flags & 4),
        "shaded": bool(flags & 8),
        "large_cells": bool(flags & 16),
        "card_index": (flags >> 5) & 0x07,
        "hash": int.from_bytes(data[2:6], "big"),
        "fields": fields,
        "entries": entries,
    }


def encode_key(quiz_ident, records, field_names=(), title=""):
    """records: list of (option_count, present_mask, correct_mask, points);
    field_names: names of the data fields on class-list cards, in card order."""
    if len(field_names) > 255:
        raise ValueError("at most 255 field names fit in the QR code")
    out = bytes([KEY_SCHEMA, 0]) + quiz_hash(quiz_ident).to_bytes(4, "big") + pack_field(title)
    out += bytes([len(field_names)]) + b"".join(pack_field(n) for n in field_names)
    out += len(records).to_bytes(2, "big")
    for n, present, correct, points in records:
        hundredths = round((points or 0) * 100)
        if not 0 <= hundredths <= 0xFFFF:
            raise ValueError(f"point value {points} cannot be stored (0 to 655.35)")
        out += bytes([n, present, correct]) + hundredths.to_bytes(2, "big")
    return out


def encode_key_ext(quiz_ident, records, field_names=(), title=""):
    """Schema 0x06: like 0x03, but each record starts with a kind byte, so numeric and text
    questions can be stored. records: ("choice", n, present, correct, points) |
    ("numeric", points, percent, tolerance, [answers]) | ("text", points, [answers])."""
    out = bytes([KEY_SCHEMA_EXT, 0]) + quiz_hash(quiz_ident).to_bytes(4, "big") + pack_field(title)
    out += bytes([len(field_names)]) + b"".join(pack_field(n) for n in field_names)
    out += len(records).to_bytes(2, "big")
    for rec in records:
        kind = rec[0]
        points = rec[1] if kind != "choice" else rec[4]
        hundredths = round((points or 0) * 100)
        if not 0 <= hundredths <= 0xFFFF:
            raise ValueError(f"point value {points} cannot be stored (0 to 655.35)")
        if kind == "choice":
            out += bytes([0, rec[1], rec[2], rec[3]]) + hundredths.to_bytes(2, "big")
        elif kind == "numeric":
            _, _, percent, tolerance, answers = rec
            out += bytes([1]) + hundredths.to_bytes(2, "big") + bytes([1 if percent else 0]) + pack_field(tolerance)
            out += bytes([len(answers)]) + b"".join(pack_field(a) for a in answers)
        else:
            answers = rec[2][:255]
            out += bytes([2]) + hundredths.to_bytes(2, "big") + bytes([len(answers)])
            out += b"".join(pack_field(a) for a in answers)
    return out


def decode_key(data):
    if len(data) < KEY_FIXED_BYTES or data[0] not in (KEY_SCHEMA, KEY_SCHEMA_EXT):
        raise ValueError("not a schema 0x03 / 0x06 answer-key payload")
    if data[0] == KEY_SCHEMA_EXT:
        return _decode_key_ext(data)
    title = data[7:7 + data[6]].decode("utf-8", "replace")
    pos, names = 7 + data[6], []
    count_fields = data[pos]
    pos += 1
    for _ in range(count_fields):
        length = data[pos]
        names.append(data[pos + 1:pos + 1 + length].decode("utf-8", "replace"))
        pos += 1 + length
    count = int.from_bytes(data[pos:pos + 2], "big")
    pos += 2
    questions = []
    for j in range(count):
        r = data[pos + j * KEY_RECORD_BYTES:pos + (j + 1) * KEY_RECORD_BYTES]
        n = r[0]
        questions.append({
            "number": j + 1, "kind": "choice", "options": n,
            "present": [i for i in range(n) if r[1] >> i & 1],
            "correct": [i for i in range(n) if r[2] >> i & 1],
            "points": int.from_bytes(r[3:5], "big") / 100,
        })
    return {"hash": int.from_bytes(data[2:6], "big"), "title": title, "field_names": names, "questions": questions}



def _decode_key_ext(data):
    """Schema 0x06 (see encode_key_ext)."""
    pos = 6

    def byte():
        nonlocal pos
        pos += 1
        return data[pos - 1]

    def u16():
        nonlocal pos
        pos += 2
        return int.from_bytes(data[pos - 2:pos], "big")

    def string():
        nonlocal pos
        length = byte()
        pos += length
        return data[pos - length:pos].decode("utf-8", "replace")

    title = string()
    names = [string() for _ in range(byte())]
    questions = []
    for j in range(u16()):
        kind = byte()
        if kind == 0:
            n, present, correct = byte(), byte(), byte()
            questions.append({"number": j + 1, "kind": "choice", "options": n, "points": u16() / 100,
                              "present": [i for i in range(n) if present >> i & 1],
                              "correct": [i for i in range(n) if correct >> i & 1]})
        elif kind == 1:
            points = u16() / 100
            percent = bool(byte())
            tolerance = string()
            answers = [string() for _ in range(byte())]
            questions.append({"number": j + 1, "kind": "numeric", "options": 0, "points": points,
                              "percent": percent, "tolerance": tolerance, "answers": answers})
        else:
            points = u16() / 100
            answers = [string() for _ in range(byte())]
            questions.append({"number": j + 1, "kind": "text", "options": 0, "points": points, "answers": answers})
    return {"hash": int.from_bytes(data[2:6], "big"), "title": title, "field_names": names, "questions": questions}


KDF_ITERATIONS = 600_000
FLAG_PBKDF2 = 0x01


def _aes_key(password, header):
    """Deliberately slow, so that guessing passwords against a photographed key is expensive."""
    if hasattr(hashlib, "pbkdf2_hmac"):
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), header, KDF_ITERATIONS, 32)
    # Python in the browser (Pyodide) has no hashlib.pbkdf2_hmac; the same derivation from cryptography
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=header, iterations=KDF_ITERATIONS).derive(
        password.encode("utf-8"))


def _aesgcm(key):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        raise RuntimeError("--password needs the 'cryptography' package: pip install cryptography")
    return AESGCM(key)


def protect_key(payload, password):
    """Encrypt a schema 0x03 or 0x06 answer-key payload into a schema 0x05 one."""
    if payload[0] not in (KEY_SCHEMA, KEY_SCHEMA_EXT):
        raise ValueError("not a schema 0x03 / 0x06 answer-key payload")
    name_end = 7 + payload[6]
    flags = FLAG_PBKDF2 | (FLAG_EXT if payload[0] == KEY_SCHEMA_EXT else 0)
    header = bytes([PROTECTED_KEY_SCHEMA, flags]) + payload[2:name_end]
    plain = payload[name_end:]
    key = _aes_key(password, header)
    # Derived from the content, so the same key sheet is reproducible and a different
    # sheet under the same password never reuses a nonce.
    nonce = hashlib.sha256(key + header + plain).digest()[:NONCE_BYTES]
    return header + nonce + _aesgcm(key).encrypt(nonce, plain, header)


def unprotect_key(data, password):
    """Inverse of protect_key(); raises ValueError when the password is wrong."""
    if data[0] != PROTECTED_KEY_SCHEMA:
        raise ValueError("not a schema 0x05 answer-key payload")
    name_end = 7 + data[6]
    header = data[:name_end]
    nonce = data[name_end:name_end + NONCE_BYTES]
    if not data[1] & FLAG_PBKDF2:
        raise ValueError("this answer key uses a key scheme this version does not support")
    try:
        plain = _aesgcm(_aes_key(password, header)).decrypt(nonce, data[name_end + NONCE_BYTES:], header)
    except Exception:
        raise ValueError("wrong password, or the answer key is damaged")
    return bytes([KEY_SCHEMA_EXT if data[1] & FLAG_EXT else KEY_SCHEMA, 0]) + data[2:name_end] + plain
