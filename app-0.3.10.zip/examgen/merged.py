"""Merged single-page quizzes (page sizes letter-merged and A4-merged).

The questions and the answer spaces share the page: two columns of questions, each with an answer
gutter down its right side, where every question's bubbles, number box or text box sits level with
the question. A quiz runs onto further sheets when it does not fit on one. Every sheet carries a
compact header (title, name, student number, QR code) and the four corner squares.

The card QR code (schema 0x07) records, for every question on the sheet, which column it is in and
how far down the page its answer is, so a scanner can find the answers whatever the questions'
lengths. Everything else on the sheet is at fixed positions that depend only on the paper size;
MasterTest Marker's MergedGeometry must match the constants below.
"""

import io
from dataclasses import replace as dc_replace

from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import Spacer, Table, TableStyle

from .answer_card import draw_qr, draw_cells, SHADING
from .card_instructions import CardInstructions, draw as draw_instructions, height as instruction_height
from .canvas import question_html
from .errors import ExamError

# ---- fixed geometry (points; origin at the bottom-left corner of the page)
MARGIN = 40.0            # content left and right
INSET = 32.0             # centres of the corner squares, from the page edges
MARK = 14.0              # corner square size
QR_SIZE = 104.0          # QR code including its quiet zone, top right (large enough for 2-3 MP preview frames)
QR_TOP = 40.0            # from the top of the page
HEADER_BOTTOM = 156.0    # divider below the header, from the top of the page
CONTENT_TOP = 164.0      # first question, from the top of the page
CONTENT_BOTTOM = 52.0    # from the bottom of the page
COLUMN_GAP = 14.0
NUMBER_WIDTH = 20.0
PITCH = 13.2             # bubble pitch
BUBBLE_RADIUS = 5.4
CELL_W = 15.0            # one character cell of a number box (13.2 before 0.2.3: QR flag bit 4 clear)
BOX_HALF = 9.5           # boxes are 19 pt tall (16 before 0.2.3)
BOX_CELLS = 6
ANSWER_WIDTH = BOX_CELLS * CELL_W  # default width of the answer column (--answer-width); bubbles and boxes scale with it
SCALE_CAP = 120.0        # bubbles and box height scale with the answer width only up to this width (k <= 4/3)
GUTTER_AIR = 4.8         # the answer gutter is the answer width plus this
DIGIT_W = 15.0           # handwritten student-number and seat boxes
DIGIT_H = 22.0
ID_DIGITS = 9
SEAT_DIGITS = 3
MAX_CHOICES = 4
MAX_SHEETS = 8
LETTERS = "ABCD"


def column_width(W):
    return (W - 2 * MARGIN - COLUMN_GAP) / 2


def answer_scale(aw):
    """The width that sets the size of bubbles and the height of boxes: the answer width, at most
    SCALE_CAP, so wide answer boxes get longer rather than also taller (0.3.3; QR SCALE_FLAG)."""
    return min(aw, SCALE_CAP)


def gutter_left(W, col, aw=ANSWER_WIDTH):
    """Left edge of the answer gutter's widgets (bubble A's cell, or a box's left side) in column `col`."""
    cw = column_width(W)
    return MARGIN + col * (cw + COLUMN_GAP) + cw - aw - 2.0


def header_boxes(W, H):
    """Blank cards: (name box, first student-number box, first seat box) as (left, bottom, width, height)."""
    qr_left = W - MARGIN - QR_SIZE
    available = qr_left - 12 - MARGIN
    ids = ID_DIGITS * DIGIT_W
    seats = SEAT_DIGITS * DIGIT_W
    name_w = available - ids - seats - 2 * 14
    top = H - 69.0
    name = (MARGIN, top - DIGIT_H, name_w, DIGIT_H)
    id_left = MARGIN + name_w + 14
    seat_left = id_left + ids + 14
    return name, (id_left, top - DIGIT_H, DIGIT_W, DIGIT_H), (seat_left, top - DIGIT_H, DIGIT_W, DIGIT_H)


def fiducials(W, H):
    return [[INSET, H - INSET], [W - INSET, H - INSET], [INSET, INSET], [W - INSET, INSET]]


def widget_spots(W, col, yc, kind, bubbles, aw=ANSWER_WIDTH):
    """Bubble centres or the box of one answer, for the manifest and the drawing. Bubble pitch and
    size, and box height, scale with the answer width `aw` up to SCALE_CAP (answer_scale())."""
    gx = gutter_left(W, col, aw)
    k = answer_scale(aw) / ANSWER_WIDTH
    if kind == "choice":
        return {"bubbles": [[gx + k * PITCH / 2 + j * k * PITCH, yc] for j in range(bubbles)], "bubble_radius": BUBBLE_RADIUS * k}
    return {"box": [gx, yc - BOX_HALF * k, aw, 2 * BOX_HALF * k], "cells": BOX_CELLS if kind == "numeric" else 1}


def check_choices(questions):
    """Merged quizzes print at most four options per question."""
    for q in questions:
        if q.kind == "choice" and q.printed_option_count > MAX_CHOICES:
            label = q.title or q.ident
            raise ExamError(f"Question '{label}' ({q.ident}) has {q.printed_option_count} options; a merged "
                            f"--page-size allows at most {MAX_CHOICES} (A-D). Use another page size or shorten the question.")


class MergedBuilder:
    """Lays out and draws merged quizzes, using an ExamBuilder's renderer for the question text."""

    def __init__(self, exam_builder, pagesize, spacing=None, hints=(None, None), pad_options=False, shading=SHADING,
                 columns=2, answer_width=None, instructions=None):
        self.eb = exam_builder
        self.L = exam_builder.layout
        self.R = exam_builder.renderer
        self.W, self.H = pagesize
        self.spacing = 6.0 if spacing is None else spacing
        self.hints = hints            # (calculated, fill-in) instruction lines; None = none
        self.pad_options = pad_options
        self.shading = shading        # darkness of the shaded answer cells; 0 = outlined boxes
        # one column (--columns 1): the questions run the full width and every answer sits
        # in the right-hand gutter, exactly where column 1's answers are in the two-column layout,
        # so the QR code describes them the same way (column 1) and the marking app needs nothing new
        self.columns = columns
        self.aw = ANSWER_WIDTH if answer_width is None else answer_width   # --answer-width
        self.instructions = instructions or CardInstructions.load()        # --answer-card-instructions
        self.half = BOX_HALF * answer_scale(self.aw) / ANSWER_WIDTH                      # half the height of an answer box

    # ------------------------------------------------------------ question blocks
    def _block(self, question, perm, variables):
        """A flowable holding the question's text (and options) at the column's text width."""
        L, R = self.L, self.R
        width = self.text_width
        base = R.base_ctx()
        content = R.render(self.eb._html(question_html(question, perm), True, variables), width)
        hint = self.hints[0] if question.kind == "numeric" else self.hints[1] if question.kind == "text" else None
        if hint:
            content.append(R.paragraph(hint, dc_replace(base, italic=True), spaceBefore=2))
        if question.qtype == "multiple_answers_question":
            content.append(R.paragraph("Select all that apply.", dc_replace(base, italic=True), spaceBefore=1))
        if question.kind == "choice":
            printed = [question.options[i] for i in perm if not question.options[i].empty]
            content.append(Spacer(1, L.font_size * 0.2))
            content.append(self._options(printed, variables, width))
        if not content:
            content = [R.paragraph("", base)]
        block = Table([[content]], colWidths=[width])
        block.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                   ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                                   ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return block

    def _options(self, printed, variables, width):
        """The options, as many to a line as fit: 4, 2 or 1 columns."""
        L, R = self.L, self.R
        base = R.base_ctx()
        optface = self.eb.fonts.face(L.option_family)
        dot = "." if L.option_dot else ""
        letter_w = max(stringWidth(c + dot, optface, L.option_size) for c in LETTERS[:len(printed)]) + L.font_size * 0.5 + 1
        octx = dc_replace(base, family=L.option_family, size=L.option_size)
        one_line = L.font_size * 1.6
        for cols in (4, 2, 1):
            if cols > len(printed) and cols != 1:
                continue
            cell_w = width / cols
            cells, fits = [], True
            for k, opt in enumerate(printed):
                body = R.render(self.eb._html(opt.text, opt.is_html, variables), cell_w - letter_w - 4) or [R.paragraph("", base)]
                t = Table([[R.paragraph(LETTERS[k] + dot, octx), body]], colWidths=[letter_w, cell_w - letter_w])
                t.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                       ("RIGHTPADDING", (1, 0), (1, 0), 4),
                                       ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
                                       ("VALIGN", (0, 0), (-1, -1), "TOP")]))
                if t.wrap(cell_w, 100000)[1] > one_line:
                    fits = False
                cells.append(t)
            if fits or cols == 1:
                rows = [cells[i:i + cols] + [""] * (cols - len(cells[i:i + cols])) for i in range(0, len(cells), cols)]
                table = Table(rows, colWidths=[cell_w] * cols)
                table.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                           ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
                return table

    @property
    def text_width(self):
        if self.columns == 1:
            return self.W - 2 * MARGIN - NUMBER_WIDTH - self.aw - GUTTER_AIR - 6.0
        return column_width(self.W) - NUMBER_WIDTH - self.aw - GUTTER_AIR - 6.0

    def text_left(self, col):
        """Left edge of the question numbers in column `col`."""
        return MARGIN if self.columns == 1 else MARGIN + col * (column_width(self.W) + COLUMN_GAP)

    # ------------------------------------------------------------ layout
    def layout(self, selection, variables, who):
        """Places every question. Returns (instructions flowables, sheets); a sheet is a list of
        (selection index, column, block top, block, block height)."""
        H = self.H
        col_h = H - CONTENT_TOP - CONTENT_BOTTOM
        intro = []
        if self.L.instructions and self.eb.quiz.description:
            intro = self.R.render(self.eb._html(self.eb.quiz.description, True, variables), self.W - 2 * MARGIN)
        intro_h = sum(f.wrap(self.W - 2 * MARGIN, 100000)[1] + f.getSpaceBefore() + f.getSpaceAfter() for f in intro)
        if intro_h > col_h / 2:
            raise ExamError(f"The quiz instructions take {intro_h:.0f} pt, too much for a merged quiz for {who}. "
                            f"Shorten them or use --no-quiz-instructions.")
        first_col = 1 if self.columns == 1 else 0     # one column: its answers use column 1's gutter
        sheets, sheet, col = [], [], first_col
        y = H - CONTENT_TOP - (intro_h + 6 if intro else 0)
        for i, (q, perm) in enumerate(selection):
            block = self._block(q, perm, variables)
            h = max(block.wrap(self.text_width, 100000)[1], 2 * self.half + 1)
            if h > col_h:
                raise ExamError(f"Question {i + 1} ({q.ident}) is {h:.0f} pt tall, more than a column of a merged "
                                f"quiz ({col_h:.0f} pt). Use a smaller --font-size or another page size.")
            if y - h < CONTENT_BOTTOM:
                col += 1
                y = H - CONTENT_TOP
                if col == 2:
                    sheets.append(sheet)
                    sheet, col = [], first_col
            sheet.append((i, col, y, block, h))
            y -= h + self.spacing
        sheets.append(sheet)
        if len(sheets) > MAX_SHEETS:
            raise ExamError(f"The quiz for {who} needs {len(sheets)} sheets; a merged quiz can have at most {MAX_SHEETS}.")
        return intro, sheets

    def answer_y(self, block_top):
        """Centre of a question's answer: level with its first line."""
        return block_top - self.half

    # ------------------------------------------------------------ drawing
    def build(self, selection, variables, who, payload_for, *, quiz_title, blank, name, number, seat, variant,
              card_id, qr_quality):
        """Returns (pdf bytes, per sheet: {payload, first_number, spots}). payload_for(sheet index,
        first number, [selection indices], [(column, y from the top)]) gives a sheet's QR payload."""
        intro, sheets = self.layout(selection, variables, who)
        W, H = self.W, self.H
        fonts, L = self.eb.fonts, self.L
        font, bold = fonts.face(L.family), fonts.face(L.family, bold=True)
        buf = io.BytesIO()
        c = rl_canvas.Canvas(buf, pagesize=(W, H))
        c.setTitle(quiz_title)
        c.setAuthor("MasterTest Generator")
        out = []

        def safe(text, face):
            return "".join(ch if ch.isspace() or fonts.has_glyph(face, ch) else "?" for ch in str(text))

        for s, sheet in enumerate(sheets):
            first = sheet[0][0] + 1 if sheet else 1
            spots = [(col, round(H - self.answer_y(top), 1)) for _i, col, top, _b, _h in sheet]
            payload = payload_for(s, first, [i for i, *_ in sheet], spots)
            # corner squares
            c.setFillGray(0)
            for x, y in fiducials(W, H):
                c.rect(x - MARK / 2, y - MARK / 2, MARK, MARK, stroke=0, fill=1)
            # QR code and header
            qx, qy = W - MARGIN - QR_SIZE, H - QR_TOP - QR_SIZE
            draw_qr(c, payload, qx, qy, QR_SIZE, qr_quality)
            title = safe(quiz_title, bold)
            room = qx - 12 - MARGIN
            size = 13.0
            while size > 7 and stringWidth(title, bold, size) > room:
                size -= 0.5
            c.setFont(bold, size)
            c.drawString(MARGIN, H - 52, title)
            sheet_note = f"Sheet {s + 1} of {len(sheets)}" if len(sheets) > 1 else ""
            if blank:
                name_box, id_box, seat_box = header_boxes(W, H)
                c.setFont(bold, 6.5)
                c.drawString(name_box[0], name_box[1] + DIGIT_H + 3, "NAME (please print)")
                c.drawString(id_box[0], id_box[1] + DIGIT_H + 3, "STUDENT NUMBER")
                c.drawString(seat_box[0], seat_box[1] + DIGIT_H + 3, "SEAT")
                c.setLineWidth(0.8)
                c.setStrokeGray(0)
                c.rect(*name_box, stroke=1, fill=0)
                for box, n in ((id_box, ID_DIGITS), (seat_box, SEAT_DIGITS)):
                    draw_cells(c, box[0], box[1], n * DIGIT_W, DIGIT_H, n, self.shading)
                c.setFont(font, 7)
                bits = [f"Card {card_id}"] + ([f"Variant {variant}"] if variant else []) + ([sheet_note] if sheet_note else [])
                c.drawString(MARGIN, H - 103, "  ·  ".join(bits))
            else:
                c.setFont(font, 9)
                line = f"Name: {safe(name, font)}    Student number: {safe(number, font)}"
                if seat:
                    line += f"    Seat: {safe(seat, font)}"
                c.drawString(MARGIN, H - 72, line)
                c.setFont(font, 7)
                bits = [f"Card {card_id}"] + ([f"Variant {variant}"] if variant else []) + ([sheet_note] if sheet_note else [])
                c.drawString(MARGIN, H - 86, "  ·  ".join(bits))
            # instructions (--answer-card-instructions): below the header details, above the divider
            conditions = {"merged", "blank" if blank else "named"}
            if any(q.kind != "choice" for q, _p in selection):
                conditions.add("written")
            iw = qx - 10 - MARGIN
            flow = self.instructions.flowables(fonts, L.family, 7.0, iw, conditions)
            room = HEADER_BOTTOM - 4 - 113
            if instruction_height(flow, iw) > room:
                raise ExamError(f"The answer-card instructions are {instruction_height(flow, iw):.0f} pt tall; a merged "
                                f"sheet has room for {room:.0f} pt. Shorten the --answer-card-instructions file or its images.")
            draw_instructions(c, flow, MARGIN, H - 113, iw)
            c.setFont(font, 6.5)
            c.drawCentredString(qx + QR_SIZE / 2, qy - 7, safe(card_id, font))
            c.setStrokeGray(0.6)
            c.setLineWidth(0.5)
            c.line(MARGIN, H - HEADER_BOTTOM, W - MARGIN, H - HEADER_BOTTOM)
            c.setStrokeGray(0.8)
            if self.columns == 2:
                c.line(W / 2, H - CONTENT_TOP + 4, W / 2, CONTENT_BOTTOM - 2)
            c.setStrokeGray(0)
            # quiz instructions, first sheet only
            if s == 0 and intro:
                y = H - CONTENT_TOP
                for f in intro:
                    _w, h = f.wrap(W - 2 * MARGIN, 100000)
                    y -= f.getSpaceBefore()
                    f.drawOn(c, MARGIN, y - h)
                    y -= h + f.getSpaceAfter()
            # questions and their answers
            sheet_spots = []
            for (i, col, top, block, h) in sheet:
                q, perm = selection[i]
                cx = self.text_left(col)
                c.setFont(bold, L.font_size)
                c.setFillGray(0)
                c.drawRightString(cx + NUMBER_WIDTH - 4, top - L.font_size * 1.05, f"{i + 1}.")
                _bw, bh = block.wrapOn(c, self.text_width, 100000)
                block.drawOn(c, cx + NUMBER_WIDTH, top - bh)
                yc = self.answer_y(top)
                kind = q.kind
                n_bub = MAX_CHOICES if self.pad_options else q.printed_option_count if kind == "choice" else 0
                spot = widget_spots(W, col, yc, kind, n_bub, self.aw)
                spot.update({"number": i + 1, "kind": kind, "column": col, "y_from_top": round(H - yc, 1)})
                sheet_spots.append(spot)
                if kind == "choice":
                    r = spot["bubble_radius"]
                    for k, (bx, by) in enumerate(spot["bubbles"]):
                        c.setLineWidth(0.7)
                        c.setStrokeGray(0)
                        c.circle(bx, by, r, stroke=1, fill=0)
                        c.setFillGray(0.5)
                        c.setFont(font, 6 * r / BUBBLE_RADIUS)
                        c.drawCentredString(bx, by - 2.1 * r / BUBBLE_RADIUS, LETTERS[k])
                        c.setFillGray(0)
                else:
                    left, bottom, width, height = spot["box"]
                    draw_cells(c, left, bottom, width, height, spot["cells"], self.shading)
            c.showPage()
            out.append({"payload": payload, "first_number": first, "spots": sheet_spots,
                        "layout": {"page": [W, H], "fiducials": fiducials(W, H), "fiducial_size": MARK,
                                   "qr": {"x": qx, "y": qy, "size": QR_SIZE}, "merged": True, "answers": sheet_spots,
                                   **({"name_box": list(header_boxes(W, H)[0]), "id_box": list(header_boxes(W, H)[1]),
                                       "seat_box": list(header_boxes(W, H)[2])} if blank else {})}})
        c.save()
        return buf.getvalue(), out
