"""Glue for the in-browser version (web/): describes the command-line options so the page can
build its form from them, runs the program on files held in memory, and zips the result.

Everything here runs inside the visitor's browser (Pyodide). Input and output live in the
in-memory file system under /work, which disappears when the page is closed.
"""
import argparse
import io
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

from . import __version__, cli

WORK = Path("/work")
INPUT = WORK / "in"
OUTPUT = WORK / "out"
# options the page handles itself or does not show
HIDDEN = {"-h", "--help", "--version", "--list-quizzes", "--output", "-o", "--password"}


def _kind(action):
    if isinstance(action, argparse.BooleanOptionalAction):
        return "bool"
    if isinstance(action, argparse._StoreTrueAction):
        return "flag"
    if action.choices:
        return "choice"
    if action.metavar and "filename" in str(action.metavar):
        return "file"
    if action.type in (int, float):
        return "number"
    return "text"


def spec():
    """The options as JSON, grouped as in --help, for building the form."""
    parser = cli.build_parser()
    exclusive = {}
    for n, group in enumerate(parser._mutually_exclusive_groups):
        for a in group._group_actions:
            exclusive[id(a)] = n
    groups = []
    for group in parser._action_groups:
        options = []
        for a in group._group_actions:
            names = a.option_strings
            if not names:          # the export, chosen separately
                continue
            name = next((s for s in names if s.startswith("--")), names[0])
            if name in HIDDEN or a.help == argparse.SUPPRESS:
                continue
            kind, choices = _kind(a), [str(c) for c in a.choices] if a.choices else None
            if name == "--page-size":   # accepts many spellings; the form offers the canonical names
                kind, choices = "choice", list(dict.fromkeys(v[0] for v in cli.PAGE_SIZES.values()))
            options.append({
                "name": name, "kind": kind, "help": (a.help or "").replace("%%", "%"),
                "default": a.default if isinstance(a.default, (str, int, float, bool)) else None,
                "choices": choices,
                "metavar": str(a.metavar) if a.metavar else None,
                "exclusive": exclusive.get(id(a)),
            })
        if options:
            groups.append({"title": group.title, "options": options})
    return json.dumps({"version": __version__, "groups": groups})


def reset():
    """Empties /work (the files of the last run) and makes it ready for the next."""
    os.chdir("/")
    shutil.rmtree(WORK, ignore_errors=True)
    INPUT.mkdir(parents=True, exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    os.chdir(INPUT)


def run(argv, password=""):
    """Runs MasterTest Generator on the files in /work/in; returns the exit code. The password, if
    --password is used, is read from standard input as in a script."""
    os.chdir(INPUT)
    old_stdin = sys.stdin
    sys.stdin = io.StringIO(password + "\n")
    try:
        return cli.main(list(argv) + ["--output", str(OUTPUT)])
    except SystemExit as exc:          # argparse after --help and the like
        return exc.code if isinstance(exc.code, int) else 1
    finally:
        sys.stdin = old_stdin


def output_zip():
    """(file name, zip bytes) of everything the run wrote."""
    title = "exam_generator_output"
    manifest = OUTPUT / "manifest.json"
    if manifest.exists():
        title = cli.safe_name(json.loads(manifest.read_text(encoding="utf-8"))["quiz"]["title"], 80)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(OUTPUT.rglob("*")):
            if path.is_file():
                z.write(path, f"{title}/{path.relative_to(OUTPUT)}")
    return f"{title}.zip", buf.getvalue()
