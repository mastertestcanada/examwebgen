"""The language of MasterTest Builder's own messages: errors, warnings and the run summary
(--messages-language, by default the computer's language; MasterTest Web passes the page's).

Messages are written in English where they arise, and the program's own checks read that
English. They are translated only when shown: `translate(text)` matches the finished English
message against the templates below ({0}, {1} ... stand for the values in it) and writes the
French with the same values, each of which is translated too when it is itself a message or one
of the FRAGMENTS (such as the reason a question was left out). A message that matches no template
is shown in English. This is separate from --print-language, the language of the printed exams.
"""
import os
import re

LANGUAGES = ("en", "fr")
_language = "en"


def default_language():
    """fr when the computer's language is French, else en."""
    for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        v = os.environ.get(var, "")
        if v:
            return "fr" if v.lower().startswith("fr") else "en"
    return "en"


def set_language(language):
    global _language
    _language = language if language in LANGUAGES else "en"


def language():
    return _language


# (English template, French) -- the English exactly as the program writes it
FR = [
    # answer cards and keys
    ("An answer card holds at most {0} answers.", "Une carte-réponse contient au plus {0} réponses."),
    ("The answer-card instructions are {0} pt tall; the answer card has room for {1} pt. Shorten the --answer-card-instructions file or its images.",
     "Les consignes de la carte-réponse font {0} pt de haut; la carte-réponse a de la place pour {1} pt. Raccourcissez le fichier --answer-card-instructions ou ses images."),
    ("{0} bytes do not fit in one QR code at quality level {1}. Use a lower --qr-quality or fewer --add-qr-field columns.",
     "{0} octets ne tiennent pas dans un code QR de niveau {1}. Choisissez un --qr-quality plus bas ou moins de colonnes --add-qr-field."),
    ("{0} bytes do not fit in one QR code at quality level {1}. Use a lower --qr-quality.",
     "{0} octets ne tiennent pas dans un code QR de niveau {1}. Choisissez un --qr-quality plus bas."),
    ("Answer key: {0}", "Corrigé : {0}"),
    # the export
    ("{0} is not a valid XML file.", "{0} n'est pas un fichier XML valide."),
    ("Canvas export not found: {0}", "Export Canvas introuvable : {0}"),
    ("{0} is neither a folder nor a zip file.", "{0} n'est ni un dossier ni un fichier zip."),
    ("No quizzes were found in the Canvas export.", "Aucun questionnaire n'a été trouvé dans l'export Canvas."),
    ("Question '{0}' ({1}) has {2} options; at most {3} (A-F) are supported.",
     "La question « {0} » ({1}) a {2} choix; au plus {3} (A-F) sont pris en charge."),
    ("Question '{0}' ({1}) has {2} options in the export (including empty ones); at most {3} are supported. Delete the empty options in Canvas.",
     "La question « {0} » ({1}) a {2} choix dans l'export (vides compris); au plus {3} sont pris en charge. Supprimez les choix vides dans Canvas."),
    ("Question '{0}' ({1}) has {2} empty option(s) in the export; it is not printed.",
     "La question « {0} » ({1}) a {2} choix vide dans l'export; il n'est pas imprimé."),
    ("Question '{0}' ({1}) has {2} empty option(s) in the export; they are not printed.",
     "La question « {0} » ({1}) a {2} choix vides dans l'export; ils ne sont pas imprimés."),
    ("Quiz '{0}' contains no supported questions.", "Le questionnaire « {0} » ne contient aucune question prise en charge."),
    ("Could not read {0}: {1}", "Impossible de lire {0} : {1}"),
    ("Question '{0}' ({1}): {2} of its worked values have answers longer than {3} characters and are not used.",
     "Question « {0} » ({1}) : {2} de ses jeux de valeurs ont des réponses de plus de {3} caractères et ne sont pas utilisés."),
    ("Question '{0}' ({1}) in bank '{2}' was omitted: {3}.", "La question « {0} » ({1}) de la banque « {2} » a été omise : {3}."),
    ("Question '{0}' ({1}) was omitted: {2}.", "La question « {0} » ({1}) a été omise : {2}."),
    ("'{0}' asks for {1} question(s) but only {2} of its {3} are usable; using {4}.",
     "« {0} » demande {1} question(s), mais seulement {2} de ses {3} sont utilisables; {4} sont utilisées."),
    ("Unsafe path in zip file: {0}", "Chemin dangereux dans le fichier zip : {0}"),
    ("Item bank '{0}' ({1}) is not included in the export; its questions were omitted.",
     "La banque d'items « {0} » ({1}) n'est pas incluse dans l'export; ses questions ont été omises."),
    ("A question references item bank '{0}', which is not in the export; it was omitted.",
     "Une question renvoie à la banque d'items « {0} », absente de l'export; elle a été omise."),
    # answer-card instructions
    ("--answer-card-instructions: file not found: {0}", "--answer-card-instructions : fichier introuvable : {0}"),
    ("--answer-card-instructions: cannot read {0}: {1}", "--answer-card-instructions : impossible de lire {0} : {1}"),
    # options
    ("{0}  (see --help)", "{0}  (voir --help)"),
    ("Unknown --page-size '{0}'. Choose from: {1}.", "--page-size « {0} » inconnu. Choisissez parmi : {1}."),
    ("--cell-shading must be between 0 and 40 (percent); got {0}. Darker shading hides pencil from the marking app.",
     "--cell-shading doit être entre 0 et 40 (pour cent); reçu {0}. Un ombrage plus foncé cache le crayon à l'application de correction."),
    ("--cell-shading must be a percentage such as 15, or none; got '{0}'.",
     "--cell-shading doit être un pourcentage comme 15, ou none; reçu « {0} »."),
    ("--answer-width must be between {0} and {1} pt {2}; got {3} pt.", "--answer-width doit être entre {0} et {1} pt {2}; reçu {3} pt."),
    ("Invalid {0} '{1}'. Use a number with in, cm, mm or pt (e.g. 0.75in, 2cm).",
     "{0} invalide : « {1} ». Écrivez un nombre avec in, cm, mm ou pt (p. ex. 0.75in, 2cm)."),
    ("Invalid {0} '{1}'.", "{0} invalide : « {1} »."),
    ("{0} {1} would be {2} points; a length without a unit is in points. Did you mean {3}in?",
     "{0} {1} vaudrait {2} points; une longueur sans unité est en points. Vouliez-vous dire {3}in?"),
    ("Unknown page option '{0}'. Choose from: {1}.", "Option de page « {0} » inconnue. Choisissez parmi : {1}."),
    ("The password is short. Anyone who photographs the answer-key code can try passwords on their own computer; use a long passphrase (four or more random words).",
     "Le mot de passe est court. Quiconque photographie le code du corrigé peut essayer des mots de passe sur son propre ordinateur; utilisez une longue phrase de passe (quatre mots choisis au hasard ou plus)."),
    ("No password was set.", "Aucun mot de passe n'a été défini."),
    ("--password: no password was supplied on standard input.", "--password : aucun mot de passe n'a été fourni sur l'entrée standard."),
    ("The password cannot be empty.", "Le mot de passe ne peut pas être vide."),
    ("The two entries did not match.", "Les deux saisies ne correspondent pas."),
    ("Could not read options file '{0}': {1}", "Impossible de lire le fichier d'options « {0} » : {1}"),
    ("Options file '{0}': {1} in: {2}", "Fichier d'options « {0} » : {1} dans : {2}"),
    ("Could not read {0} '{1}': {2}", "Impossible de lire {0} « {1} » : {2}"),
    ("--title-map: '{0}' needs the form title=count.", "--title-map : « {0} » doit avoir la forme titre=nombre."),
    ("--title-map needs a filename.", "--title-map demande un nom de fichier."),
    ("Question titles not listed in the title map are left out of the exam: {0}",
     "Les titres de questions absents de la table des titres sont exclus de l'examen : {0}"),
    ("{0} selects no questions.", "{0} ne choisit aucune question."),
    ("{0}: '{1}' needs a whole number of questions, not '{2}'.", "{0} : « {1} » demande un nombre entier de questions, pas « {2} »."),
    ("{0}: no usable question in the export has the title '{1}'.", "{0} : aucune question utilisable de l'export n'a le titre « {1} »."),
    ("{0}: '{1}' asks for {2} questions but only {3} exist.", "{0} : « {1} » demande {2} questions, mais il n'en existe que {3}."),
    ("--max-items must be a number from 1 to {0} (the usable questions in the export).",
     "--max-items doit être un nombre de 1 à {0} (les questions utilisables de l'export)."),
    ("Give the Canvas quiz export (.zip file or unpacked folder) or Word document (.docx) to build from.",
     "Indiquez l'export du questionnaire Canvas (fichier .zip ou dossier décompressé) ou le document Word (.docx) à utiliser."),
    # Word documents
    ("{0} could not be read as a Word document ({1}).", "{0} n'a pas pu être lu comme document Word ({1})."),
    ("The Word document is too large to read ({0}).", "Le document Word est trop volumineux pour être lu ({0})."),
    ("The Word document is damaged ({0}).", "Le document Word est endommagé ({0})."),
    ("{0} is not a Word document (.docx).", "{0} n'est pas un document Word (.docx)."),
    ("The Word document has no text (word/document.xml is missing).", "Le document Word n'a pas de texte (word/document.xml manque)."),
    ("No questions that can be marked were found in the Word document '{0}'.",
     "Aucune question corrigeable n'a été trouvée dans le document Word « {0} »."),
    ("Question {0} was omitted: {1}.", "La question {0} a été omise : {1}."),
    ("Question {0} was omitted: it has {1} items; at most {2} are supported.",
     "La question {0} a été omise : elle a {1} éléments; au plus {2} sont pris en charge."),
    ("{0} paragraph(s) before the first question (such as a name line or instructions) are not printed; MasterTest prints its own instructions.",
     "{0} paragraphe(s) avant la première question (une ligne pour le nom, des consignes...) ne sont pas imprimés; MasterTest imprime ses propres consignes."),
    ("Read from the Word document (check the answers before printing):", "Lu dans le document Word (vérifiez les réponses avant d'imprimer) :"),
    ("  Question {0}: {1}, {2}, {3} pt  {4}", "  Question {0} : {1}, {2}, {3} pt  {4}"),
    ("The export contains {0} quizzes; choose one with --quiz <#>:\n{1}", "L'export contient {0} questionnaires; choisissez-en un avec --quiz <#> :\n{1}"),
    ("--quiz must be between 1 and {0} (see --list-quizzes).", "--quiz doit être entre 1 et {0} (voir --list-quizzes)."),
    ("collate-title-pages cannot be used with a booklet --page-size: the title page is always the first page of the booklet.",
     "collate-title-pages ne peut pas servir avec un --page-size en livret : la page de titre est toujours la première page du livret."),
    ("pad-title-page can only be used together with title-page or collate-title-pages.",
     "pad-title-page ne s'utilise qu'avec title-page ou collate-title-pages."),
    ("--columns applies only to the merged page sizes (letter-merged, a4-merged).",
     "--columns ne s'applique qu'aux formats fusionnés (letter-merged, a4-merged)."),
    ("{0} cannot be used with a single-page --page-size: the quiz and its answers start on the first page.",
     "{0} ne peut pas servir avec un --page-size d'une page : le questionnaire et ses réponses commencent à la première page."),
    ("collate-title-pages cannot be used with a merged --page-size: use title-page, which puts the title page before each student's first sheet.",
     "collate-title-pages ne peut pas servir avec un --page-size fusionné : utilisez title-page, qui place la page de titre avant la première feuille de chaque étudiant."),
    ("The margins leave too little room on the page.", "Les marges laissent trop peu de place sur la page."),
    ("--font-size must be between 4 and 72 points.", "--font-size doit être entre 4 et 72 points."),
    ("--option-columns must be 1 or more.", "--option-columns doit valoir 1 ou plus."),
    ("--blank-cards cannot be negative.", "--blank-cards ne peut pas être négatif."),
    ("Nothing to generate: give --class-list <filename>, --blank-cards <#>, or both.",
     "Rien à produire : indiquez --class-list <fichier>, --blank-cards <#>, ou les deux."),
    ("--variants must be a number (1 or more) or 'all'.", "--variants doit être un nombre (1 ou plus) ou « all »."),
    ("--student-id-column and --add-qr-field need a class list.", "--student-id-column et --add-qr-field nécessitent une liste de classe."),
    ("--randomize-seats / --seat-labels was ignored because there is no class list.",
     "--randomize-seats / --seat-labels a été ignoré faute de liste de classe."),
    ("--add-attendance-field and --attendance-sort need a class list.", "--add-attendance-field et --attendance-sort nécessitent une liste de classe."),
    ("This quiz has no item banks or question groups that pick fewer than all their questions; --ignore-item-banks changes nothing.",
     "Ce questionnaire n'a pas de banque d'items ni de groupe de questions qui en choisit une partie; --ignore-item-banks ne change rien."),
    ("The exam would have {0} questions; with a booklet --page-size the answer card is one folded sheet of {1} pages, so the limit is {2}. Use --max-items or --title-map to print fewer questions.",
     "L'examen aurait {0} questions; avec un --page-size en livret, la carte-réponse est une feuille pliée de {1} pages, donc la limite est {2}. Utilisez --max-items ou --title-map pour imprimer moins de questions."),
    ("The exam would have {0} questions; the limit is {1} ({2} answer cards of {3}). Use --max-items or --title-map to print fewer questions.",
     "L'examen aurait {0} questions; la limite est {1} ({2} cartes-réponses de {3}). Utilisez --max-items ou --title-map pour imprimer moins de questions."),
    ("At {0} pt answers some exams need more than {1} sheets; trying {2} pt (give --answer-width to choose the width yourself).",
     "Avec des réponses de {0} pt, certains examens demandent plus de {1} feuilles; essai à {2} pt (donnez --answer-width pour choisir la largeur vous-même)."),
    ("{0} Make the questions take less room: a narrower --answer-width (now {1} pt), a smaller --font-size or --question-spacing, more --option-columns, fewer questions (--max-items), two columns (if every question has at most four options), or a booklet --page-size.",
     "{0} Faites prendre moins de place aux questions : un --answer-width plus étroit (actuellement {1} pt), un --font-size ou un --question-spacing plus petit, plus de --option-columns, moins de questions (--max-items), deux colonnes (si chaque question a au plus quatre choix), ou un --page-size en livret."),
    ("The quiz does not fit on a single page for {0}: it has {1} questions.", "Le questionnaire ne tient pas sur une page pour {0} : il a {1} questions."),
    # class lists
    ("Class list '{0}' is empty.", "La liste de classe « {0} » est vide."),
    ("Class list '{0}' needs a 'student name' column.", "La liste de classe « {0} » doit avoir une colonne de nom d'étudiant (« student name »)."),
    ("Class list '{0}' has no students.", "La liste de classe « {0} » ne contient aucun étudiant."),
    ("{0}: the class list has no column named '{1}'. Its columns are: {2}.", "{0} : la liste de classe n'a pas de colonne « {1} ». Ses colonnes sont : {2}."),
    ("Class list '{0}' needs a 'student number' column (or name one with --student-id-column).",
     "La liste de classe « {0} » doit avoir une colonne de numéro d'étudiant (ou nommez-en une avec --student-id-column)."),
    ("Class list line {0} ({1}) was skipped: its '{2}' column is empty.", "La ligne {0} de la liste de classe ({1}) a été ignorée : sa colonne « {2} » est vide."),
    ("Class list line {0}: '{1}' value {2} appears more than once.", "Ligne {0} de la liste de classe : la valeur {2} de « {1} » apparaît plus d'une fois."),
    ("Class list line {0}: '{1}' is longer than {2} bytes and is cut short in the QR code.",
     "Ligne {0} de la liste de classe : « {1} » dépasse {2} octets et est tronqué dans le code QR."),
    ("--seat-labels lists {0} different seat(s) but the class list has {1} students.",
     "--seat-labels donne {0} place(s) différente(s), mais la liste de classe a {1} étudiants."),
    ("--attendance-sort: there is no column '{0}' on the attendance sheet or in the class list. The sheet's columns are: {1}.",
     "--attendance-sort : aucune colonne « {0} » sur la feuille de présences ni dans la liste de classe. Les colonnes de la feuille sont : {1}."),
    # pages and layout
    ("The quiz does not fit on a single page for {0}: {1} Use fewer questions (--max-items #), a smaller --font-size, smaller margins, more --option-columns, shorter quiz instructions (or --no-quiz-instructions), or a multi-page --page-size.",
     "Le questionnaire ne tient pas sur une page pour {0} : {1} Utilisez moins de questions (--max-items #), un --font-size plus petit, des marges plus petites, plus de --option-columns, des consignes plus courtes (ou --no-quiz-instructions), ou un --page-size de plusieurs pages."),
    ("the instructions and {0} question(s) need {1} pt of height but only {2} pt remain below the answer area.",
     "les consignes et {0} question(s) demandent {1} pt de hauteur, mais il ne reste que {2} pt sous la zone de réponse."),
    ("The exam could not be laid out on the page (is a table or image too large?): {0}",
     "L'examen n'a pas pu être mis en page (un tableau ou une image est-il trop grand?) : {0}"),
    ("Question '{0}' ({1}) has {2} options; a {3}-column merged --page-size allows at most {4} ({5}-{6}). Use --columns 1 (up to six options), another page size, or shorten the question.",
     "La question « {0} » ({1}) a {2} choix; un --page-size fusionné à {3} colonne(s) en permet au plus {4} ({5}-{6}). Utilisez --columns 1 (jusqu'à six choix), un autre format, ou raccourcissez la question."),
    ("Question '{0}' ({1}) has {2} options; a {3}-column merged --page-size allows at most {4} ({5}-{6}). Use another page size or shorten the question.",
     "La question « {0} » ({1}) a {2} choix; un --page-size fusionné à {3} colonne(s) en permet au plus {4} ({5}-{6}). Utilisez un autre format ou raccourcissez la question."),
    ("The quiz instructions take {0} pt, too much to leave room for question 1 on the first sheet, for {1}. Shorten them, print them on a title page (--page-options title-page) or use --no-quiz-instructions.",
     "Les consignes du questionnaire prennent {0} pt, trop pour laisser de la place à la question 1 sur la première feuille, pour {1}. Raccourcissez-les, imprimez-les sur une page de titre (--page-options title-page) ou utilisez --no-quiz-instructions."),
    ("--title cannot be empty.", "--title ne peut pas être vide."),
    ("Essay questions are not printed on single-page quizzes: {0} left out. Use a booklet or merged --page-size to print them, with the space for the answers at the end of the answer card.",
     "Les questions à développement ne sont pas imprimées sur les questionnaires d'une page : {0} laissée(s) de côté. Utilisez un --page-size en livret ou fusionné pour les imprimer, avec l'espace des réponses à la fin de la carte-réponse."),
    ("The answer card would need {0} pages with the essay spaces; the limit is {1}. Use smaller --essay-space or fewer questions.",
     "La carte-réponse aurait besoin de {0} pages avec les espaces de développement; la limite est {1}. Utilisez un --essay-space plus petit ou moins de questions."),
    ("Question {0} ({1}), an essay, has too long a text for its answer space ({2}/4 page). Give it more space, for example \"(1/2 page)\" in its name in Canvas or a larger --essay-space.",
     "La question {0} ({1}), à développement, a un texte trop long pour son espace de réponse ({2}/4 de page). Donnez-lui plus d'espace, par exemple « (1/2 page) » dans son nom dans Canvas, ou un --essay-space plus grand."),
    ("Question {0} ({1}) is {2} pt tall, more than a column of a merged quiz ({3} pt). Use a smaller --font-size or another page size.",
     "La question {0} ({1}) fait {2} pt de haut, plus qu'une colonne de questionnaire fusionné ({3} pt). Utilisez un --font-size plus petit ou un autre format."),
    ("The answer-card instructions are {0} pt tall; a merged sheet has room for {1} pt. Shorten the --answer-card-instructions file or its images.",
     "Les consignes de la carte-réponse font {0} pt de haut; une feuille fusionnée a de la place pour {1} pt. Raccourcissez le fichier --answer-card-instructions ou ses images."),
    # fonts
    ("Font file not found: {0}", "Fichier de police introuvable : {0}"),
    ("Font '{0}' was not found. Use Helvetica, Times, Courier, a font supplied with MasterTest Builder ({1}), the path to a TrueType/OpenType file, or the name of an installed font family (see --list-fonts).",
     "La police « {0} » est introuvable. Utilisez Helvetica, Times, Courier, une police fournie avec MasterTest Builder ({1}), le chemin d'un fichier TrueType/OpenType ou le nom d'une famille de polices installée (voir --list-fonts)."),
    ("Font '{0}': no {1} face was found; the closest available face is used instead.",
     "Police « {0} » : aucun style {1} n'a été trouvé; le style le plus proche est utilisé."),
    ("This quiz has {0} text, but no font for it was found on this computer, so those characters are printed as '?'. Install a font for it (such as Noto Sans CJK) or give --cjk-font with a font file; MasterTest Web supplies one.",
     "Ce questionnaire contient du texte en {0}, mais aucune police pour cette langue n'a été trouvée sur cet ordinateur : ces caractères s'impriment « ? ». Installez-en une (comme Noto Sans CJK) ou donnez --cjk-font avec un fichier de police; MasterTest Web en fournit une."),
    ("No {0} font was found on this computer; {1} is used for the Chinese, Japanese and Korean characters, so some may look different from {2} print.",
     "Aucune police pour le {0} n'a été trouvée sur cet ordinateur; {1} sert pour les caractères chinois, japonais et coréens, et certains peuvent différer de l'imprimé en {2}."),
    ("Unsupported font file type: {0} (use .ttf, .otf or .ttc)", "Type de fichier de police non pris en charge : {0} (utilisez .ttf, .otf ou .ttc)"),
    ("Could not read font file {0}", "Impossible de lire le fichier de police {0}"),
    ("Could not load font {0}: {1}", "Impossible de charger la police {0} : {1}"),
    ("No available font can draw the character {0} (U+{1}); it is printed as '?'.",
     "Aucune police disponible ne peut dessiner le caractère {0} (U+{1}); il s'imprime « ? »."),
    # question text
    ("Unknown variable [[{0}]] was left as written.", "La variable inconnue [[{0}]] a été laissée telle quelle."),
    ("Image could not be read ({0}): {1}", "L'image n'a pas pu être lue ({0}) : {1}"),
    ("Image '{0}' is not in the export; its description is printed instead.", "L'image « {0} » n'est pas dans l'export; sa description est imprimée à la place."),
    # MasterTest Web's own wording
    ("This file could not be read as a class list ({0}).", "Ce fichier n'a pas pu être lu comme liste de classe ({0})."),
    ("The class list is empty.", "La liste de classe est vide."),
    ("The class list needs a 'student name' column.", "La liste de classe doit avoir une colonne de nom d'étudiant (« student name »)."),
    ("The class list has no students.", "La liste de classe ne contient aucun étudiant."),
    ("The class list needs a 'student number' column (choose its student ID column under Class list options).",
     "La liste de classe doit avoir une colonne de numéro d'étudiant (choisissez-la dans les options de la liste de classe)."),
    ("This is neither a .zip file nor a Word document (.docx). In Canvas, export the quiz as a QTI .zip file.",
     "Ce n'est ni un fichier .zip ni un document Word (.docx). Dans Canvas, exportez le questionnaire en fichier QTI .zip."),
    ("This .zip file holds no Canvas quiz. In Canvas, export the quiz as a QTI .zip file.",
     "Ce fichier .zip ne contient aucun questionnaire Canvas. Dans Canvas, exportez le questionnaire en fichier QTI .zip."),
    ("This file could not be read as a Canvas quiz export ({0}).", "Ce fichier n'a pas pu être lu comme export de questionnaire Canvas ({0})."),
    # the command line's own errors (argparse)
    ("unrecognized arguments: {0}", "arguments non reconnus : {0}"),
    ("argument {0}: invalid choice: {1} (choose from {2})", "argument {0} : choix invalide : {1} (choisissez parmi {2})"),
    ("argument {0}: expected one argument", "argument {0} : une valeur est attendue"),
    ("argument {0}: invalid {1} value: {2}", "argument {0} : valeur {1} invalide : {2}"),
    ("argument {0}: not allowed with argument {1}", "argument {0} : incompatible avec l'argument {1}"),
    ("the following arguments are required: {0}", "les arguments suivants sont obligatoires : {0}"),
    ("unknown option {0}; did you mean {1}?", "option inconnue {0}; vouliez-vous dire {1}?"),
    ("unknown option {0}", "option inconnue {0}"),
    ("Answer-key password: ", "Mot de passe du corrigé : "),
    ("Type it again: ", "Tapez-le de nouveau : "),
    # the run summary
    ("Quiz:      {0}", "Questionnaire : {0}"),
    ("Questions: {0} per exam (from {1} usable in the export)", "Questions :     {0} par examen (sur {1} utilisables dans l'export)"),
    ("Questions: {0} per exam (from {1} usable in the export; {2})", "Questions :     {0} par examen (sur {1} utilisables dans l'export; {2})"),
    ("Cards:     {0} student(s), {1} blank(s)", "Cartes :        {0} étudiant(s), {1} vierge(s)"),
    ("Seed:      {0}", "Amorçage :      {0}"),
    ("Output:    {0}  ({1})", "Sortie :        {0}  ({1})"),
    ("Built into every PDF reader: Helvetica, Times, Courier", "Intégrées à tous les lecteurs PDF : Helvetica, Times, Courier"),
    ("Supplied with MasterTest Builder: {0}", "Fournies avec MasterTest Builder : {0}"),
    ("Installed on this computer ({0}):", "Installées sur cet ordinateur ({0}) :"),
    ("Or give the path of a .ttf, .otf or .ttc file.", "Ou donnez le chemin d'un fichier .ttf, .otf ou .ttc."),
    ("Preparing the font {0} for PDFs (done once; a large font such as a Chinese, Japanese or Korean one takes about a minute)...",
     "Préparation de la police {0} pour les PDF (une seule fois; une grande police, chinoise, japonaise ou coréenne par exemple, prend environ une minute)..."),
]

# values inside messages that are themselves English words
FRAGMENTS = {
    # why a question was left out
    "matching questions cannot be marked on an answer card": "les questions d'association ne peuvent pas être corrigées sur une carte-réponse",
    "it has no answer options and no blank (open-ended questions cannot be marked on an answer card)":
        "elle n'a ni choix de réponse ni trou (les questions ouvertes ne peuvent pas être corrigées sur une carte-réponse)",
    "no correct answer is marked (use bold, italics, highlighting, an asterisk or an 'Answer:' line)":
        "aucune bonne réponse n'est indiquée (gras, italique, surlignage, astérisque ou ligne « Answer: »)",
    "one of its options is empty": "un de ses choix est vide",
    "it has no items to match": "elle n'a aucun élément à associer",
    "matching": "association",
    # what was read from a Word document
    "multiple choice": "choix multiple", "multiple answers": "réponses multiples", "true/false": "vrai/faux",
    "number": "nombre", "fill in the blank": "texte à trou", "(marked by hand)": "(corrigé à la main)",
    "it has no answer options": "elle n'a aucun choix de réponse",
    "all of its answer options are empty": "tous ses choix de réponse sont vides",
    "it has no calculated-answer data": "elle n'a pas de données de réponse calculée",
    "the export has no worked values (var_sets) for it": "l'export n'a pas de jeux de valeurs (var_sets) pour elle",
    "it has no accepted answers": "elle n'a aucune réponse acceptée",
    # font faces
    "bold": "gras", "italic": "italique", "bold-italic": "gras italique",
    "bold, italic": "gras, italique", "bold, bold-italic": "gras, gras italique", "italic, bold-italic": "italique, gras italique",
    "bold, italic, bold-italic": "gras, italique, gras italique",
    # where an answer width applies
    "on a one-column merged sheet": "sur une feuille fusionnée à une colonne",
    "following the item banks' \"pick N\" rules": "selon les règles « choisir N » des banques d'items",
    "on an answer card (one column of answers at the widest)": "sur une carte-réponse (une seule colonne de réponses au plus large)",
    "on a two-column merged sheet (the question text needs at least 80 pt; --columns 1 allows up to 255 pt)":
        "sur une feuille fusionnée à deux colonnes (le texte des questions demande au moins 80 pt; --columns 1 permet jusqu'à 255 pt)",
    # regions
    "Simplified Chinese": "chinois simplifié", "Traditional Chinese": "chinois traditionnel", "Japanese": "japonais", "Korean": "coréen",
    # files and settings named in messages
    "class list": "la liste de classe", "title map": "la table des titres",
}
FRAGMENT_PATTERNS = [
    ("item '{0}' has no correct answer", "l'élément « {0} » n'a pas de bonne réponse"),
    ("it has {0} answers; at most {1} are supported", "elle a {0} réponses; au plus {1} sont prises en charge"),
    ("it has {0} items; at most {1} are supported", "elle a {0} éléments; au plus {1} sont pris en charge"),
    ("it has {0} options; at most {1} (A-F) are supported", "elle a {0} choix; au plus {1} (A-F) sont pris en charge"),
    ("question type '{0}' is not supported", "le type de question « {0} » n'est pas pris en charge"),
    ("its answer tolerance '{0}' is not a number", "sa tolérance de réponse « {0} » n'est pas un nombre"),
    ("none of its answers fit in the {0} answer boxes", "aucune de ses réponses ne tient dans les {0} cases"),
    ("it has {0} blanks; only fill-in-the-blank questions with one blank are supported",
     "elle a {0} trous; seuls les textes à un trou sont pris en charge"),
]


def _compile(pairs):
    out = []
    for en, fr in pairs:
        parts = re.split(r"\{(\d+)\}", en)
        pattern = "".join(re.escape(p) if i % 2 == 0 else f"(?P<v{p}>.*?)" for i, p in enumerate(parts))
        out.append((re.compile(pattern + r"\Z", re.S), fr))
    # most specific (longest literal text) first, so a general template does not catch a longer one
    out.sort(key=lambda x: -len(re.sub(r"\(\?P<v\d+>\.\*\?\)", "", x[0].pattern)))
    return out


_FR = None


def translate(text, language=None, _depth=0):
    """`text` in the messages language (`language`, by default the one set); English when no
    template matches."""
    global _FR
    lang = language or _language
    if lang == "en" or not text or _depth > 3:
        return text
    if _FR is None:
        _FR = _compile(FR + FRAGMENT_PATTERNS)
    s = str(text)
    if s in FRAGMENTS:
        return FRAGMENTS[s]
    for pattern, fr in _FR:
        m = pattern.match(s)
        if m:
            values = {k[1:]: translate(v, lang, _depth + 1) for k, v in m.groupdict().items()}
            return re.sub(r"\{(\d+)\}", lambda g: values.get(g.group(1), g.group(0)), fr)
    return s


def prefix(kind):
    """ERROR: / WARNING: in the messages language (MasterTest Web looks for either)."""
    if _language == "fr":
        return {"ERROR": "ERREUR :", "WARNING": "AVERTISSEMENT :"}[kind]
    return kind + ":"
