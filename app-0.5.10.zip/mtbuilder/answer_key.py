"""The answer-key page: one QR code holding, for every question in the
pre-randomized order, its point value and correct option(s)."""

import io

from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas as rl_canvas

from . import __version__, qr_payload
from .answer_card import draw_qr
from .errors import ExamError
from . import i18n
from .i18n import t


def key_payload(quiz, field_names=()):
    """The answer key's QR payload (schema 0x11)."""
    records = []
    for q in quiz.questions:  # already in pre-randomized order
        if q.kind == "numeric":
            records.append(("numeric", q.points, q.tolerance_percent, q.tolerance, [a for _v, a in q.value_sets]))
        elif q.kind == "text":
            records.append(("text", q.points, q.accepted))
        elif q.kind == "match":
            records.append(("match", q.points, q.cells, len(q.answers), [m + 1 for m in q.matches]))
        elif q.kind == "essay":
            records.append(("essay", q.points, q.essay_quarters))
        else:
            present = sum(1 << i for i, o in enumerate(q.options) if not o.empty)
            correct = sum(1 << i for i, o in enumerate(q.options) if o.correct)
            records.append(("choice", len(q.options), present, correct, q.points))
    try:
        return qr_payload.encode_key(quiz.ident, records, field_names, quiz.title, decimal_comma=i18n.decimal_comma())
    except ValueError as exc:
        raise ExamError(f"Answer key: {exc}")


def answer_key_pdf(pagesize, fonts, family, quiz, payload, qr_quality="M", protected=False):
    W, H = pagesize
    font, bold = fonts.face(family), fonts.face(family, bold=True)

    def safe(text, face):
        return "".join(ch if ch.isspace() or fonts.has_glyph(face, ch) else "?" for ch in str(text))

    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=pagesize)
    c.setTitle(f"{quiz.title} - answer key")
    c.setAuthor("MasterTest Builder")
    c.setFont(bold, 22)
    c.drawCentredString(W / 2, H - 80, t("answer_key"))
    title, size = safe(quiz.title, bold), 14.0
    while size > 7 and stringWidth(title, bold, size) > W - 100:
        size -= 0.5
    c.setFont(bold, size)
    c.drawCentredString(W / 2, H - 108, title)
    c.setFont(font, 10)
    c.drawCentredString(W / 2, H - 128, t("key_note") if not protected else t("key_note_password"))
    side = min(W - 110, H - 300)
    draw_qr(c, payload, (W - side) / 2, H - 150 - side, side, qr_quality)
    total = sum(q.points or 0 for q in quiz.questions)
    c.setFont(font, 9)
    c.drawCentredString(W / 2, H - 150 - side - 14,
                        f"{len(quiz.questions)} questions in pre-randomized order  -  quiz hash "
                        f"{qr_payload.quiz_hash(quiz.ident):08x}  -  {len(payload)} bytes")
    c.setFont(font, 7)
    c.setFillGray(0.4)
    c.drawCentredString(W / 2, 30, f"MasterTest Builder {__version__}")
    c.showPage()
    c.save()
    return buf.getvalue()
