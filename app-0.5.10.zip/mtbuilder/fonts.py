"""Font handling: built-in PDF fonts, TrueType/OpenType loading, automatic
bold/italic discovery, and fallback fonts for characters a font lacks."""

import atexit
import logging
import os
import shutil
import sys
import tempfile
from pathlib import Path

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont as RLTTFont

from .errors import ExamError, warn

BUILTIN = {
    "helvetica": {(0, 0): "Helvetica", (1, 0): "Helvetica-Bold", (0, 1): "Helvetica-Oblique", (1, 1): "Helvetica-BoldOblique"},
    "times": {(0, 0): "Times-Roman", (1, 0): "Times-Bold", (0, 1): "Times-Italic", (1, 1): "Times-BoldItalic"},
    "courier": {(0, 0): "Courier", (1, 0): "Courier-Bold", (0, 1): "Courier-Oblique", (1, 1): "Courier-BoldOblique"},
}
_BUILTIN_NAMES = {name for fam in BUILTIN.values() for name in fam.values()}

# CSS font-family names used by the Canvas editor -> (family, force bold)
CSS_FAMILIES = {
    "arial": ("helvetica", False), "helvetica": ("helvetica", False), "sans-serif": ("helvetica", False),
    "verdana": ("helvetica", False), "tahoma": ("helvetica", False), "trebuchet ms": ("helvetica", False),
    "arial black": ("helvetica", True), "impact": ("helvetica", True),
    "times new roman": ("times", False), "times": ("times", False), "georgia": ("times", False),
    "serif": ("times", False), "book antiqua": ("times", False), "palatino": ("times", False),
    "courier new": ("courier", False), "courier": ("courier", False), "monospace": ("courier", False),
    "andale mono": ("courier", False), "consolas": ("courier", False), "monaco": ("courier", False),
}

FONT_EXTENSIONS = (".ttf", ".otf", ".ttc")
# Fonts supplied with the program (fonts/): Open Sans (many alphabets) and Source Code Pro (for
# code), which can be chosen like any font; DejaVu Sans, for characters such as subscripts and
# arrows that the standard PDF fonts lack (on computers without a suitable font and in the browser
# version); and in fonts/enclosed/ MasterTest Enclosed, the circled and negative circled capital
# letters (Ⓐ, 🅐) of Noto Sans CJK, used for the option letters when the chosen font lacks them.
BUNDLED_FONTS = Path(__file__).resolve().parent.parent / "fonts"
ENCLOSED_FONT = BUNDLED_FONTS / "enclosed" / "MasterTestEnclosed.ttf"
CIRCLED_A, FILLED_A = 0x24B6, 0x1F150     # Ⓐ..Ⓩ and 🅐..🅩 (Unicode Enclosed Alphanumerics)


def enclosed_letter(index, style):
    """The option letter for option `index` (0 = A): plain, circled (Ⓐ) or filled (🅐)."""
    if style == "circled" and index < 26:
        return chr(CIRCLED_A + index)
    if style == "filled" and index < 26:
        return chr(FILLED_A + index)
    return chr(ord("A") + index)


# --------------------------------------------------------------- Chinese, Japanese, Korean
# Few fonts have these characters, so they come from a CJK font of their own: --cjk-font, or one
# installed on the computer for the region (Han characters are drawn differently in Simplified and
# Traditional Chinese, Japanese and Korean, so the region picks the font). MasterTest Web has no
# installed fonts: the page downloads the region's Noto Sans CJK and passes it as --cjk-font.
CJK_RANGES = ((0x1100, 0x11FF), (0x2E80, 0x2FDF), (0x2FF0, 0x2FFF), (0x3000, 0x303F), (0x3040, 0x30FF),
              (0x3100, 0x312F), (0x3130, 0x318F), (0x3190, 0x31FF), (0x3200, 0x33FF), (0x3400, 0x4DBF),
              (0x4E00, 0x9FFF), (0xA960, 0xA97F), (0xAC00, 0xD7FF), (0xF900, 0xFAFF), (0xFE10, 0xFE1F),
              (0xFE30, 0xFE4F), (0xFF00, 0xFFEF), (0x20000, 0x3FFFF))
CJK_REGIONS = {"sc": "Simplified Chinese", "tc": "Traditional Chinese", "jp": "Japanese", "kr": "Korean"}
# installed families to use, best first (Windows, macOS and Linux names)
CJK_FAMILIES = {
    "sc": ["Noto Sans CJK SC", "Noto Sans SC", "Source Han Sans SC", "Source Han Sans CN", "Microsoft YaHei",
           "PingFang SC", "Hiragino Sans GB", "Heiti SC", "STHeiti", "WenQuanYi Zen Hei", "WenQuanYi Micro Hei",
           "SimHei", "DengXian", "SimSun", "Droid Sans Fallback"],
    "tc": ["Noto Sans CJK TC", "Noto Sans TC", "Source Han Sans TC", "Source Han Sans TW", "Microsoft JhengHei",
           "PingFang TC", "Heiti TC", "Noto Sans CJK HK", "PingFang HK", "MingLiU", "PMingLiU"],
    "jp": ["Noto Sans CJK JP", "Noto Sans JP", "Source Han Sans JP", "Source Han Sans", "Yu Gothic", "Meiryo",
           "Hiragino Sans", "Hiragino Kaku Gothic ProN", "Hiragino Kaku Gothic Pro", "MS Gothic", "TakaoGothic",
           "IPAexGothic", "IPAGothic"],
    "kr": ["Noto Sans CJK KR", "Noto Sans KR", "Source Han Sans KR", "Source Han Sans K", "Malgun Gothic",
           "Apple SD Gothic Neo", "NanumGothic", "Gulim", "Dotum", "UnDotum"],
}
# words in the file names of those fonts, so only likely files are opened
_CJK_FILE_HINTS = ("noto", "sourcehan", "msyh", "msjh", "yahei", "jhenghei", "pingfang", "hiragino", "ヒラギノ",
                   "heiti", "yugoth", "meiryo", "msgothic", "malgun", "applesdgothic", "nanum", "wqy", "simhei",
                   "simsun", "deng", "mingliu", "gulim", "dotum", "takao", "ipa", "droidsansfallback", "undotum")


def is_cjk(cp):
    return any(a <= cp <= b for a, b in CJK_RANGES)


def detect_cjk(text):
    """The region a text's CJK characters suggest: Simplified Chinese when Han characters make up
    most of it (Traditional Chinese cannot be told apart reliably), else Japanese when it has more
    kana than Hangul, else Korean; None without CJK characters."""
    kana = hangul = han = 0
    for ch in text:
        cp = ord(ch)
        if 0x3040 <= cp <= 0x30FF or 0x31F0 <= cp <= 0x31FF:
            kana += 1
        elif 0xAC00 <= cp <= 0xD7AF or 0x1100 <= cp <= 0x11FF or 0x3130 <= cp <= 0x318F:
            hangul += 1
        elif 0x3400 <= cp <= 0x9FFF or 0xF900 <= cp <= 0xFAFF or 0x20000 <= cp <= 0x3FFFF:
            han += 1
    if han > 2 * (kana + hangul):     # mostly Chinese, with a few Japanese or Korean words
        return "sc"
    if kana or hangul:
        return "jp" if kana >= hangul else "kr"
    return None


def find_cjk_font(region):
    """(file, face index, family) of an installed font for the region, else for another region,
    else None."""
    files = []
    for d in system_font_dirs():
        for p in _font_files(d, True):
            name = p.name.lower().replace(" ", "").replace("-", "").replace("_", "")
            if any(h in name for h in _CJK_FILE_HINTS):
                files.append(p)
    faces = [(p, i, fam, cff) for p in files for i, fam, bold, italic, cff in _describe(p) if not bold and not italic]
    order = [region] + [r for r in CJK_FAMILIES if r != region]
    for r in order:
        for want in CJK_FAMILIES[r]:
            w = want.lower()
            exact = [f for f in faces if f[2].lower() == w]
            close = [f for f in faces if f[2].lower().startswith(w)]
            for p, i, fam, cff in exact + close:
                return p, i, fam, cff
    return None


def _is_enclosed(cp):
    return CIRCLED_A <= cp < CIRCLED_A + 26 or FILLED_A <= cp < FILLED_A + 26
_FALLBACK_FILES = [
    "DejaVuSans.ttf", "Arial Unicode.ttf", "arialuni.ttf", "seguisym.ttf", "NotoSans-Regular.ttf",
    "LiberationSans-Regular.ttf", "FreeSans.ttf", "segoeui.ttf", "Arial.ttf", "arial.ttf",
]


def system_font_dirs():
    if os.environ.get("MTBUILDER_NO_SYSTEM_FONTS"):   # tests: behave like a computer without fonts
        return []
    dirs = []
    if sys.platform.startswith("win"):
        dirs.append(Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts")
        local = os.environ.get("LOCALAPPDATA")
        if local:
            dirs.append(Path(local) / "Microsoft" / "Windows" / "Fonts")
    elif sys.platform == "darwin":
        dirs += [Path("/System/Library/Fonts"), Path("/Library/Fonts"), Path.home() / "Library" / "Fonts"]
    else:
        dirs += [Path("/usr/share/fonts"), Path("/usr/local/share/fonts"), Path.home() / ".fonts",
                 Path.home() / ".local" / "share" / "fonts"]
    return [d for d in dirs if d.is_dir()]


def _font_files(directory, recursive):
    it = directory.rglob("*") if recursive else directory.iterdir()
    try:
        return sorted(p for p in it if p.suffix.lower() in FONT_EXTENSIONS and p.is_file())
    except OSError:
        return []


def _describe(path):
    """[(index, family, bold, italic, is_cff)] for each face in a font file."""
    from fontTools.ttLib import TTCollection, TTFont

    out = []
    try:
        if path.suffix.lower() == ".ttc":
            faces = list(enumerate(TTCollection(str(path), lazy=True).fonts))
        else:
            faces = [(0, TTFont(str(path), lazy=True))]
        for index, f in faces:
            name = f["name"]
            family = name.getDebugName(1) or name.getDebugName(16) or path.stem
            sub = (name.getDebugName(2) or name.getDebugName(17) or "").lower()
            sel = f["OS/2"].fsSelection if "OS/2" in f else 0
            mac = f["head"].macStyle if "head" in f else 0
            bold = bool(sel & 0x20 or mac & 1 or "bold" in sub)
            italic = bool(sel & 0x01 or mac & 2 or "italic" in sub or "oblique" in sub)
            out.append((index, family.strip(), bold, italic, "CFF " in f or "CFF2" in f))
    except Exception:
        return []
    return out


def bundled_fonts():
    """{family name: file} for the fonts supplied with the program."""
    out = {}
    if BUNDLED_FONTS.is_dir():
        for p in _font_files(BUNDLED_FONTS, False):
            for _i, family, bold, italic, _c in _describe(p):
                if not bold and not italic:
                    out.setdefault(family, p)
    return out


def installed_families():
    """Sorted family names of the fonts installed on this computer."""
    names = set()
    for d in system_font_dirs():
        for p in _font_files(d, True):
            names.update(f[1] for f in _describe(p))
    return sorted(names, key=str.lower)


def _to_unicode_cmap(fontname, subset):
    """reportlab's ToUnicode CMap writes characters beyond U+FFFF (such as the filled letters 🅐)
    as five hex digits, which PDF readers misread when text is copied or read aloud; PDF wants
    them as UTF-16 surrogate pairs. Same CMap otherwise."""
    cmap = _ORIGINAL_CMAP(fontname, subset)
    if all(v <= 0xFFFF for v in subset):
        return cmap
    for i, v in enumerate(subset):
        if v > 0xFFFF:
            cmap = cmap.replace("<%02X> <%04X>" % (i, v), "<%02X> <%s>" % (i, chr(v).encode("utf-16-be").hex().upper()))
    return cmap


from reportlab.pdfbase import ttfonts as _ttfonts   # noqa: E402
_ORIGINAL_CMAP = _ttfonts.makeToUnicodeCMap
_ttfonts.makeToUnicodeCMap = _to_unicode_cmap

_tmpdir = None
logging.getLogger("fontTools").setLevel(logging.ERROR)   # odd timestamps etc. in installed fonts


def _cache_dir():
    """Where converted fonts are kept between runs (converting a large font takes a while), or a
    temporary folder when there is no writable cache (and in the browser)."""
    global _tmpdir
    if sys.platform != "emscripten":
        if sys.platform.startswith("win"):
            base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local") / "MasterTest" / "fonts"
        elif sys.platform == "darwin":
            base = Path.home() / "Library" / "Caches" / "MasterTest" / "fonts"
        else:
            base = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache") / "mastertest" / "fonts"
        try:
            base.mkdir(parents=True, exist_ok=True)
            return base
        except OSError:
            pass
    if _tmpdir is None:
        _tmpdir = Path(tempfile.mkdtemp(prefix="mtbuilder_fonts_"))
        atexit.register(shutil.rmtree, _tmpdir, ignore_errors=True)
    return _tmpdir


def _convert_cff(path, index=0):
    """reportlab cannot embed PostScript-flavoured OpenType; convert the outlines to TrueType.
    `index`: the face in a font collection (.ttc). Returns a single-font .ttf, kept in the cache
    so the conversion is done once per font file."""
    from fontTools.pens.cu2quPen import Cu2QuPen
    from fontTools.pens.ttGlyphPen import TTGlyphPen
    from fontTools.ttLib import TTFont, newTable

    st = path.stat()
    target = _cache_dir() / f"{path.stem}-{index}-{st.st_size}-{int(st.st_mtime)}.ttf"
    if target.exists():
        return target
    font = TTFont(str(path), fontNumber=index) if path.suffix.lower() == ".ttc" else TTFont(str(path))
    order = font.getGlyphOrder()
    if len(order) > 5000:
        from .messages import translate
        print(translate(f"Preparing the font {path.name} for PDFs (done once; a large font such as a Chinese, "
                        f"Japanese or Korean one takes about a minute)..."), file=sys.stderr, flush=True)
    glyph_set = font.getGlyphSet()
    glyphs = {}
    for name in order:
        pen = TTGlyphPen(glyph_set)
        glyph_set[name].draw(Cu2QuPen(pen, 1.0, reverse_direction=True))
        glyphs[name] = pen.glyph()
    font["loca"] = newTable("loca")
    font["glyf"] = glyf = newTable("glyf")
    glyf.glyphOrder = order
    glyf.glyphs = glyphs
    for tag in ("CFF ", "CFF2", "VORG"):
        if tag in font:
            del font[tag]
    glyf.compile(font)
    for name, (advance, _lsb) in list(font["hmtx"].metrics.items()):
        g = glyf[name]
        font["hmtx"].metrics[name] = (advance, getattr(g, "xMin", 0) if g.numberOfContours else 0)
    font["maxp"] = maxp = newTable("maxp")
    maxp.tableVersion = 0x00010000
    maxp.numGlyphs = len(order)
    for attr in ("maxZones", "maxTwilightPoints", "maxStorage", "maxFunctionDefs", "maxInstructionDefs",
                 "maxStackElements", "maxSizeOfInstructions", "maxComponentElements", "maxPoints",
                 "maxContours", "maxCompositePoints", "maxCompositeContours", "maxComponentDepth"):
        setattr(maxp, attr, 0)
    maxp.maxZones = 1
    post = font["post"]
    post.formatType = 3.0
    post.extraNames, post.mapping = [], {}
    font.sfntVersion = "\000\001\000\000"
    partial = target.with_suffix(".part")
    font.save(str(partial))
    os.replace(partial, target)
    return target


class FontManager:
    def __init__(self):
        self.families = {k: dict(v) for k, v in BUILTIN.items()}
        self._cmaps = {}
        self._fallback = None
        self._fallback_searched = False
        self._enclosed = None
        self._cjk = None          # the registered CJK font name, "" when there is none
        self.cjk_region = "sc"
        self.cjk_spec = None      # --cjk-font
        self.cjk_used = None      # what was used, for the manifest and messages
        self._counter = 0

    # ------------------------------------------------------------ loading
    def load(self, spec, quiet=False):
        """Make a font available and return its family key. `spec` is Helvetica,
        Times, Courier, a font supplied with the program, a path to a .ttf/.otf/.ttc file, or an
        installed family name. `quiet`: only the regular face is needed (the option letters), so a
        family without bold or italic faces is not reported."""
        self._quiet = quiet
        key = spec.strip().lower()
        if key in ("times-roman", "times roman", "times new roman"):
            key = "times"
        if key in ("courier new",):
            key = "courier"
        if key in self.families:
            return key
        path = Path(spec).expanduser()
        if path.is_file():
            if path.suffix.lower() not in FONT_EXTENSIONS:
                raise ExamError(f"Unsupported font file type: {path.name} (use .ttf, .otf or .ttc)")
            faces = _describe(path)
            if not faces:
                raise ExamError(f"Could not read font file {path}")
            family = faces[0][1]
            prefix = path.stem[:3].lower()
            candidates = [p for p in _font_files(path.parent, False) if p.stem[:3].lower() == prefix]
            return self._register_family(family, candidates, preferred=path)
        if any(spec.lower().endswith(e) for e in FONT_EXTENSIONS) or os.sep in spec:
            raise ExamError(f"Font file not found: {spec}")
        # a font supplied with the program
        for family, p in bundled_fonts().items():
            if family.lower() == key:
                return self._register_family(family, _font_files(BUNDLED_FONTS, False), preferred=p)
        # an installed family name
        wanted = key.replace(" ", "")
        candidates = []
        for d in system_font_dirs():
            for p in _font_files(d, True):
                stem = p.stem.lower().replace(" ", "").replace("-", "").replace("_", "")
                if stem.startswith(wanted[:4]):
                    candidates.append(p)
        fam = None
        for p in candidates:
            for _i, family, _b, _it, _c in _describe(p):
                if family.lower() == key:
                    fam = family
                    break
            if fam:
                break
        if not fam:
            raise ExamError(
                f"Font '{spec}' was not found. Use Helvetica, Times, Courier, a font supplied with "
                f"MasterTest Builder ({', '.join(sorted(bundled_fonts()))}), the path to a TrueType/OpenType "
                f"file, or the name of an installed font family (see --list-fonts)."
            )
        return self._register_family(fam, candidates)

    def _register_family(self, family, files, preferred=None):
        key = family.lower()
        if key in self.families:
            return key
        found = {}
        ordered = ([preferred] if preferred else []) + [f for f in files if f != preferred]
        for p in ordered:
            for index, fam, bold, italic, cff in _describe(p):
                if fam.lower() != key:
                    continue
                slot = (int(bold), int(italic))
                if slot not in found:
                    found[slot] = (p, index, cff)
        if preferred is not None and (0, 0) not in found:
            # the named file is e.g. a bold face: still use it as the regular font
            p0 = next(iter(_describe(preferred)))
            found[(0, 0)] = (preferred, p0[0], p0[4])
        if (0, 0) not in found:
            found[(0, 0)] = next(iter(found.values()))
        faces = {}
        for slot, (p, index, cff) in found.items():
            self._counter += 1
            name = f"EG{self._counter}-{family.replace(' ', '')}-{'B' if slot[0] else ''}{'I' if slot[1] else ''}R"[:60]
            try:
                src, sub = (_convert_cff(p, index), 0) if cff else (p, index)
                pdfmetrics.registerFont(RLTTFont(name, str(src), subfontIndex=sub))
            except Exception as exc:
                if slot == (0, 0):
                    raise ExamError(f"Could not load font {p}: {exc}")
                warn(f"Could not load font {p.name}: {exc}")
                continue
            faces[slot] = name
        missing = [n for s, n in (((1, 0), "bold"), ((0, 1), "italic"), ((1, 1), "bold-italic")) if s not in faces]
        if missing and not getattr(self, "_quiet", False):
            warn(f"Font '{family}': no {', '.join(missing)} face was found; the closest available face is used instead.")
        reg = faces[(0, 0)]
        faces.setdefault((1, 0), reg)
        faces.setdefault((0, 1), reg)
        faces.setdefault((1, 1), faces[(1, 0)] if faces[(1, 0)] != reg else faces[(0, 1)])
        self.families[key] = faces
        return key

    # ------------------------------------------------------------ lookup
    def face(self, family, bold=False, italic=False):
        return self.families[family][(int(bool(bold)), int(bool(italic)))]

    def css_family(self, value, base_family):
        """Resolve a CSS font-family list to (family key, force_bold)."""
        for name in value.split(","):
            name = name.strip().strip("'\"").lower()
            if name in self.families:
                return name, False
            if name in CSS_FAMILIES:
                return CSS_FAMILIES[name]
        return base_family, False

    def has_glyph(self, fontname, ch):
        cp = ord(ch)
        if fontname in _BUILTIN_NAMES:
            if cp < 0x7F or 0xA0 <= cp <= 0xFF:
                return True
            try:
                ch.encode("cp1252")
                return True
            except UnicodeEncodeError:
                return False
        cmap = self._cmaps.get(fontname)
        if cmap is None:
            cmap = self._cmaps[fontname] = pdfmetrics.getFont(fontname).face.charToGlyph
        return cp in cmap or cp in (0x20, 0xA0)

    def _fallback_font(self):
        if not self._fallback_searched:
            self._fallback_searched = True
            dirs = system_font_dirs() + ([BUNDLED_FONTS] if BUNDLED_FONTS.is_dir() else [])
            for d in dirs:
                files = {p.name.lower(): p for p in _font_files(d, True)}
                for wanted in _FALLBACK_FILES:
                    p = files.get(wanted.lower())
                    if p is not None:
                        try:
                            pdfmetrics.registerFont(RLTTFont("EG-Fallback", str(p)))
                            self._fallback = "EG-Fallback"
                            return self._fallback
                        except Exception:
                            continue
        return self._fallback

    def _enclosed_font(self):
        if self._enclosed is None:
            self._enclosed = ""
            if ENCLOSED_FONT.is_file():
                pdfmetrics.registerFont(RLTTFont("MT-Enclosed", str(ENCLOSED_FONT)))
                self._enclosed = "MT-Enclosed"
        return self._enclosed

    def set_cjk(self, region=None, spec=None):
        self.cjk_region = region or "sc"
        self.cjk_spec = spec
        self._cjk = None

    def _cjk_font(self):
        if self._cjk is not None:
            return self._cjk
        self._cjk = ""
        region = CJK_REGIONS.get(self.cjk_region, self.cjk_region)
        if self.cjk_spec:
            family = self.load(self.cjk_spec, quiet=True)
            self._cjk = self.face(family)
            self.cjk_used = family
            return self._cjk
        found = find_cjk_font(self.cjk_region)
        if found is None:
            warn(f"This quiz has {region} text, but no font for it was found on this computer, so those "
                 f"characters are printed as '?'. Install a font for it (such as Noto Sans CJK) or give "
                 f"--cjk-font with a font file; MasterTest Web supplies one.")
            return self._cjk
        p, index, family, cff = found
        if family.lower() not in [f.lower() for f in CJK_FAMILIES[self.cjk_region]] and \
                not any(family.lower().startswith(f.lower()) for f in CJK_FAMILIES[self.cjk_region]):
            warn(f"No {region} font was found on this computer; {family} is used for the "
                 f"Chinese, Japanese and Korean characters, so some may look different from {region} print.")
        src, sub = (_convert_cff(p, index), 0) if cff else (p, index)
        self._counter += 1
        name = f"EG{self._counter}-CJK"
        pdfmetrics.registerFont(RLTTFont(name, str(src), subfontIndex=sub))
        self._cjk = name
        self.cjk_used = family
        return self._cjk

    def width(self, text, fontname, size):
        """The width of text as runs() draws it, fallback fonts included."""
        return sum(pdfmetrics.stringWidth(t, f, size) for f, t in self.runs(text, fontname))

    def runs(self, text, fontname):
        """Split text into [(fontname, chunk)], switching to a fallback font for
        characters the requested font cannot draw."""
        if text.isascii() and fontname in _BUILTIN_NAMES:
            return [(fontname, text)]
        out = []
        for ch in text:
            use = fontname
            if not self.has_glyph(fontname, ch) and not ch.isspace():
                # enclosed letters: the supplied font, so they look the same whatever is installed;
                # Chinese, Japanese and Korean: the region's CJK font
                cp = ord(ch)
                fb = self._enclosed_font() if _is_enclosed(cp) else self._cjk_font() if is_cjk(cp) else None
                if fb and not self.has_glyph(fb, ch):
                    fb = None
                if not fb and is_cjk(cp) and not self._cjk:
                    ch = "?"      # reported once by _cjk_font
                    if out and out[-1][0] == use:
                        out[-1][1] += ch
                    else:
                        out.append([use, ch])
                    continue
                fb = fb or self._fallback_font()
                if fb and self.has_glyph(fb, ch):
                    use = fb
                else:
                    warn(f"No available font can draw the character {ch!r} (U+{ord(ch):04X}); it is printed as '?'.")
                    ch = "?"
            if out and out[-1][0] == use:
                out[-1][1] += ch
            else:
                out.append([use, ch])
        return [(f, t) for f, t in out]
