"""MasterTest Generator - builds printable exams and answer cards from Canvas quiz exports."""

__version__ = "0.4.0"
__app_name__ = "MasterTest Generator"
