"""The language of everything MasterTest Builder prints (--print-language), and the decimal mark
used for numbers on the page (--decimal-mark).

The printed language is separate from the language of the program's own messages: a teacher may
print a French test from an English program, or the reverse. Each text has one entry per
language; `t(key, **values)` returns it in the current print language. Numbers the program
prints (calculated-question values, points) use the decimal mark; the QR codes and the
answer_key.csv always use a point, so marking does not depend on the language.
"""

LANGUAGES = {"en": "English", "fr": "Français"}

# A non-breaking space, which French puts before ":" and inside « ».
NBSP = " "

TEXT = {
    # exam booklets and single-page quizzes
    "select_all": {"en": "Select all that apply.",
                   "fr": "Plusieurs réponses possibles."},
    "calc_hint": {"en": "Write your answer in the boxes on the answer card: one digit, minus sign or {mark} per box.",
                  "fr": "Écrivez votre réponse dans les cases de la carte-réponse : un chiffre, un signe moins ou {mark} par case."},
    "fill_hint": {"en": "Write your answer in the box on the answer card.",
                  "fr": "Écrivez votre réponse dans la case de la carte-réponse."},
    "match_hint": {"en": "For each item, write the number of its answer in the item's box on the answer card.",
                   "fr": "Pour chaque élément, écrivez le numéro de sa réponse dans la case de l'élément sur la carte-réponse."},
    "match_hint_merged": {"en": "Write the number of each item's answer in the box beside it.",
                          "fr": "Écrivez le numéro de la réponse de chaque élément dans la case à côté."},
    "mark_point": {"en": "decimal point", "fr": "un point décimal"},
    "mark_comma": {"en": "decimal comma", "fr": "une virgule"},
    "points_one": {"en": "({n} pt)", "fr": "({n} pt)"},
    "points_many": {"en": "({n} pts)", "fr": "({n} pts)"},
    "page_of": {"en": "Page {n} of {total}", "fr": "Page {n} de {total}"},
    "blank_label": {"en": "Blank {id}", "fr": "Vierge {id}"},
    # answer cards
    "answer_card": {"en": "ANSWER CARD", "fr": "CARTE-RÉPONSE"},
    "answers": {"en": "ANSWERS", "fr": "RÉPONSES"},
    "n_of_total": {"en": "{n} of {total}", "fr": "{n} de {total}"},
    "name_print": {"en": "NAME (please print)", "fr": "NOM (en lettres moulées)"},
    "student_number_caps": {"en": "STUDENT NUMBER", "fr": "NUMÉRO D'ÉTUDIANT"},
    "seat_caps": {"en": "SEAT", "fr": "PLACE"},
    "name": {"en": "Name", "fr": "Nom"},
    "student_number": {"en": "Student number", "fr": "Numéro d'étudiant"},
    "seat": {"en": "Seat", "fr": "Place"},
    "variant": {"en": "Variant", "fr": "Version"},
    "card": {"en": "Card", "fr": "Carte"},
    "sheet_of": {"en": "Sheet {n} of {total}", "fr": "Feuille {n} de {total}"},
    # answer key
    "answer_key": {"en": "ANSWER KEY", "fr": "CORRIGÉ"},
    "key_note": {"en": "Instructor copy - do not distribute. Scan this code with the marking software.",
                 "fr": "Copie de l'enseignant – ne pas distribuer. Numérisez ce code avec le logiciel de correction."},
    "key_note_password": {"en": "Password protected. Scan this code with the marking software and enter the password.",
                          "fr": "Protégé par mot de passe. Numérisez ce code avec le logiciel de correction et entrez le mot de passe."},
    # answer_key.csv headings
    "csv_serial": {"en": "card serial", "fr": "numéro de carte"},
    "csv_name": {"en": "name", "fr": "nom"},
    "csv_number": {"en": "student number", "fr": "numéro d'étudiant"},
    "csv_variant": {"en": "variant", "fr": "version"},
    "csv_seat": {"en": "seat", "fr": "place"},
    "csv_blank": {"en": "blank", "fr": "vierge"},
    # attendance sheet
    "student_name": {"en": "Student Name", "fr": "Nom de l'étudiant"},
    "student_number_column": {"en": "Student Number", "fr": "Numéro d'étudiant"},
    "attendance_title": {"en": "Attendance - {title}", "fr": "Présences – {title}"},
    "signature": {"en": "Signature", "fr": "Signature"},
}

_language = "en"
_comma = False


def set_language(language="en", decimal_mark=None):
    """`decimal_mark`: "point", "comma", or None for the language's usual mark (French: comma)."""
    global _language, _comma
    if language not in LANGUAGES:
        raise ValueError(f"unknown print language {language!r}")
    _language = language
    _comma = (decimal_mark == "comma") if decimal_mark else language == "fr"


def language():
    return _language


def decimal_comma():
    return _comma


def label(text):
    """A label followed by a colon, as the language writes it ("Nom :" in French)."""
    return f"{text}{NBSP}:" if _language == "fr" else f"{text}:"


def t(key, **values):
    entry = TEXT[key]
    text = entry.get(_language) or entry["en"]
    if "{mark}" in text:
        values.setdefault("mark", entry_text("mark_comma" if _comma else "mark_point"))
    return text.format(**values)


def entry_text(key):
    entry = TEXT[key]
    return entry.get(_language) or entry["en"]


def number(text):
    """A number as printed: with the decimal comma when that is the mark ("2.5" -> "2,5")."""
    text = str(text)
    return text.replace(".", ",") if _comma else text
