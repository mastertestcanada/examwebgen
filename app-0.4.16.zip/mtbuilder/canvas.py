"""Reads Canvas quiz exports (QTI 1.2) from both the Classic and New Quizzes engines."""

import atexit
import re
import random
import shutil
import sys
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from lxml import etree

from . import i18n, word
from .errors import ExamError, warn

CHOICE_TYPES = {
    "multiple_choice_question",
    "true_false_question",
    "multiple_answers_question",
}
NUMERIC_TYPES = {"calculated_question"}
TEXT_TYPES = {"fill_in_multiple_blanks_question", "short_answer_question"}
SUPPORTED_TYPES = CHOICE_TYPES | NUMERIC_TYPES | TEXT_TYPES

NUMERIC_BOXES = 6        # handwritten characters for a numeric answer (digits, "-" and ".")
MAX_VALUE_SETS = 32      # worked value sets kept per calculated question (5 bits on the card)
BLANK = "__________"     # printed in place of the blank in a fill-in-the-blank question
MAX_OPTIONS = 6          # printed options (A-F)
MAX_EXPORT_OPTIONS = 8   # options in the export, counting empty ones (answer-key masks are one byte)


@dataclass
class Option:
    ident: str
    text: str
    is_html: bool
    correct: bool
    export_pos: int = 0  # position of this option in the Canvas export

    @property
    def empty(self):
        return not self.text.strip()


@dataclass
class Question:
    ident: str
    title: str
    qtype: str
    points: Optional[float]
    html: str
    options: List[Option]
    bank_title: str = ""
    index: int = -1         # position in the pre-randomized (master) order
    export_index: int = -1  # position in the Canvas export
    kind: str = "choice"    # "choice" (bubbles), "numeric" (digit boxes) or "text" (written box)
    # numeric: worked examples from Canvas, each ({variable: value}, answer as written by Canvas)
    value_sets: List[tuple] = field(default_factory=list)
    tolerance: str = "0"            # numeric: allowed difference from the answer
    tolerance_percent: bool = False  # numeric: tolerance is a percentage of the answer
    accepted: List[str] = field(default_factory=list)  # text: every accepted answer

    @property
    def written(self):
        return self.kind != "choice"

    @property
    def printed_option_count(self):
        return sum(1 for o in self.options if not o.empty)


@dataclass
class Group:
    """A set of questions the export says to draw from (an item bank, a question
    group, or a single stand-alone question)."""

    label: str
    select: Optional[int]  # None = use every question
    indices: List[int] = field(default_factory=list)


@dataclass
class QuizInfo:
    number: int
    ident: str
    title: str
    path: Path


@dataclass
class Quiz:
    ident: str
    title: str
    description: str
    questions: List[Question]
    groups: List[Group]
    root: Path
    has_item_banks: bool = False


# ---------------------------------------------------------------- utilities

def _parse(path):
    """Parse an XML file and strip namespaces so tags can be matched by name."""
    try:
        tree = etree.parse(str(path), etree.XMLParser(recover=True, huge_tree=True))
    except (OSError, etree.XMLSyntaxError) as exc:
        raise ExamError(f"Could not read {path}: {exc}")
    root = tree.getroot()
    if root is None:
        raise ExamError(f"{path} is not a valid XML file.")
    for el in root.iter():
        if isinstance(el.tag, str) and "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]
    return root


def open_export(path):
    """Return a folder containing the export; zip files are unpacked to a temp folder."""
    p = Path(path)
    if not p.exists():
        raise ExamError(f"Canvas export not found: {path}")
    if p.is_dir():
        return p
    if word.is_word(p):
        return word.open_document(p)
    if not zipfile.is_zipfile(p):
        raise ExamError(f"{path} is neither a folder nor a zip file.")
    tmp = Path(tempfile.mkdtemp(prefix="examgen_"))
    atexit.register(shutil.rmtree, tmp, ignore_errors=True)
    with zipfile.ZipFile(p) as zf:
        for member in zf.infolist():
            target = (tmp / member.filename).resolve()
            if not str(target).startswith(str(tmp.resolve())):
                raise ExamError(f"Unsafe path in zip file: {member.filename}")
        zf.extractall(tmp)
    return tmp


def _manifest_resources(root_dir):
    """Map of resource identifier -> (type, href) from imsmanifest.xml."""
    out = {}
    mf = root_dir / "imsmanifest.xml"
    if not mf.exists():
        return out
    for res in _parse(mf).iter("resource"):
        href = res.get("href")
        if not href:
            f = res.find("file")
            href = f.get("href") if f is not None else None
        if href:
            out[res.get("identifier")] = (res.get("type") or "", href)
    return out


def list_quizzes(root_dir):
    if word.is_word_folder(root_dir):
        return [QuizInfo(1, word.quiz_ident(root_dir), word.quiz_title(root_dir), Path(root_dir) / word.SOURCE_NAME)]
    resources = _manifest_resources(root_dir)
    paths = [root_dir / href for typ, href in resources.values() if typ.startswith("imsqti_xml")]
    if not paths:  # no manifest: look for any QTI file holding an <assessment>
        paths = sorted(p for p in root_dir.rglob("*.xml") if p.name not in ("imsmanifest.xml", "assessment_meta.xml"))
    quizzes = []
    for p in paths:
        if not p.exists():
            continue
        a = _parse(p).find("assessment")
        if a is None:
            continue
        quizzes.append(QuizInfo(len(quizzes) + 1, a.get("ident") or p.stem, a.get("title") or p.stem, p))
    if not quizzes:
        raise ExamError("No quizzes were found in the Canvas export.")
    return quizzes


# ------------------------------------------------------------------ parsing

def _metadata(item):
    md = {}
    for f in item.iterfind("itemmetadata/qtimetadata/qtimetadatafield"):
        md[(f.findtext("fieldlabel") or "").strip()] = (f.findtext("fieldentry") or "").strip()
    return md


def _to_float(text):
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _correct_idents(item):
    """Identifiers of the correct responses, read from <resprocessing>."""
    correct = set()
    for cond in item.iterfind("resprocessing/respcondition"):
        score = None
        for sv in cond.iterfind("setvar"):
            score = _to_float(sv.text)
        if score is not None and score <= 0:
            continue
        cv = cond.find("conditionvar")
        if cv is None:
            continue
        for ve in cv.iter("varequal"):
            negated, anc = False, ve.getparent()
            while anc is not None and anc is not cv:
                negated = negated or anc.tag == "not"
                anc = anc.getparent()
            if not negated and ve.text:
                correct.add(ve.text.strip())
    return correct


def _parse_item(item, points_override=None, bank_title=""):
    """Returns (Question, None) or (None, reason-it-is-unsupported)."""
    md = _metadata(item)
    qtype = md.get("question_type", "")
    label = item.get("title") or item.get("ident") or "untitled"
    if qtype not in SUPPORTED_TYPES:
        return None, f"question type '{qtype or 'unknown'}' is not supported"
    if qtype in NUMERIC_TYPES or qtype in TEXT_TYPES:
        return _parse_written(item, md, qtype, points_override, bank_title)
    pres = item.find("presentation")
    lid = pres.find("response_lid") if pres is not None else None
    labels = list(lid.iterfind("render_choice/response_label")) if lid is not None else []
    if not labels:
        return None, "it has no answer options"
    mat = pres.find("material/mattext")
    html = _inner(mat)
    if mat is not None and (mat.get("texttype") or "text/html") == "text/plain" and not len(mat):
        html = _escape(html)
    correct = _correct_idents(item)
    options = []
    for lab in labels:
        mt = lab.find("material/mattext")
        text = _inner(mt)
        is_html = mt is not None and ((mt.get("texttype") or "text/plain") == "text/html" or len(mt) > 0)
        ident = lab.get("ident") or ""
        options.append(Option(ident, text, is_html, ident in correct, len(options)))
    points = points_override if points_override is not None else _to_float(md.get("points_possible"))
    q = Question(item.get("ident") or "", item.get("title") or "", qtype, points, html, options, bank_title)
    if q.printed_option_count > MAX_OPTIONS:
        raise ExamError(
            f"Question '{label}' ({q.ident}) has {q.printed_option_count} options; "
            f"at most {MAX_OPTIONS} (A-F) are supported."
        )
    if q.printed_option_count == 0:
        return None, "all of its answer options are empty"
    if len(q.options) > MAX_EXPORT_OPTIONS:
        raise ExamError(
            f"Question '{label}' ({q.ident}) has {len(q.options)} options in the export (including empty "
            f"ones); at most {MAX_EXPORT_OPTIONS} are supported. Delete the empty options in Canvas."
        )
    empty = len(q.options) - q.printed_option_count
    if empty:
        warn(f"Question '{label}' ({q.ident}) has {empty} empty option(s) in the export; "
             f"{'it is' if empty == 1 else 'they are'} not printed.")
    return q, None


def _question_html(item):
    pres = item.find("presentation")
    mat = pres.find("material/mattext") if pres is not None else None
    html = _inner(mat)
    if mat is not None and (mat.get("texttype") or "text/html") == "text/plain":
        html = _escape(html)
    return html


def _number(text):
    try:
        float(text)
        return True
    except (TypeError, ValueError):
        return False


def _parse_written(item, md, qtype, points_override, bank_title):
    """Calculated (numeric) and single-blank fill-in (text) questions."""
    html = _question_html(item)
    points = points_override if points_override is not None else _to_float(md.get("points_possible"))
    q = Question(item.get("ident") or "", item.get("title") or "", qtype, points, html, [], bank_title)
    label = item.get("title") or item.get("ident") or "untitled"

    if qtype in NUMERIC_TYPES:
        q.kind = "numeric"
        calc = item.find("itemproc_extension/calculated")
        if calc is None:
            return None, "it has no calculated-answer data"
        tol_el = calc.find("answer_tolerance")
        tol = ((tol_el.text if tol_el is not None else None) or "0").strip()
        q.tolerance_percent = tol.endswith("%") or (tol_el is not None and tol_el.get("margin_type") == "percent")
        q.tolerance = tol.rstrip("%").strip() or "0"
        if not _number(q.tolerance):
            return None, f"its answer tolerance '{tol}' is not a number"
        too_long = 0
        for vs in calc.iterfind("var_sets/var_set"):
            values = {(v.get("name") or ""): (v.text or "").strip() for v in vs.iterfind("var")}
            answer = (vs.findtext("answer") or "").strip().lstrip("+")
            if not _number(answer):
                continue
            if len(answer) > NUMERIC_BOXES:
                too_long += 1
                continue
            q.value_sets.append((values, answer))
        if not q.value_sets:
            if too_long:
                return None, f"none of its answers fit in the {NUMERIC_BOXES} answer boxes"
            return None, "the export has no worked values (var_sets) for it"
        if too_long:
            warn(f"Question '{label}' ({q.ident}): {too_long} of its worked values have answers longer than "
                 f"{NUMERIC_BOXES} characters and are not used.")
        q.value_sets = q.value_sets[:MAX_VALUE_SETS]
        return q, None

    q.kind = "text"
    pres = item.find("presentation")
    if qtype == "short_answer_question":       # Classic "fill in the blank": one blank, answers in resprocessing
        for cond in item.iterfind("resprocessing/respcondition"):
            for ve in cond.iter("varequal"):
                text = (ve.text or "").strip()
                if text and text not in q.accepted:
                    q.accepted.append(text)
    else:
        lids = list(pres.iterfind("response_lid")) if pres is not None else []
        if len(lids) != 1:
            return None, f"it has {len(lids)} blanks; only fill-in-the-blank questions with one blank are supported"
        lid = lids[0]
        token = (lid.get("ident") or "")[len("response_"):]
        labels = list(lid.iterfind("render_choice/response_label"))
        correct = _correct_idents(item)
        # Typed ("open entry") answers: every listed answer is accepted. Otherwise only the scored ones.
        open_entry = any(lab.get("answer_type") == "openEntry" for lab in labels)
        for lab in labels:
            if open_entry or (lab.get("ident") or "") in correct:
                text = _plain(lab.find("material/mattext")).strip()
                if text and text not in q.accepted:
                    q.accepted.append(text)
        if not q.accepted:   # no answer marked as scored: accept them all
            q.accepted = [t for t in (_plain(lab.find("material/mattext")).strip() for lab in labels) if t]
        if token:
            q.html = q.html.replace(f"[{token}]", BLANK)
    if not q.accepted:
        return None, "it has no accepted answers"
    return q, None


def _inner(el):
    """The content of a mattext (or description) element as HTML. Canvas writes the HTML as
    escaped text, so it is the element's text; other QTI tools write it as XHTML elements
    (<mattext texttype="text/html"><p>What does <strong>喝</strong> mean?</p></mattext>), or mix
    the two, and then the text before the first element is not all of it."""
    if el is None:
        return ""
    # each element as XHTML, and the text after it as it stands: a file can mix the two forms
    # (&lt;p&gt;What does <b>喝</b> mean?&lt;/p&gt;), and that text is HTML source like the rest
    inner = "".join(re.sub(r'\s+xmlns(?::\w+)?="[^"]*"', "", etree.tostring(c, encoding="unicode", with_tail=False))   # not the QTI namespace
                    + (c.tail or "") for c in el)
    return (el.text or "") + inner


def _plain(el):
    """The text of an element, whatever markup it holds (for accepted answers)."""
    return "".join(el.itertext()) if el is not None else ""


def question_html(question, perm):
    """The question text as printed. For a calculated question the variables are replaced by the
    values of the worked example chosen for this exam (perm[0])."""
    html = question.html
    if question.kind == "numeric" and perm:
        for name, value in question.value_sets[perm[0]][0].items():
            if not name:
                continue
            value = i18n.number(value)                  # 2,5 with the decimal comma
            html = re.sub(r"(?<!\[)\[" + re.escape(name) + r"\](?!\])", value, html)   # Classic: [x]
            html = html.replace(f"`{name}`", value)                                     # New Quizzes: `x`
    return html


def _escape(text):
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class _Loader:
    def __init__(self, root_dir):
        self.root_dir = root_dir
        self.resources = _manifest_resources(root_dir)
        self.banks = {}
        self.questions = []
        self.by_ident = {}
        self.groups = []
        self.has_banks = False

    def bank(self, ref):
        """Items of an item bank: (title, [item elements]) or None when not exported."""
        if ref in self.banks:
            return self.banks[ref]
        path = None
        if ref in self.resources:
            path = self.root_dir / self.resources[ref][1]
        if path is None or not path.exists():
            hits = sorted(self.root_dir.rglob(f"{ref}*"))
            path = hits[0] if hits else None
        result = None
        if path is not None and path.is_file():
            ob = _parse(path).find("objectbank")
            if ob is not None:
                title = ""
                for f in ob.iterfind("qtimetadata/qtimetadatafield"):
                    if (f.findtext("fieldlabel") or "").strip() == "bank_title":
                        title = (f.findtext("fieldentry") or "").strip()
                result = (title, list(ob.iterfind("item")))
        self.banks[ref] = result
        return result

    def add(self, item, points=None, bank_title=""):
        """Register a question; returns its index or None when it is omitted."""
        ident = item.get("ident") or ""
        if ident in self.by_ident:
            return self.by_ident[ident]
        q, reason = _parse_item(item, points, bank_title)
        if q is None:
            name = item.get("title") or ident
            where = f" in bank '{bank_title}'" if bank_title else ""
            warn(f"Question '{name}' ({ident}){where} was omitted: {reason}.")
            self.by_ident[ident] = None
            return None
        q.index = len(self.questions)
        self.questions.append(q)
        self.by_ident[ident] = q.index
        return q.index

    def add_group(self, label, select, indices, total):
        indices = [i for i in indices if i is not None]
        if not indices:
            return
        if select is not None and select > len(indices):
            warn(
                f"'{label}' asks for {select} question(s) but only {len(indices)} of its "
                f"{total} are usable; using {len(indices)}."
            )
            select = len(indices)
        self.groups.append(Group(label, select, indices))

    def walk(self, section):
        for child in section:
            if child.tag == "item":
                idx = self.add(child)
                self.add_group(child.get("title") or child.get("ident") or "question", None, [idx], 1)
            elif child.tag == "bankentry_item":
                self.has_banks = True
                ref = child.get("sourcebank_ref") or ""
                bank = self.bank(ref)
                target = None
                if bank:
                    target = next((i for i in bank[1] if i.get("ident") == child.get("item_ref")), None)
                if target is None:
                    warn(f"A question references item bank '{ref}', which is not in the export; it was omitted.")
                    continue
                idx = self.add(target, _to_float(child.get("points_possible")), bank[0])
                self.add_group(bank[0] or ref, None, [idx], 1)
            elif child.tag == "section":
                self.walk_section(child)

    def walk_section(self, sec):
        sel = sec.find("selection_ordering/selection")
        if sel is None:
            self.walk(sec)
            return
        number = (sel.findtext("selection_number") or "").strip()
        select = int(number) if number.isdigit() else None
        points = _to_float(sel.findtext("selection_extension/points_per_item"))
        ref = (sel.findtext("sourcebank_ref") or "").strip()
        label = sec.get("title") or ref or sec.get("ident") or "group"
        items, bank_title = list(sec.iterfind("item")), ""
        if ref:
            self.has_banks = True
            bank = self.bank(ref)
            if bank is None:
                if not items:
                    warn(f"Item bank '{label}' ({ref}) is not included in the export; its questions were omitted.")
            else:
                bank_title = bank[0]
                items = bank[1] + items
        indices = [self.add(i, points, bank_title) for i in items]
        self.add_group(label, select, indices, len(items))


def load_quiz(root_dir, info, blank=BLANK):
    """`blank`: printed in place of the blank in fill-in-the-blank questions (--fill-blank-text)."""
    if word.is_word_folder(root_dir):
        return _word_quiz(root_dir, info, blank)
    qroot = _parse(info.path)
    assessment = qroot.find("assessment")
    title, description = info.title, ""
    meta = info.path.parent / "assessment_meta.xml"
    if meta.exists():
        m = _parse(meta)
        title = (m.findtext("title") or title).strip()
        description = _inner(m.find("description"))
    loader = _Loader(root_dir)
    for sec in assessment.iterfind("section"):
        loader.walk(sec)
    if not loader.questions:
        raise ExamError(f"Quiz '{title}' contains no supported questions.")
    if blank != BLANK:
        for q in loader.questions:
            if q.kind == "text":
                q.html = q.html.replace(BLANK, _escape(blank) if blank else "")
    questions, groups = _pre_randomize(info.ident, loader.questions, loader.groups)
    return Quiz(info.ident, title, description, questions, groups, root_dir, loader.has_banks)


def _word_quiz(root_dir, info, blank):
    """A quiz from a Word document (see word.py): every question is printed, in the document's order
    before the usual pre-randomizing."""
    questions = word.load(root_dir, sys.modules[__name__])
    if not questions:
        raise ExamError(f"No questions that can be marked were found in the Word document '{info.title}'.")
    groups = []
    for i, q in enumerate(questions):
        q.index = i
        if blank != BLANK and q.kind == "text":
            q.html = q.html.replace(BLANK, _escape(blank) if blank else "")
        groups.append(Group(q.title, None, [i]))
    questions, groups = _pre_randomize(info.ident, questions, groups)
    return Quiz(info.ident, info.title, "", questions, groups, Path(root_dir), False)


def _pre_randomize(quiz_ident, questions, groups):
    """Put the questions, and the options inside each question, into the
    pre-randomized (master) order. Everything printed in QR codes refers to this
    order, never to the order in the export, so a pattern in how the instructor
    wrote the quiz (e.g. the first option is always correct) cannot leak.

    The shuffle is seeded from the quiz identifier only, so every run on the same
    export produces the same master order and therefore the same answer key."""
    rng = random.Random(f"mastertest-order:{quiz_ident}")
    order = list(range(len(questions)))
    rng.shuffle(order)
    new_index = {old: new for new, old in enumerate(order)}
    out = []
    for new, old in enumerate(order):
        q = questions[old]
        q.export_index, q.index = old, new
        rng.shuffle(q.options)
        out.append(q)
    for g in groups:
        g.indices = [new_index[i] for i in g.indices]
    return out, groups
