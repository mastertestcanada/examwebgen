"""How far the slow steps have got: reading a large export, and making each student's exam, title
page and answer card. On the desktop a step with 20 or more of something prints every tenth to
standard error ("  exam 120/300"); MasterTest Web sets `hook` and shows a progress bar instead.

Stages: "reading" (files of the export), "exam", "title page", "card", "quiz" (single-page and
merged sheets), "writing" (putting the files together; total 0 = no count).
"""
import sys

hook = None   # MasterTest Web: a function(stage, done, total)


def report(stage, done, total, cli=True):
    if hook is not None:
        hook(stage, done, total)
    elif cli and total >= 20 and (done % 10 == 0 or done == total):
        print(f"  {stage} {done}/{total}", file=sys.stderr, flush=True)
