"""The translations of MasterTest Builder and MasterTest Web: one file per language, <code>.json.

    "language"          the language's own name (Français)
    "rules"             how the language prints: "label" ({0}: or {0} :), "decimal_comma" (the
                        usual decimal mark, which --decimal-mark overrides) and
                        "singular_below_two" (French: 1,5 pt; English: 1.5 pts)
    "printed"           what the exams, cards and keys print (mtbuilder/i18n.py), by key;
                        en.json has the English of each
    "message_prefix"    ERROR: and WARNING: in the language
    "messages"          the program's errors and warnings (mtbuilder/messages.py): the English
                        exactly as the program writes it, {0}, {1} ... for the values in it
    "fragments"         English words and phrases that appear as values inside messages
    "fragment_patterns" the same, with values
    "web"               MasterTest Web's page (web/i18n.js, written in by tools/build_web.py):
                        the English text, {name} for a value

A new language is a new file. tools/check_translations.py lists what a file is missing.
"""
import json
from functools import lru_cache
from pathlib import Path

FOLDER = Path(__file__).resolve().parent


@lru_cache(maxsize=None)
def load(code):
    path = FOLDER / f"{code}.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}


def codes():
    """The languages there are files for, English first."""
    found = sorted(p.stem for p in FOLDER.glob("*.json"))
    return ["en"] + [c for c in found if c != "en"]
