"""The language of MasterTest Builder's own messages: errors, warnings and the run summary
(--messages-language, by default the computer's language; MasterTest Web passes the page's).

Messages are written in English where they arise, and the program's own checks read that
English. They are translated only when shown: `translate(text)` matches the finished English
message against the templates in mtbuilder/locales/<language>.json ({0}, {1} ... stand for the values in it) and writes the
French with the same values, each of which is translated too when it is itself a message or one
of the fragments (such as the reason a question was left out). A message that matches no template
is shown in English. This is separate from --print-language, the language of the printed exams.
"""
import os
import re

from . import locales

LANGUAGES = tuple(locales.codes())
_language = "en"


def default_language():
    """The computer's language when there is a translation for it, else en."""
    for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        v = os.environ.get(var, "")
        if v:
            code = v.lower()[:2]
            return code if code in LANGUAGES else "en"
    return "en"


def set_language(language):
    global _language
    _language = language if language in LANGUAGES else "en"


def language():
    return _language


def _table(language):
    return locales.load(language)


def _compile(pairs):
    out = []
    for en, translated in pairs:
        parts = re.split(r"\{(\d+)\}", en)
        pattern = "".join(re.escape(p) if i % 2 == 0 else f"(?P<v{p}>.*?)" for i, p in enumerate(parts))
        out.append((re.compile(pattern + r"\Z", re.S), translated))
    # most specific (longest literal text) first, so a general template does not catch a longer one
    out.sort(key=lambda x: -len(re.sub(r"\(\?P<v\d+>\.\*\?\)", "", x[0].pattern)))
    return out


_compiled = {}


def translate(text, language=None, _depth=0):
    """`text` in the messages language (`language`, by default the one set); English when no
    template matches."""
    lang = language or _language
    if lang == "en" or not text or _depth > 3:
        return text
    table = _table(lang)
    if lang not in _compiled:
        _compiled[lang] = _compile(list(table.get("messages", {}).items()) + list(table.get("fragment_patterns", {}).items()))
    s = str(text)
    if s in table.get("fragments", {}):
        return table["fragments"][s]
    for pattern, out in _compiled[lang]:
        m = pattern.match(s)
        if m:
            values = {k[1:]: translate(v, lang, _depth + 1) for k, v in m.groupdict().items()}
            return re.sub(r"\{(\d+)\}", lambda g: values.get(g.group(1), g.group(0)), out)
    return s


def prefix(kind):
    """ERROR: / WARNING: in the messages language (MasterTest Web looks for either)."""
    return _table(_language).get("message_prefix", {}).get(kind, kind + ":")
