"""Binary payloads of the QR codes, MasterTest QR format 2 (MasterTest Builder 0.5.13 and later;
all integers big-endian). Format 1 (schemas 0x10, 0x11 and 0x18, Builder 0.4.6 to 0.5.12) is
recognised by MasterTest Marker only to say that the exam must be printed again.

ANSWER CARD - schema 0x20 (a full-page answer card, a single-page quiz, or one sheet of a merged quiz)
    1 byte   schema        0x20
    1 byte   flags         bit 0: 1 = blank card (the student fills in name and number)
                           bit 1: paper size, 0 = letter, 1 = A4
                           bit 2: 1 = padded: every multiple-choice question has as many bubbles
                                  as the quiz's question with the most printed options
                                  (the reader works the number out from the answer key)
                           bit 3: 1 = written-answer cells are shaded, not outlined
                           bit 4: 1 = numbered: the number printed beside the first question
                                  follows the data fields on every kind of card (always so on
                                  merged sheets); set when the quiz has matching questions,
                                  which take more than one row of a card
                           bit 5: 1 = the index byte also gives how many cards (or sheets) the
                                  student's exam has (from 0.5.19; MasterTest Marker then asks
                                  for the rest after the first is scanned)
    4 bytes  hash          CRC-32 of the quiz identifier (UTF-8); at bytes 2-5 in every payload
    1 byte   kind          0 = full-page answer card, 1 = single-page quiz, 2 = merged sheet
    1 byte   answer width  width of the written-answer boxes in whole points (--answer-width);
                           0 = the default for the layout. On merged sheets bubble size and box
                           height scale with min(width, 120) / 90.
    1 byte   index         low 4 bits: 0 for the first card (or sheet) of an exam, 1 for the
                           second, ...; with flag bit 5, high 4 bits: the number of cards - 1.
                           A full-page card holds questions index x (answers per card) + 1 onward.
    5 bytes  serial        the card's 12-digit serial, as a number (it is the last data field)
    1 byte   field count   number of data fields that follow
    variable data fields   each is 1 length byte followed by that many bytes of UTF-8.
                           Class-list cards: student name, student number, the --add-qr-field
                           columns in the order given. Blank cards: none.
                           Read back, the serial is added as the last field ("Card serial"), so
                           the field names in the answer key match the fields in order.
    2 bytes  first number  merged sheets, and cards with flag bit 4: the number printed beside the
                           first question
    2 bytes  questions     number of questions printed on this card or sheet
    variable question map  for each question, in printed order:
                             Q bits  index of the question in the pre-randomized order
                             then, depending on the question's kind in the answer key:
                               choice:  L bits  Lehmer code of the option shuffle
                               numeric: V bits  which worked example (value set) was printed;
                                        V = bits needed for (number of answers in the key - 1)
                               text:    nothing
                               essay:   nothing (an essay is always after every other question)
                               match:   16 bits, the seed of the answers' order on this exam
                                        (match_order(): the shuffle both programs compute from it)
                           packed most-significant bit first, zero padded to a byte.
    rest     positions     merged sheets only: the height of the centre of each answer below the
                           top of the page, in half points, column by column: a varint, how many
                           answers are in the left column (0); then for each column used, its
                           first answer as 2 bytes and every further one as a varint, the
                           step down from the one before. (A varint holds 7 bits per byte, low
                           bits first, the top bit set on every byte but the last; a step of up
                           to 63.5 points takes one byte.) Answers of one-column sheets are all in
                           column 1. The answer area of a column ends at its right edge; bubbles
                           end there too, boxes fill it. A matching question has one position per
                           item (its cells end at the right edge); an essay has none.

    Matching questions on full-page cards and single-page quizzes take rows of their own: the item
    letter and its digit cells side by side, as many items to a row as fit in the six bubble
    positions (BOX_CELLS // (1 + cells): three with one cell, two with two), starting a new column
    rather than splitting across one (answer_card.row_layout).

    Essay questions come after every other question of the exam, each with a space for the answer
    (a fraction of a page, in the answer key) at the foot of the last card or sheet, or on further
    cards or sheets when they do not fit there. On a full-page card that has essays the rows per
    column are the fewest that hold its other questions (answer_card.essay_rows), so the essays
    start just below them; a card with only essays has no rows.

Q is the number of bits needed for the largest question index in the export
(every usable question, including all item-bank questions).
L is the number of bits needed for n! - 1, where n is the number of options the
question has in the export (including options that are empty and not printed).
The shuffle is a permutation p of 0..n-1 where p[i] is the pre-randomized
position of the option in slot i; empty options keep their slot in p but are
skipped when lettering, so printed letter k is the k-th non-empty entry of p.

ANSWER KEY - schema 0x21
    1 byte   schema        0x21
    1 byte   flags         bit 0: the exam was printed with the decimal comma (display only)
                           bit 1: everything after the exam name is compressed (raw DEFLATE,
                                  RFC 1951); set when that makes the code smaller
    4 bytes  hash          CRC-32 of the quiz identifier (same value as on the cards)
    variable exam name     1 length byte followed by that many bytes of UTF-8
    1 byte   field count   number of field names that follow
    variable field names   the names of the data fields on class-list cards, in card order
    2 bytes  questions     number of questions N in the pre-randomized order
    N records, record j describing question j+1 (index j), starting with a kind byte:
      0 choice:  n options in the export (1), present mask (1: bit i = pre-randomized option i
                 is printed), correct mask (1), points x 100 (2)
      1 numeric: points x 100 (2), tolerance kind (1: 0 = absolute, 1 = percent),
                 tolerance (length byte + text), answer count (1), answers (length byte + text each);
                 the card says which answer applies to the student
      2 text:    points x 100 (2), answer count (1), accepted answers (length byte + text each)
      4 essay:   points x 100 (2), answer space in quarters of a page (1: 1/4 ... 4: a whole page)
      3 match:   points x 100 (2, for the whole question; each item earns an equal share),
                 digit cells per item (1), answer count m (1), item count n (1), then for each
                 item its answer (1-m) in the pre-randomized order (1 byte each); the number
                 printed for it on an exam is its place in that exam's match_order() plus one
      5 choice with a scoring method: as kind 0, then the method (1): 1 = right minus wrong,
                 2 = correct selections, 3 = correct answers with limited selections (D2L's
                 multi-select methods; kind 0 is all or nothing)
      6 match with a scoring method: as kind 3, then the method (1): 1 = all or nothing,
                 2 = right minus wrong (kind 3 gives each item an equal share)

PASSWORD-PROTECTED ANSWER KEY - schema 0x28   (--password)
    1 byte   schema        0x28
    1 byte   flags         as in the key (bit 1: the plaintext is compressed)
    4 bytes  hash          CRC-32 of the quiz identifier (same value as on the cards)
    variable exam name     1 length byte followed by that many bytes of UTF-8 (not secret:
                           it lets the marking app say which exam it wants a password for)
    12 bytes nonce
    rest     ciphertext    AES-256-GCM, 16-byte tag at the end

    associated data = all bytes before the nonce (schema, flags, hash, exam name)
    AES key    = PBKDF2-HMAC-SHA256( password as UTF-8, salt = the associated data,
                                     600,000 iterations, 32 bytes )
                 The salt contains the quiz hash and exam name, so the same password
                 gives a different key for every exam.
    plaintext  = everything in a schema 0x21 payload after the exam name (compressed or not)
    nonce      = first 12 bytes of SHA-256( AES key || associated data || plaintext )
    Decrypting and putting 0x21, the flags, hash and exam name in front of the plaintext gives an
    ordinary answer key. The GCM tag fails when the password is wrong.
"""

import hashlib
import zlib

from . import aesgcm
from math import factorial

CARD_SCHEMA = 0x20
KEY_SCHEMA = 0x21
PROTECTED_KEY_SCHEMA = 0x28
OLD_SCHEMAS = (0x10, 0x11, 0x18)          # QR format 1: print the exam again
CARD, SINGLE_PAGE, MERGED = 0, 1, 2      # the kind byte of a card
KINDS = {CARD: "card", SINGLE_PAGE: "single_page", MERGED: "merged"}
NONCE_BYTES = 12
KEY_FIXED_BYTES = 8    # at least: schema, flags, hash, name length, one byte of records
MAX_FIELD_BYTES = 255
CARD_FIXED_BYTES = 17  # schema, flags, hash, kind, width, index, serial, field count, question count
KEY_COMPRESSED = 0x02     # key flags: the part after the exam name is raw DEFLATE
CARD_TOTAL = 0x20         # card flags: the index byte's high 4 bits give the number of cards - 1


def index_bits(pool_size):
    """Bits used for an original question index (Q)."""
    return max(1, (max(pool_size, 1) - 1).bit_length())


def lehmer_bits(n):
    return (factorial(n) - 1).bit_length()


def lehmer_encode(perm):
    n, value = len(perm), 0
    for i, p in enumerate(perm):
        smaller = sum(1 for q in perm[i + 1:] if q < p)
        value += smaller * factorial(n - 1 - i)
    return value


def lehmer_decode(value, n):
    pool, perm = list(range(n)), []
    for i in range(n):
        f = factorial(n - 1 - i)
        perm.append(pool.pop(value // f))
        value %= f
    return perm


def quiz_hash(quiz_ident):
    return zlib.crc32(quiz_ident.encode("utf-8")) & 0xFFFFFFFF


def pack_field(text):
    """One length-prefixed string: a length byte, then up to 255 bytes of UTF-8."""
    raw = str(text).encode("utf-8")[:MAX_FIELD_BYTES]
    while True:  # never cut a multi-byte character in half
        try:
            raw.decode("utf-8")
            break
        except UnicodeDecodeError:
            raw = raw[:-1]
    return bytes([len(raw)]) + raw


def value_bits(count):
    """Bits used for the worked-example index of a calculated question with `count` examples."""
    return max(count - 1, 0).bit_length()


MATCH_SEED_BITS = 16


def match_order(seed, m):
    """The order a matching question's m answers are printed in on an exam with this seed:
    order[k] is the pre-randomized answer printed as number k + 1. A Fisher-Yates shuffle driven by
    xorshift32, so MasterTest Marker (Payloads.matchOrder) computes exactly the same."""
    x = (seed * 2654435761 + 0x9E3779B9) & 0xFFFFFFFF or 1
    order = list(range(m))
    for i in range(m - 1, 0, -1):
        x ^= (x << 13) & 0xFFFFFFFF
        x ^= x >> 17
        x ^= (x << 5) & 0xFFFFFFFF
        j = x % (i + 1)
        order[i], order[j] = order[j], order[i]
    return order


def entry_field(kind, perm, size):
    """(value, bit count) stored after the question index on a card.
    choice: Lehmer code of the option shuffle; numeric: index of the worked example; text: nothing."""
    if kind == "numeric":
        return perm[0], value_bits(size)
    if kind == "match":
        return perm[0], MATCH_SEED_BITS
    if kind in ("text", "essay"):
        return 0, 0
    return lehmer_encode(perm), lehmer_bits(len(perm))


def encode(quiz_ident, blank, fields, entries, pool_size, index=0, kind=CARD, a4=False, padded=False,
           shaded=False, answer_width=None, first_number=None, spots=(), total=None):
    """One answer card or merged sheet. fields: the data-field values; entries: (pre-randomized
    question index, value, bit count) for each question printed (see entry_field); merged sheets:
    first_number and spots [(column, y from the top)] for every question; total: how many cards
    (or sheets) the student's exam has."""
    if not 0 <= index <= 15:
        raise ValueError("card index must be 0-15")
    if total is not None and not index < total <= 16:
        raise ValueError("an exam has 1-16 cards, and the index must be below their number")
    if len(fields) > 255:
        raise ValueError("at most 255 data fields fit in the QR code")
    width = 0 if answer_width is None else answer_width
    if not 0 <= width <= 255 or width != int(width):
        raise ValueError("the answer width must be a whole number of points, 1-255")
    numbered = kind != MERGED and first_number is not None
    flags = ((1 if blank else 0) | (2 if a4 else 0) | (4 if padded else 0) | (8 if shaded else 0) | (16 if numbered else 0)
             | (CARD_TOTAL if total is not None else 0))
    index_byte = index | ((total - 1) << 4 if total is not None else 0)
    out = bytes([CARD_SCHEMA, flags]) + quiz_hash(quiz_ident).to_bytes(4, "big") + bytes([kind, int(width), index_byte])
    *fields, serial = fields                     # the serial (always the last field) as a 5-byte number
    if not (str(serial).isdigit() and len(str(serial)) == 12):
        raise ValueError("the card serial must be 12 digits")
    out += int(serial).to_bytes(5, "big")
    out += bytes([len(fields)]) + b"".join(pack_field(f) for f in fields)
    if kind == MERGED or numbered:
        out += int(first_number).to_bytes(2, "big")
    out += len(entries).to_bytes(2, "big")
    qbits = index_bits(pool_size)
    acc, nbits = 0, 0
    for q_index, value, bits in entries:
        acc = (acc << qbits) | q_index
        acc = (acc << bits) | value
        nbits += qbits + bits
    pad = (-nbits) % 8
    out += (acc << pad).to_bytes((nbits + pad) // 8, "big")
    if kind == MERGED:
        out += pack_spots(spots)
    return out


def _varint(n):
    out = bytearray()
    while True:
        out.append((n & 0x7F) | (0x80 if n > 0x7F else 0))
        n >>= 7
        if not n:
            return bytes(out)


def pack_spots(spots):
    """The answer positions of a merged sheet, [(column, y from the top)], as described above (half points)."""
    halves = [(col, round(y * 2)) for col, y in spots]
    if any(col not in (0, 1) or not 0 <= h < 0x10000 for col, h in halves):
        raise ValueError("answer position out of range")
    left = [h for col, h in halves if col == 0]
    right = [h for col, h in halves if col == 1]
    if halves != [(0, h) for h in left] + [(1, h) for h in right]:
        raise ValueError("answer positions must be the left column's, then the right column's")
    out = bytearray(_varint(len(left)))
    for column in (left, right):
        for k, h in enumerate(column):
            if k == 0:
                out += h.to_bytes(2, "big")
            elif h < column[k - 1]:
                raise ValueError("answer positions must go down a column")
            else:
                out += _varint(h - column[k - 1])
    return bytes(out)


def unpack_spots(data, at, count):
    """(positions [(column, y)], bytes used) of `count` answers from data[at:]."""
    start = at

    def varint():
        nonlocal at
        n = shift = 0
        while True:
            b = data[at]
            at += 1
            n |= (b & 0x7F) << shift
            shift += 7
            if not b & 0x80:
                return n
    left = varint()
    out = []
    for col, n in ((0, left), (1, count - left)):
        h = 0
        for k in range(n):
            if k == 0:
                h = int.from_bytes(data[at:at + 2], "big")
                at += 2
            else:
                h += varint()
            out.append((col, h / 2))
    return out, at - start


def decode(data, questions):
    """Inverse of encode(). questions: the answer key's question dicts (decode_key()["questions"])."""
    if len(data) < CARD_FIXED_BYTES or data[0] != CARD_SCHEMA or data[6] not in KINDS:
        raise ValueError("not a MasterTest answer-card payload (schema 0x20)")
    kind, flags = data[6], data[1]
    serial = f"{int.from_bytes(data[9:14], 'big'):012d}"
    pos = 15
    fields = []
    for _ in range(data[14]):
        length = data[pos]
        fields.append(data[pos + 1:pos + 1 + length].decode("utf-8", "replace"))
        pos += 1 + length
    first_number = None
    if kind == MERGED or flags & 16:
        first_number = int.from_bytes(data[pos:pos + 2], "big")
        pos += 2
    count = int.from_bytes(data[pos:pos + 2], "big")
    pos += 2
    qbits = index_bits(len(questions))
    stream = int.from_bytes(data[pos:], "big")
    remaining = (len(data) - pos) * 8
    entries = []
    for _ in range(count):
        remaining -= qbits
        index = (stream >> remaining) & ((1 << qbits) - 1)
        q = questions[index]
        bits = (value_bits(len(q["answers"])) if q["kind"] == "numeric" else MATCH_SEED_BITS if q["kind"] == "match"
                else 0 if q["kind"] in ("text", "essay") else lehmer_bits(q["options"]))
        remaining -= bits
        code = (stream >> remaining) & ((1 << bits) - 1)
        entries.append((index, [code] if q["kind"] in ("numeric", "match") else [] if q["kind"] in ("text", "essay")
                        else lehmer_decode(code, q["options"])))
    spots = None
    if kind == MERGED:
        at = pos + ((len(data) - pos) * 8 - remaining + 7) // 8
        n_spots = sum(len(questions[i]["matches"]) if questions[i]["kind"] == "match" else
                      0 if questions[i]["kind"] == "essay" else 1 for i, _p in entries)
        spots, _used = unpack_spots(data, at, n_spots)
    return {
        "kind": KINDS[kind],
        "merged": kind == MERGED,
        "single_page": kind == SINGLE_PAGE,
        "first_number": first_number,
        "spots": spots,
        "answer_width": data[7] or None,
        "index": data[8] & 15,
        "total": (data[8] >> 4) + 1 if flags & CARD_TOTAL else None,
        "blank": bool(flags & 1),
        "a4": bool(flags & 2),
        "padded": bool(flags & 4),
        "shaded": bool(flags & 8),
        "numbered": bool(flags & 16),
        "hash": int.from_bytes(data[2:6], "big"),
        "fields": fields + [serial],
        "serial": serial,
        "entries": entries,
    }


KEY_DECIMAL_COMMA = 0x01   # key flags: the exam was printed with the decimal comma (display only)
# scoring methods in the key (records 5 and 6); the usual ones (all or nothing; an equal share per item) are 0
CHOICE_SCORING = {"": 0, "all": 0, "right_minus_wrong": 1, "correct_selections": 2, "limited": 3}
MATCH_SCORING = {"": 0, "equal": 0, "all": 1, "right_minus_wrong": 2}


def encode_key(quiz_ident, records, field_names=(), title="", decimal_comma=False):
    """records: ("choice", n, present, correct, points[, scoring]) | ("numeric", points, percent, tolerance,
    [answers]) | ("text", points, [answers]) | ("match", points, cells, answer count, [answer number
    of each item][, scoring]) | ("essay", points, quarters of a page); field_names: the data fields on class-list
    cards. scoring: CHOICE_SCORING or MATCH_SCORING's name, "" for the usual method."""
    if len(field_names) > 255:
        raise ValueError("at most 255 field names fit in the QR code")
    flags = KEY_DECIMAL_COMMA if decimal_comma else 0
    out = bytes([len(field_names)]) + b"".join(pack_field(n) for n in field_names)
    out += len(records).to_bytes(2, "big")
    for rec in records:
        kind = rec[0]
        points = rec[1] if kind != "choice" else rec[4]
        hundredths = round((points or 0) * 100)
        if not 0 <= hundredths <= 0xFFFF:
            raise ValueError(f"point value {points} cannot be stored (0 to 655.35)")
        if kind == "choice":
            method = CHOICE_SCORING.get(rec[5] if len(rec) > 5 else "", 0)
            out += bytes([5 if method else 0, rec[1], rec[2], rec[3]]) + hundredths.to_bytes(2, "big") + (bytes([method]) if method else b"")
        elif kind == "numeric":
            _, _, percent, tolerance, answers = rec
            out += bytes([1]) + hundredths.to_bytes(2, "big") + bytes([1 if percent else 0]) + pack_field(tolerance)
            out += bytes([len(answers)]) + b"".join(pack_field(a) for a in answers)
        elif kind == "match":
            _, _, cells, m, numbers, *rest = rec
            method = MATCH_SCORING.get(rest[0] if rest else "", 0)
            out += bytes([6 if method else 3]) + hundredths.to_bytes(2, "big") + bytes([cells, m, len(numbers)]) + bytes(numbers)
            out += bytes([method]) if method else b""
        elif kind == "essay":
            out += bytes([4]) + hundredths.to_bytes(2, "big") + bytes([rec[2]])
        else:
            answers = rec[2][:255]
            out += bytes([2]) + hundredths.to_bytes(2, "big") + bytes([len(answers)])
            out += b"".join(pack_field(a) for a in answers)
    # the records compress well (repeated points, option masks, answers written as text): a smaller
    # code has bigger squares, which read more reliably
    packer = zlib.compressobj(9, zlib.DEFLATED, -15)
    packed = packer.compress(out) + packer.flush()
    if len(packed) < len(out):
        out, flags = packed, flags | KEY_COMPRESSED
    return bytes([KEY_SCHEMA, flags]) + quiz_hash(quiz_ident).to_bytes(4, "big") + pack_field(title) + out


def decode_key(data):
    if len(data) < KEY_FIXED_BYTES or data[0] != KEY_SCHEMA:
        raise ValueError("not a MasterTest answer-key payload (schema 0x21)")
    if data[1] & KEY_COMPRESSED:
        name_end = 7 + data[6]
        data = data[:name_end] + zlib.decompress(data[name_end:], -15)
    pos = 6

    def byte():
        nonlocal pos
        pos += 1
        return data[pos - 1]

    def u16():
        nonlocal pos
        pos += 2
        return int.from_bytes(data[pos - 2:pos], "big")

    def string():
        nonlocal pos
        length = byte()
        pos += length
        return data[pos - length:pos].decode("utf-8", "replace")

    title = string()
    names = [string() for _ in range(byte())]
    questions = []
    for j in range(u16()):
        kind = byte()
        if kind in (0, 5):
            n, present, correct = byte(), byte(), byte()
            questions.append({"number": j + 1, "kind": "choice", "options": n, "points": u16() / 100,
                              "present": [i for i in range(n) if present >> i & 1],
                              "correct": [i for i in range(n) if correct >> i & 1]})
            scoring = byte() if kind == 5 else 0
            questions[-1]["scoring"] = next(k for k, v in CHOICE_SCORING.items() if v == scoring and k)
        elif kind == 1:
            points = u16() / 100
            percent = bool(byte())
            tolerance = string()
            answers = [string() for _ in range(byte())]
            questions.append({"number": j + 1, "kind": "numeric", "options": 0, "points": points,
                              "percent": percent, "tolerance": tolerance, "answers": answers})
        elif kind in (3, 6):
            points = u16() / 100
            cells, m, n = byte(), byte(), byte()
            numbers = [byte() for _ in range(n)]
            scoring = byte() if kind == 6 else 0
            questions.append({"number": j + 1, "kind": "match", "options": 0, "points": points, "cells": cells,
                              "answer_count": m, "matches": numbers,
                              "scoring": next(k for k, v in MATCH_SCORING.items() if v == scoring and k)})
        elif kind == 4:
            points = u16() / 100
            questions.append({"number": j + 1, "kind": "essay", "options": 0, "points": points, "quarters": byte()})
        else:
            points = u16() / 100
            answers = [string() for _ in range(byte())]
            questions.append({"number": j + 1, "kind": "text", "options": 0, "points": points, "answers": answers})
    return {"hash": int.from_bytes(data[2:6], "big"), "title": title, "field_names": names, "questions": questions,
            "decimal_comma": bool(data[1] & KEY_DECIMAL_COMMA)}


KDF_ITERATIONS = 600_000


class KeyNeeded(BaseException):
    """Raised in the browser, where Python has no PBKDF2: MasterTest Web derives the AES key for
    `header` with the browser's own crypto (much faster) and runs the program again with it in
    DERIVED_KEYS. A BaseException, so that it is not reported as an error on the way out."""

    def __init__(self, header):
        super().__init__(header.hex())
        self.header = header


DERIVED_KEYS = {}    # (password, header) -> AES key, filled in by MasterTest Web (web_runner.run)


def _aes_key(password, header):
    """Deliberately slow, so that guessing passwords against a photographed key is expensive."""
    if (password, header) in DERIVED_KEYS:
        return DERIVED_KEYS[(password, header)]
    if hasattr(hashlib, "pbkdf2_hmac"):
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), header, KDF_ITERATIONS, 32)
    raise KeyNeeded(header)


def protect_key(payload, password):
    """Encrypt a schema 0x21 answer-key payload into a schema 0x28 one."""
    if payload[0] != KEY_SCHEMA:
        raise ValueError("not a MasterTest answer-key payload (schema 0x21)")
    name_end = 7 + payload[6]
    header = bytes([PROTECTED_KEY_SCHEMA, payload[1]]) + payload[2:name_end]
    plain = payload[name_end:]
    key = _aes_key(password, header)
    # Derived from the content, so the same key sheet is reproducible and a different
    # sheet under the same password never reuses a nonce.
    nonce = hashlib.sha256(key + header + plain).digest()[:NONCE_BYTES]
    return header + nonce + aesgcm.encrypt(key, nonce, plain, header)


def unprotect_key(data, password):
    """Inverse of protect_key(); raises ValueError when the password is wrong."""
    if data[0] != PROTECTED_KEY_SCHEMA:
        raise ValueError("not a password-protected MasterTest answer key (schema 0x28)")
    name_end = 7 + data[6]
    header = data[:name_end]
    nonce = data[name_end:name_end + NONCE_BYTES]
    try:
        plain = aesgcm.decrypt(_aes_key(password, header), nonce, data[name_end + NONCE_BYTES:], header)
    except ValueError:
        raise ValueError("wrong password, or the answer key is damaged")
    return bytes([KEY_SCHEMA, data[1]]) + data[2:name_end] + plain
