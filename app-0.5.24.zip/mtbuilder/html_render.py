"""Converts the HTML that Canvas stores for questions and instructions into
reportlab flowables."""

import base64
import copy
import io
import re
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Optional
from urllib.parse import unquote, urlparse
from xml.sax.saxutils import escape

import lxml.html
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Flowable, HRFlowable, Paragraph, Table, TableStyle, XPreformatted

from .errors import warn

BLOCK_TAGS = {
    "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li", "table", "pre", "blockquote",
    "hr", "section", "article", "header", "footer", "figure", "figcaption", "address", "center",
    "dl", "dt", "dd", "caption", "thead", "tbody", "tfoot", "tr", "td", "th",
}
SKIP_TAGS = {"script", "style", "head", "title", "meta", "link", "iframe", "object", "embed", "video", "audio", "svg", "math", "noscript", "template"}
HEADING_SCALE = {"h1": 2.0, "h2": 1.5, "h3": 1.17, "h4": 1.0, "h5": 0.83, "h6": 0.67}
SIZE_KEYWORDS = {"xx-small": 0.6, "x-small": 0.75, "small": 0.89, "medium": 1.0, "large": 1.2,
                 "x-large": 1.5, "xx-large": 2.0, "xxx-large": 3.0}
FONT_TAG_SIZES = {1: 0.63, 2: 0.82, 3: 1.0, 4: 1.13, 5: 1.5, 6: 2.0, 7: 3.0}
ALIGN = {"left": TA_LEFT, "start": TA_LEFT, "center": TA_CENTER, "right": TA_RIGHT, "end": TA_RIGHT, "justify": TA_JUSTIFY}
PX = 0.75  # CSS pixels -> points
VARIABLE_RE = re.compile(r"\[\[\s*([^\[\]<>]+?)\s*\]\]")
_WS_RE = re.compile(r"[ \t\r\n\f\v]+")


def normalise_variable(name):
    return re.sub(r"[\s_]+", " ", name.replace("\xa0", " ")).strip().upper()


def substitute_variables(html, variables):
    """Replace [[NAME]] with its value. Unknown names are left untouched."""
    def repl(m):
        key = normalise_variable(m.group(1))
        if key in variables:
            return escape(str(variables[key]))
        warn(f"Unknown variable [[{m.group(1)}]] was left as written.")
        return m.group(0)
    return VARIABLE_RE.sub(repl, html)


def uses_variable(html, name):
    return any(normalise_variable(m.group(1)) == name for m in VARIABLE_RE.finditer(html))


def parse_style(text):
    out = {}
    for part in (text or "").split(";"):
        if ":" in part:
            k, v = part.split(":", 1)
            out[k.strip().lower()] = v.replace("!important", "").strip()
    return out


def parse_color(value):
    if not value:
        return None
    v = value.strip().lower()
    if v in ("transparent", "inherit", "initial", "none", "currentcolor", "unset"):
        return None
    m = re.match(r"rgba?\(\s*([\d.]+)%?[\s,]+([\d.]+)%?[\s,]+([\d.]+)%?(?:[\s,/]+([\d.]+%?))?\s*\)", v)
    if m:
        if m.group(4) and float(m.group(4).rstrip("%")) == 0:
            return None
        return colors.Color(*(min(float(m.group(i)), 255) / 255 for i in (1, 2, 3)))
    try:
        if v.startswith("#") and len(v) == 4:
            v = "#" + "".join(c * 2 for c in v[1:])
        c = colors.toColor(v)
        return colors.Color(c.red, c.green, c.blue)
    except Exception:
        return None


def _hex(c):
    return "#%02x%02x%02x" % (round(c.red * 255), round(c.green * 255), round(c.blue * 255))


def parse_length(value, relative_to=None, em=None, scale=1.0):
    """CSS/HTML length -> points. Percentages need `relative_to`; returns None if unusable."""
    if value is None:
        return None
    v = str(value).strip().lower()
    m = re.match(r"^(-?[\d.]+)\s*([a-z%]*)$", v)
    if not m:
        return None
    try:
        n = float(m.group(1))
    except ValueError:
        return None
    unit = m.group(2)
    if unit == "%":
        return None if relative_to is None else n / 100.0 * relative_to
    if unit in ("em", "rem"):
        return None if em is None else n * em
    factor = {"": PX, "px": PX, "pt": 1.0, "in": 72.0, "cm": 72 / 2.54, "mm": 72 / 25.4, "pc": 12.0}.get(unit)
    return None if factor is None else n * factor * scale


class Picture(Flowable):
    """An image drawn from an in-memory reader."""

    def __init__(self, reader, width, height):
        super().__init__()
        self.reader, self.width, self.height = reader, width, height
        self.drawWidth, self.drawHeight = width, height

    def wrap(self, avail_width, avail_height):
        return self.width, self.height

    def draw(self):
        self.canv.drawImage(self.reader, 0, 0, self.width, self.height, mask="auto")


@dataclass(frozen=True)
class Ctx:
    family: str
    size: float
    bold: bool = False
    italic: bool = False
    underline: bool = False
    strike: bool = False
    color: Optional[colors.Color] = None
    bg: Optional[colors.Color] = None
    script: str = ""  # "sub" / "sup"
    align: int = TA_LEFT
    pre: bool = False


@dataclass
class Block:
    """Paragraph-level formatting in force where inline content is flushed."""
    indent: float = 0.0
    bullet: Optional[str] = None
    space_before: float = 0.0
    space_after: float = 0.0
    bg: Optional[colors.Color] = None
    pre: bool = False


class _State:
    def __init__(self, width):
        self.width = width
        self.out = []
        self.parts = []
        self.visible = False
        self.trailing_space = True
        self.block = Block()
        self.max_size = 0.0
        self.align = TA_LEFT
        self.list_depth = 0
        self.breaks = False
        self.after_image = False


class HtmlRenderer:
    def __init__(self, fonts, base_family, base_size, export_root=None, scale=1.0):
        self.fonts = fonts
        self.base_family = base_family
        self.base_size = base_size * scale
        self.scale = scale
        self.export_root = Path(export_root) if export_root else None
        self._images = {}
        self._n = 0
        self._cache = {}       # parsed paragraphs, see render()

    def scaled(self, scale):
        r = HtmlRenderer(self.fonts, self.base_family, self.base_size / self.scale, self.export_root, scale)
        r._images = self._images
        return r

    # ------------------------------------------------------------ public
    def base_ctx(self, **kw):
        return Ctx(family=self.base_family, size=self.base_size, **kw)

    def render(self, html, width, ctx=None, plain=False):
        """HTML (or plain text) -> list of flowables laid out for `width` points. Text made only of
        paragraphs is parsed once and handed out as copies: every student's exam prints the same
        questions and options, and parsing is most of the time spent on a booklet."""
        ctx = ctx or self.base_ctx()
        key = (html, width, ctx, plain)
        cached = self._cache.get(key)
        if cached is not None:
            return [copy.copy(f) for f in cached]
        out = self._render(html, width, ctx, plain)
        if out and all(type(f) is Paragraph for f in out):
            self._cache[key] = out
            return [copy.copy(f) for f in out]
        return out

    def _render(self, html, width, ctx, plain):
        if plain:
            html = escape(html)
        if not html or not html.strip():
            return []
        try:
            root = lxml.html.fragment_fromstring(html, create_parent="div")
        except Exception:
            root = lxml.html.fragment_fromstring(escape(html), create_parent="div")
        st = _State(width)
        st.align = ctx.align
        self._children(root, ctx, st)
        self._flush(st, ctx)
        self._trim(st.out)
        return st.out

    def paragraph(self, text, ctx=None, align=None, **style_kw):
        """A simple one-style paragraph from plain text (parsed once, then copied, as in render())."""
        ctx = ctx or self.base_ctx()
        key = ("p", text, ctx, align, tuple(sorted(style_kw.items())))
        cached = self._cache.get(key)
        if cached is None:
            markup = self._markup(text, ctx)
            cached = self._cache[key] = Paragraph(markup, self._pstyle(ctx.size, ctx.align if align is None else align, **style_kw))
        return copy.copy(cached)

    # ------------------------------------------------------------ helpers
    @staticmethod
    def _trim(flowables):
        for f, attr in ((flowables[0], "spaceBefore"), (flowables[-1], "spaceAfter")) if flowables else ():
            style = getattr(f, "style", None)
            if isinstance(style, ParagraphStyle):
                setattr(style, attr, 0)
            elif hasattr(f, attr):
                setattr(f, attr, 0)

    def _pstyle(self, size, align, **kw):
        self._n += 1
        base = dict(
            fontName=self.fonts.face(self.base_family), fontSize=size, leading=size * 1.22,
            alignment=align, splitLongWords=1, allowWidows=1, allowOrphans=1,
        )
        base.update(kw)
        return ParagraphStyle(f"eg{self._n}", **base)

    def _markup(self, text, ctx):
        face = self.fonts.face(ctx.family, ctx.bold, ctx.italic)
        out = []
        size = ctx.size * (0.68 if ctx.script else 1.0)
        for fontname, chunk in self.fonts.runs(text, face):
            attrs = f'name="{fontname}" size="{size:.2f}"'
            if ctx.color is not None:
                attrs += f' color="{_hex(ctx.color)}"'
            if ctx.bg is not None:
                attrs += f' backColor="{_hex(ctx.bg)}"'
            s = f"<font {attrs}>{escape(chunk)}</font>"
            if ctx.script == "sub":
                s = f'<sub rise="{ctx.size * 0.18:.2f}">{s}</sub>'
            elif ctx.script == "sup":
                s = f'<super rise="{ctx.size * 0.36:.2f}">{s}</super>'
            if ctx.underline:
                s = f"<u>{s}</u>"
            if ctx.strike:
                s = f"<strike>{s}</strike>"
            out.append(s)
        return "".join(out)

    def _text(self, text, ctx, st):
        if not text:
            return
        if ctx.pre:
            text = text.replace("\r\n", "\n").replace("\t", "    ")
        else:
            text = _WS_RE.sub(" ", text)
            if st.trailing_space:
                text = text.lstrip(" ")
            if not text:
                return
        st.trailing_space = text.endswith(" ") and not ctx.pre
        if text.strip(" \n"):
            st.visible = True
        st.max_size = max(st.max_size, ctx.size)
        st.after_image = False
        st.parts.append(self._markup(text, ctx))

    def _flush(self, st, ctx):
        parts, visible = st.parts, st.visible
        st.parts, st.visible, st.trailing_space, size = [], False, True, st.max_size or ctx.size
        st.max_size = 0.0
        breaks, st.breaks = st.breaks, False
        while parts and parts[-1] == "<br/>":  # browsers ignore a line break that ends a block
            parts.pop()
        if not visible:
            if not breaks or st.block.pre:
                return
            parts = ["&nbsp;"]  # an empty line the author put in on purpose
        b = st.block
        kw = dict(leftIndent=b.indent, spaceBefore=b.space_before, spaceAfter=b.space_after)
        if b.bg is not None:
            kw["backColor"] = b.bg
        bullet = None
        if b.bullet is not None:
            bullet, b.bullet = b.bullet, None
            kw.update(bulletIndent=max(b.indent - 16 * self.scale, 0), bulletFontName=self.fonts.face(ctx.family),
                      bulletFontSize=ctx.size)
        if b.pre:
            style = self._pstyle(ctx.size, TA_LEFT, **kw)
            st.out.append(XPreformatted("".join(parts).strip("\n"), style))
        else:
            style = self._pstyle(size, st.align, **kw)
            st.out.append(Paragraph("".join(parts), style, bulletText=bullet))

    # ------------------------------------------------------------ styling
    def _apply(self, el, ctx):
        """Context for an element: tag defaults, then presentational attributes, then CSS."""
        tag = el.tag
        ch = {}
        if tag in ("b", "strong", "th") or tag in HEADING_SCALE:
            ch["bold"] = True
        if tag in ("i", "em", "cite", "var", "dfn", "address"):
            ch["italic"] = True
        if tag in ("u", "ins", "a"):
            ch["underline"] = True
        if tag in ("s", "strike", "del"):
            ch["strike"] = True
        if tag == "sub":
            ch["script"] = "sub"
        if tag == "sup":
            ch["script"] = "sup"
        if tag in ("code", "tt", "kbd", "samp", "pre"):
            ch["family"] = "courier"
        if tag == "pre":
            ch["pre"] = True
        if tag == "small":
            ch["size"] = ctx.size * 0.83
        if tag == "big":
            ch["size"] = ctx.size * 1.17
        if tag == "mark":
            ch["bg"] = colors.Color(1, 1, 0)
        if tag in HEADING_SCALE:
            ch["size"] = self.base_size * HEADING_SCALE[tag]
        if tag == "center":
            ch["align"] = TA_CENTER
        if tag == "font":
            c = parse_color(el.get("color"))
            if c is not None:
                ch["color"] = c
            if el.get("face"):
                fam, force = self.fonts.css_family(el.get("face"), self.base_family)
                ch["family"] = fam
                if force:
                    ch["bold"] = True
            try:
                ch["size"] = self.base_size * FONT_TAG_SIZES[max(1, min(7, int(el.get("size"))))]
            except (TypeError, ValueError):
                pass
        if el.get("align", "").lower() in ALIGN and tag not in ("table", "img"):
            ch["align"] = ALIGN[el.get("align").lower()]
        if el.get("bgcolor") and tag not in ("table", "tr", "td", "th"):
            c = parse_color(el.get("bgcolor"))
            if c is not None:
                ch["bg"] = c

        css = parse_style(el.get("style"))
        if css:
            w = css.get("font-weight")
            if w:
                ch["bold"] = w in ("bold", "bolder") or (w.isdigit() and int(w) >= 600)
            fs = css.get("font-style")
            if fs:
                ch["italic"] = fs in ("italic", "oblique")
            deco = " ".join(css.get(k, "") for k in ("text-decoration", "text-decoration-line"))
            if "underline" in deco:
                ch["underline"] = True
            if "line-through" in deco:
                ch["strike"] = True
            if "none" in deco.split():
                ch["underline"] = ch["strike"] = False
            c = parse_color(css.get("color"))
            if c is not None:
                ch["color"] = c
            bgv = css.get("background-color") or (css.get("background") or "").split(" url")[0]
            c = parse_color(bgv)
            if c is not None and tag not in ("table", "tr", "td", "th"):
                ch["bg"] = c
            if css.get("font-family"):
                fam, force = self.fonts.css_family(css["font-family"], self.base_family)
                ch["family"] = fam
                if force:
                    ch["bold"] = True
            fsz = css.get("font-size")
            if fsz:
                cur = ch.get("size", ctx.size)
                if fsz in SIZE_KEYWORDS:
                    ch["size"] = self.base_size * SIZE_KEYWORDS[fsz]
                elif fsz == "smaller":
                    ch["size"] = cur * 0.83
                elif fsz == "larger":
                    ch["size"] = cur * 1.2
                else:
                    n = parse_length(fsz, relative_to=cur, em=cur, scale=self.scale)
                    if n and n > 0:
                        ch["size"] = n
            ta = css.get("text-align")
            if ta in ALIGN:
                ch["align"] = ALIGN[ta]
            va = css.get("vertical-align")
            if va == "sub":
                ch["script"] = "sub"
            elif va == "super":
                ch["script"] = "sup"
            if css.get("white-space", "") in ("pre", "pre-wrap"):
                ch["pre"] = True
        return replace(ctx, **ch) if ch else ctx

    @staticmethod
    def _hidden(el):
        if not isinstance(el.tag, str) or el.tag in SKIP_TAGS:
            return True
        if "sr-only" in (el.get("class") or "").split() or "screenreader-only" in (el.get("class") or "").split():
            return True
        # NB: "visibility" is deliberately ignored - such elements are still printed.
        return parse_style(el.get("style")).get("display") == "none"

    # ------------------------------------------------------------ walking
    def _children(self, el, ctx, st):
        self._text(el.text, ctx, st)
        for child in el:
            if not self._hidden(child):
                self._element(child, ctx, st)
            self._text(child.tail, ctx, st)

    def _element(self, el, ctx, st):
        tag = el.tag
        cctx = self._apply(el, ctx)
        if tag == "br":
            if st.after_image and not st.parts:
                st.after_image = False  # the break that follows a picture is already implied
                return
            st.parts.append("\n" if ctx.pre else "<br/>")
            st.trailing_space = True
            st.breaks = True
            return
        if tag == "img":
            self._image(el, ctx, st)
            return
        if tag not in BLOCK_TAGS:
            self._children(el, cctx, st)
            return

        # ---- block-level elements
        self._flush(st, ctx)
        saved_block, saved_align = st.block, st.align
        st.align = cctx.align
        gap = cctx.size * 0.55
        blk = Block(indent=saved_block.indent, bullet=saved_block.bullet, bg=saved_block.bg)
        if cctx.bg is not None and cctx.bg != ctx.bg:
            blk.bg = cctx.bg
            cctx = replace(cctx, bg=None)
        st.block = blk

        if tag == "table":
            st.block, st.align = saved_block, saved_align
            self._table(el, cctx, st)
            return
        if tag == "hr":
            st.out.append(HRFlowable(width="100%", thickness=0.6, color=colors.grey, spaceBefore=4, spaceAfter=4))
        elif tag in ("ul", "ol"):
            self._list(el, cctx, st)
        elif tag == "pre":
            blk.pre = True
            blk.space_after = gap
            self._children(el, cctx, st)
        else:
            if tag == "p" or tag in HEADING_SCALE:
                blk.space_after = gap
            if tag in HEADING_SCALE:
                blk.space_before = gap
            if tag in ("blockquote", "dd"):
                blk.indent += 24 * self.scale
                blk.space_after = gap
            self._children(el, cctx, st)
        self._flush(st, cctx)
        if saved_block.bullet is not None and blk.bullet is None:
            saved_block.bullet = None  # the list bullet was used by a nested block
        st.block, st.align = saved_block, saved_align

    def _list(self, el, ctx, st):
        ordered = el.tag == "ol"
        css = parse_style(el.get("style"))
        kind = (css.get("list-style-type") or el.get("type") or ("decimal" if ordered else "disc")).strip()
        try:
            counter = int(el.get("start", 1))
        except ValueError:
            counter = 1
        indent = st.block.indent + 22 * self.scale
        st.list_depth += 1
        for li in el:
            if not isinstance(li.tag, str) or self._hidden(li):
                continue
            if li.tag != "li":
                self._element(li, ctx, st)
                continue
            lctx = self._apply(li, ctx)
            st.block = Block(indent=indent, bullet=self._bullet(kind, counter, ordered, st.list_depth),
                             space_after=ctx.size * 0.15)
            st.align = lctx.align
            self._children(li, lctx, st)
            self._flush(st, lctx)
            counter += 1
        st.list_depth -= 1
        if st.list_depth == 0 and st.out:
            style = getattr(st.out[-1], "style", None)
            if isinstance(style, ParagraphStyle):
                style.spaceAfter = ctx.size * 0.55

    @staticmethod
    def _bullet(kind, n, ordered, depth):
        if kind == "A":
            return _alpha(n) + "."
        if kind == "I":
            return _roman(n) + "."
        kind = kind.lower()
        if kind == "none":
            return ""
        if kind in ("a", "lower-alpha", "lower-latin"):
            return _alpha(n).lower() + "."
        if kind in ("upper-alpha", "upper-latin"):
            return _alpha(n) + "."
        if kind in ("i", "lower-roman"):
            return _roman(n).lower() + "."
        if kind == "upper-roman":
            return _roman(n) + "."
        if ordered or kind in ("1", "decimal"):
            return f"{n}."
        if kind == "square":
            return "\u2022"
        if kind == "circle" or depth % 2 == 0:
            return "\u2013"
        return "\u2022"

    # ------------------------------------------------------------ images
    def _load_image(self, src):
        if src in self._images:
            return self._images[src]
        result = None
        try:
            if src.startswith("data:"):
                head, data = src.split(",", 1)
                raw = base64.b64decode(data) if ";base64" in head else unquote(data).encode("latin-1")
                result = self._prepare(io.BytesIO(raw))
            else:
                path = self._resolve(src)
                if path is not None:
                    result = self._prepare(path)
        except Exception as exc:
            warn(f"Image could not be read ({src[:80]}): {exc}")
        self._images[src] = result
        return result

    @staticmethod
    def _prepare(source):
        im = PILImage.open(source)
        im.load()
        w, h = im.size
        if im.mode in ("P", "LA", "PA") or (im.mode == "RGBA" and False):
            im = im.convert("RGBA")
        buf = io.BytesIO()
        if im.mode in ("RGBA", "RGB", "L"):
            im.save(buf, "PNG")
        else:
            im.convert("RGB").save(buf, "PNG")
        buf.seek(0)
        return ImageReader(buf), w, h

    def _resolve(self, src):
        if self.export_root is None:
            return None
        s = src.replace("$IMS-CC-FILEBASE$", "").replace("%24IMS-CC-FILEBASE%24", "")
        parsed = urlparse(s)
        if parsed.scheme in ("http", "https"):
            return None
        rel = unquote(parsed.path).lstrip("/\\")
        if not rel:
            return None
        root = self.export_root.resolve()
        for cand in (root / rel, root / "web_resources" / rel):
            try:
                c = cand.resolve()
            except OSError:
                continue
            if c.is_file() and str(c).startswith(str(root)):
                return c
        name = Path(rel).name
        hits = sorted(p for p in root.rglob(name) if p.is_file())
        return hits[0] if hits else None

    def _image(self, el, ctx, st):
        src = (el.get("src") or "").strip()
        loaded = self._load_image(src) if src else None
        if loaded is None:
            alt = el.get("alt") or "image"
            if src and not src.startswith("data:"):
                warn(f"Image '{src[:80]}' is not in the export; its description is printed instead.")
            self._text(f"[{alt}]", replace(ctx, italic=True), st)
            return
        reader, pw, ph = loaded
        css = parse_style(el.get("style"))
        w = parse_length(css.get("width") or el.get("width"), relative_to=st.width, em=ctx.size, scale=self.scale)
        h = parse_length(css.get("height") or el.get("height"), em=ctx.size, scale=self.scale)
        ratio = ph / pw if pw else 1
        if w and not h:
            h = w * ratio
        elif h and not w:
            w = h / ratio
        elif not w and not h:
            w, h = pw * PX * self.scale, ph * PX * self.scale
        max_w = max(st.width - st.block.indent, 20)
        if w > max_w:
            w, h = max_w, h * max_w / w
        max_h = 640 * self.scale
        if h > max_h:
            w, h = w * max_h / h, max_h
        if h > ctx.size * 2.2:
            # a picture rather than an in-line symbol: give it its own block
            self._flush(st, ctx)
            img = Picture(reader, w, h)
            img.hAlign = {TA_CENTER: "CENTER", TA_RIGHT: "RIGHT"}.get(st.align, "LEFT")
            img.spaceBefore = img.spaceAfter = ctx.size * 0.3
            st.out.append(img)
            st.after_image = True
            return
        key = f"egimg:{id(reader)}"
        _IMAGE_REGISTRY[key] = reader
        st.parts.append(f'<img src="{key}" width="{w:.2f}" height="{h:.2f}" valign="bottom"/>')
        st.visible = True
        st.trailing_space = False

    # ------------------------------------------------------------ tables
    def _table(self, el, ctx, st):
        rows, header_rows, caption = [], 0, None
        for child in el:
            if not isinstance(child.tag, str) or self._hidden(child):
                continue
            if child.tag == "caption":
                caption = child
            elif child.tag == "tr":
                rows.append((child, False))
            elif child.tag in ("thead", "tbody", "tfoot"):
                for tr in child:
                    if isinstance(tr.tag, str) and tr.tag == "tr" and not self._hidden(tr):
                        rows.append((tr, child.tag == "thead"))
        if not rows:
            return
        tcss = parse_style(el.get("style"))
        avail = max(st.width - st.block.indent, 40)
        width = parse_length(tcss.get("width") or el.get("width"), relative_to=avail, em=ctx.size, scale=self.scale)
        width = min(width, avail) if width else avail

        # grid with spans
        grid, occupied = [], {}
        for r, (tr, _hdr) in enumerate(rows):
            c = 0
            for cell in tr:
                if not isinstance(cell.tag, str) or cell.tag not in ("td", "th") or self._hidden(cell):
                    continue
                while (r, c) in occupied:
                    c += 1
                cs, rs = _span(cell.get("colspan")), _span(cell.get("rowspan"))
                rs = min(rs, len(rows) - r)
                for dr in range(rs):
                    for dc in range(cs):
                        occupied[(r + dr, c + dc)] = (r, c)
                grid.append((r, c, rs, cs, cell, tr))
                c += cs
        if not occupied:
            return
        ncols = max(c for (_r, c) in occupied) + 1
        for r in range(len(rows)):  # leading <thead> rows / rows made only of <th> repeat on each page
            cells = [g[4] for g in grid if g[0] == r]
            if r == header_rows and (rows[r][1] or (cells and all(c.tag == "th" for c in cells))):
                header_rows = r + 1
        nrows = len(rows)

        # column widths
        widths = [None] * ncols
        cols = [c for c in el.iter("col")]
        ci = 0
        for col in cols:
            w = parse_length(parse_style(col.get("style")).get("width") or col.get("width"), relative_to=width, em=ctx.size, scale=self.scale)
            for _ in range(_span(col.get("span"))):
                if ci < ncols and w:
                    widths[ci] = w
                ci += 1
        for r, c, rs, cs, cell, tr in grid:
            if cs == 1 and widths[c] is None:
                w = parse_length(parse_style(cell.get("style")).get("width") or cell.get("width"), relative_to=width, em=ctx.size, scale=self.scale)
                if w:
                    widths[c] = w
        known = sum(w for w in widths if w)
        unknown = [i for i, w in enumerate(widths) if not w]
        if unknown:
            share = max(width - known, 0) / len(unknown)
            if share < 18:
                share = width / ncols
            for i in unknown:
                widths[i] = share
        total = sum(widths)
        widths = [w * width / total for w in widths]

        # default borders from the table itself
        try:
            battr = float(el.get("border", 0) or 0)
        except ValueError:
            battr = 1.0
        default_side = (max(battr * PX, 0.5), colors.black) if battr > 0 else None
        tborder = _borders(tcss, None)
        tcolor = parse_color(tcss.get("border-color"))
        if default_side and tcolor is not None:
            default_side = (default_side[0], tcolor)
        pad = 4 * self.scale
        cpad = parse_length(el.get("cellpadding"), scale=self.scale)
        if cpad is not None:
            pad = max(cpad, 1)

        data = [["" for _ in range(ncols)] for _ in range(nrows)]
        cmds = [("LEFTPADDING", (0, 0), (-1, -1), pad), ("RIGHTPADDING", (0, 0), (-1, -1), pad),
                ("TOPPADDING", (0, 0), (-1, -1), pad * 0.75), ("BOTTOMPADDING", (0, 0), (-1, -1), pad * 0.75)]
        tbg = parse_color(tcss.get("background-color") or el.get("bgcolor"))
        if tbg is not None:
            cmds.append(("BACKGROUND", (0, 0), (-1, -1), tbg))
        for r, c, rs, cs, cell, tr in grid:
            r2, c2 = r + rs - 1, c + cs - 1
            if rs > 1 or cs > 1:
                cmds.append(("SPAN", (c, r), (c2, r2)))
            base = self._apply(tr, replace(ctx, align=TA_LEFT))
            if cell.tag == "th":
                base = replace(base, align=TA_CENTER)
            cctx = self._apply(cell, base)
            ccss, rcss = parse_style(cell.get("style")), parse_style(tr.get("style"))
            cw = sum(widths[c:c2 + 1]) - 2 * pad
            sub = _State(max(cw, 10))
            sub.align = cctx.align
            self._children(cell, cctx, sub)
            self._flush(sub, cctx)
            self._trim(sub.out)
            data[r][c] = sub.out if sub.out else ""
            bg = (parse_color(ccss.get("background-color") or ccss.get("background") or cell.get("bgcolor"))
                  or parse_color(rcss.get("background-color") or rcss.get("background") or tr.get("bgcolor")))
            if bg is not None:
                cmds.append(("BACKGROUND", (c, r), (c2, r2), bg))
            va = (ccss.get("vertical-align") or cell.get("valign") or rcss.get("vertical-align") or tr.get("valign") or "middle").lower()
            cmds.append(("VALIGN", (c, r), (c2, r2), {"top": "TOP", "bottom": "BOTTOM"}.get(va, "MIDDLE")))
            sides = _borders(ccss, default_side)
            edge = {"top": r == 0, "bottom": r2 == nrows - 1, "left": c == 0, "right": c2 == ncols - 1}
            for side, cmd in (("top", "LINEABOVE"), ("bottom", "LINEBELOW"), ("left", "LINEBEFORE"), ("right", "LINEAFTER")):
                line = sides[side]
                if edge[side] and tborder[side] is not None:
                    line = tborder[side]
                if line is not None and line != "none":
                    cmds.append((cmd, (c, r), (c2, r2), line[0], line[1]))

        align = "LEFT"
        if tcss.get("margin-left") == "auto" and tcss.get("margin-right") == "auto" or "auto" in (tcss.get("margin") or "").split()[1:2]:
            align = "CENTER"
        elif tcss.get("margin-left") == "auto" or tcss.get("float") == "right":
            align = "RIGHT"
        if (el.get("align") or "").lower() in ("center", "right", "left"):
            align = el.get("align").upper()
        if caption is not None:
            cap = _State(width)
            cap.align = TA_CENTER
            cctx = self._apply(caption, replace(ctx, align=TA_CENTER))
            self._children(caption, cctx, cap)
            self._flush(cap, cctx)
            st.out.extend(cap.out)
        table = Table(data, colWidths=widths, repeatRows=min(header_rows, nrows - 1), hAlign=align,
                      spaceBefore=ctx.size * 0.4, spaceAfter=ctx.size * 0.6)
        table.setStyle(TableStyle(cmds))
        st.out.append(table)


_IMAGE_REGISTRY = {}

# Let Paragraph <img src="egimg:..."> tags use images that are already in memory.
import reportlab.platypus.paraparser as _pp  # noqa: E402
import reportlab.platypus.paragraph as _para  # noqa: E402

_orig_image_reader = _pp.ImageReader


def _registry_reader(src, *a, **kw):
    if isinstance(src, str) and src in _IMAGE_REGISTRY:
        return _IMAGE_REGISTRY[src]
    return _orig_image_reader(src, *a, **kw)


_pp.ImageReader = _registry_reader
if hasattr(_para, "ImageReader"):
    _para.ImageReader = _registry_reader


def _span(value):
    try:
        return max(1, min(int(value), 1000))
    except (TypeError, ValueError):
        return 1


def _alpha(n):
    s = ""
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s or "A"


def _roman(n):
    out = ""
    for v, s in ((1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"), (50, "L"),
                 (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")):
        while n >= v:
            out += s
            n -= v
    return out or "I"


_BORDER_WIDTHS = {"thin": 0.75, "medium": 2.25, "thick": 3.75}


def _border_shorthand(value, current):
    """Parse 'border: 1px solid #000' -> (width, colour) / 'none' / unchanged."""
    width, color = (current if isinstance(current, tuple) else (0.75, colors.black))
    for tok in re.findall(r"rgba?\([^)]*\)|[^\s]+", value.lower()):
        if tok in ("none", "hidden"):
            return "none"
        if tok in ("solid", "dashed", "dotted", "double", "groove", "ridge", "inset", "outset"):
            pass                  # every visible style is drawn as a solid line
        elif tok in _BORDER_WIDTHS:
            width = _BORDER_WIDTHS[tok]
        else:
            n = parse_length(tok)
            if n is not None and re.match(r"^[\d.]", tok):
                if n == 0:
                    return "none"
                width = max(n, 0.25)
            else:
                c = parse_color(tok)
                if c is not None:
                    color = c
    return (width, color)


def _borders(css, default):
    """Per-side borders for a cell or table: (width, colour), 'none' or None (unspecified)."""
    sides = {s: default for s in ("top", "right", "bottom", "left")}
    order = ("top", "right", "bottom", "left")

    def four(value):
        vals = re.findall(r"rgba?\([^)]*\)|[^\s]+", value)
        if not vals:
            return {}
        idx = {1: (0, 0, 0, 0), 2: (0, 1, 0, 1), 3: (0, 1, 2, 1)}.get(len(vals), (0, 1, 2, 3))
        return {s: vals[i] for s, i in zip(order, idx)}

    if "border" in css:
        v = _border_shorthand(css["border"], default)
        sides = {s: v for s in order}
    for prop, fn in (("border-style", "style"), ("border-width", "width"), ("border-color", "color")):
        if prop in css:
            for s, tok in four(css[prop]).items():
                cur = sides[s]
                if fn == "style":
                    if tok in ("none", "hidden"):
                        sides[s] = "none"
                    elif cur is None or cur == "none":
                        sides[s] = (0.75, colors.black)
                elif fn == "width":
                    n = _BORDER_WIDTHS.get(tok) or parse_length(tok)
                    if n == 0:
                        sides[s] = "none"
                    elif n and cur != "none":
                        sides[s] = (max(n, 0.25), cur[1] if isinstance(cur, tuple) else colors.black)
                else:
                    c = parse_color(tok)
                    if c is not None and isinstance(cur, tuple):
                        sides[s] = (cur[0], c)
    for s in order:
        if f"border-{s}" in css:
            sides[s] = _border_shorthand(css[f"border-{s}"], sides[s] if sides[s] != "none" else None)
        for prop in ("style", "width", "color"):
            key = f"border-{s}-{prop}"
            if key in css:
                sides[s] = _border_shorthand(css[key], sides[s] if sides[s] != "none" else None)
    return sides
