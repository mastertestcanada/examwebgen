"""Reads quizzes written in a Word document (.docx), in the loose format Akindi's importer accepts.

    1. Which of these is a prime number?        a question: numbered 1. 1) Q1 or a Word numbered list
    a. 9                                        options: a. a) (a) A. or a lettered/indented list,
    *b. 11                                        one per line or several on one line
    c. 15
    Answer: B                                   the correct answer: bold, italics, highlighting,
                                                  an asterisk, or an "Answer:" line

Several correct options make a multiple-answer question, True/False options a true/false
question. A question without options is a fill-in-the-blank question (its "Answer:" line, if any,
gives the accepted answers; without one the marker judges what was written), or a number question
when its answer is a number. Matching, dropdown and open-ended questions cannot be marked on a
card and are left out with a warning. Images and tables in a question are printed with it.

The document is untrusted: only the parts needed are read, with size limits, and no external
references are followed.
"""

import atexit
import hashlib
import html
import re
import shutil
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import List, Optional

from lxml import etree

from .errors import ExamError, warn

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
WP = "{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}"
PR = "{http://schemas.openxmlformats.org/package/2006/relationships}"
DC = "{http://purl.org/dc/elements/1.1/}"

SOURCE_NAME = "__word_quiz__.docx"   # the document's copy inside the unpacked folder
MAX_PART = 50 * 2 ** 20              # largest XML part read
MAX_MEDIA = 20 * 2 ** 20             # largest image
MAX_TOTAL = 200 * 2 ** 20            # everything read from the file
IMAGE_TYPES = {".png", ".jpg", ".jpeg", ".gif", ".bmp"}
EMU_PER_PT = 12700

_PARSER = etree.XMLParser(resolve_entities=False, no_network=True, huge_tree=False, remove_comments=True)

QUESTION_RE = re.compile(r"^\s*(?:(?:Q|Question)\s*)?(\d{1,3})\s*[.):](?!\d)\s*", re.I)
OPTION_RE = re.compile(r"^\s*(\*?)\s*\(?([A-Ha-h])\s*[.)]\s*(\*?)\s*")
BARE_OPTION_RE = re.compile(r"^\s*(\*?)\s*([A-Ha-h])\s+(\*?)\s*(?=\S)")      # "d Altercation", only in sequence
INLINE_OPTION_RE = re.compile(r"(?:^|(?<=\s))\*?\(?([A-Ha-h])[.)]\s+")
ANSWER_RE = re.compile(r"^\s*(?:correct\s+)?(?:answers?|ans|key)\s*[.:=\-]\s*(.*)$", re.I)
POINTS_RE = re.compile(r"\s*[(\[]\s*(\d+(?:[.,]\d+)?)\s*(?:pts?|points?|marks?)\s*[)\]]", re.I)
BLANK_RE = re.compile(r"_{3,}")
LETTERS = "abcdefgh"


# ------------------------------------------------------------------ reading the package

class _Package:
    def __init__(self, path):
        try:
            self.zf = zipfile.ZipFile(path)
        except (OSError, zipfile.BadZipFile) as exc:
            raise ExamError(f"{path} could not be read as a Word document ({exc}).")
        self.names = {i.filename: i for i in self.zf.infolist()}
        self.total = 0

    def read(self, name, limit=MAX_PART):
        info = self.names.get(name)
        if info is None:
            return None
        if info.file_size > limit or self.total + info.file_size > MAX_TOTAL:
            raise ExamError(f"The Word document is too large to read ({name}).")
        data = self.zf.read(info)
        if len(data) > limit:        # the header lied about the size
            raise ExamError(f"The Word document is too large to read ({name}).")
        self.total += len(data)
        return data

    def xml(self, name):
        data = self.read(name)
        if data is None:
            return None
        try:
            return etree.fromstring(data, _PARSER)
        except etree.XMLSyntaxError as exc:
            raise ExamError(f"The Word document is damaged ({name}: {exc}).")


def is_word(path):
    p = Path(path)
    return p.is_file() and p.suffix.lower() == ".docx"


def open_document(path):
    """An unpacked folder for a .docx: a copy of the document and its images (media/)."""
    src = Path(path)
    pkg = _Package(src)
    if "word/document.xml" not in pkg.names:
        raise ExamError(f"{src.name} is not a Word document (.docx).")
    tmp = Path(tempfile.mkdtemp(prefix="examgen_word_"))
    atexit.register(shutil.rmtree, tmp, ignore_errors=True)
    shutil.copyfile(src, tmp / SOURCE_NAME)
    (tmp / "source_name.txt").write_text(src.name, encoding="utf-8")
    return tmp


def is_word_folder(root):
    return (Path(root) / SOURCE_NAME).is_file()


def quiz_title(root):
    root = Path(root)
    pkg = _Package(root / SOURCE_NAME)
    core = pkg.xml("docProps/core.xml")
    title = (core.findtext(DC + "title") or "").strip() if core is not None else ""
    if not title:
        doc = pkg.xml("word/document.xml")
        for p in doc.iter(W + "p"):
            style = _style(p)
            text = "".join(t.text or "" for t in p.iter(W + "t")).strip()
            if text and (style.startswith("title") or style.startswith("heading")):
                title = text
                break
            if text:
                break
    if not title:
        name = (root / "source_name.txt").read_text(encoding="utf-8") if (root / "source_name.txt").exists() else "Quiz"
        title = Path(name).stem
    return title


def quiz_ident(root):
    data = (Path(root) / SOURCE_NAME).read_bytes()
    pkg = _Package(Path(root) / SOURCE_NAME)
    body = pkg.read("word/document.xml") or data
    return "word-" + hashlib.sha256(body).hexdigest()[:16]


# ------------------------------------------------------------------ paragraphs

@dataclass
class _Run:
    text: str
    bold: bool = False
    italic: bool = False
    highlight: bool = False
    underline: bool = False
    script: str = ""        # "sup" / "sub"


@dataclass
class _Para:
    runs: List[_Run] = field(default_factory=list)
    images: List[str] = field(default_factory=list)    # <img> HTML
    list_fmt: Optional[str] = None                     # decimal, lowerLetter, bullet, ... (Word numbering)
    list_level: int = 0
    list_label: str = ""                               # the number or letter Word draws
    list_key: tuple = ()                               # (list, level): which Word list it belongs to
    heading: bool = False
    table_html: str = ""                               # set for a table, which has no runs

    @property
    def text(self):
        return "".join(r.text for r in self.runs)

    @property
    def empty(self):
        return not self.text.strip() and not self.images and not self.table_html


def _style(p):
    st = p.find(f"{W}pPr/{W}pStyle")
    return (st.get(W + "val") or "").lower() if st is not None else ""


def _on(el):
    return el is not None and (el.get(W + "val") or "true").lower() not in ("0", "false", "none", "off")


class _Numbering:
    """Word's automatic numbering: the format and current number of each list level."""

    def __init__(self, pkg, styles):
        self.fmt = {}         # (abstract id, level) -> (numFmt, start)
        self.abstract = {}    # numId -> abstract id
        self.counts = {}      # abstract id -> [count per level]
        self.style_num = {}   # paragraph style id (lower case) -> (numId, level)
        root = pkg.xml("word/numbering.xml")
        if root is not None:
            for an in root.iterfind(W + "abstractNum"):
                aid = an.get(W + "abstractNumId")
                for lvl in an.iterfind(W + "lvl"):
                    nf = lvl.find(W + "numFmt")
                    st = lvl.find(W + "start")
                    self.fmt[(aid, int(lvl.get(W + "ilvl") or 0))] = (
                        nf.get(W + "val") if nf is not None else "decimal",
                        int(st.get(W + "val") or 1) if st is not None else 1)
            for num in root.iterfind(W + "num"):
                a = num.find(W + "abstractNumId")
                if a is not None:
                    self.abstract[num.get(W + "numId")] = a.get(W + "val")
        if styles is not None:
            for s in styles.iterfind(W + "style"):
                np_ = s.find(f"{W}pPr/{W}numPr")
                if np_ is not None:
                    nid = np_.find(W + "numId")
                    il = np_.find(W + "ilvl")
                    if nid is not None:
                        self.style_num[(s.get(W + "styleId") or "").lower()] = (
                            nid.get(W + "val"), int(il.get(W + "val") or 0) if il is not None else 0)

    def label(self, p):
        """(format, level, label) of a numbered paragraph, or None."""
        np_ = p.find(f"{W}pPr/{W}numPr")
        nid, lvl = None, 0
        if np_ is not None:
            n = np_.find(W + "numId")
            il = np_.find(W + "ilvl")
            nid = n.get(W + "val") if n is not None else None
            lvl = int(il.get(W + "val") or 0) if il is not None else 0
        elif _style(p) in self.style_num:
            nid, lvl = self.style_num[_style(p)]
        if not nid or nid == "0" or nid not in self.abstract:
            return None
        aid = self.abstract[nid]
        fmt, start = self.fmt.get((aid, lvl), ("decimal", 1))
        counts = self.counts.setdefault(aid, [0] * 9)
        lvl = min(lvl, 8)
        counts[lvl] += 1
        for deeper in range(lvl + 1, 9):
            counts[deeper] = 0
        n = start + counts[lvl] - 1
        if fmt in ("lowerLetter", "upperLetter"):
            label = LETTERS[(n - 1) % 8] if n >= 1 else "a"
            label = label.upper() if fmt == "upperLetter" else label
        elif fmt == "decimal":
            label = str(n)
        else:
            label = ""
        return fmt, lvl, label, (aid, lvl)


class _Reader:
    def __init__(self, root):
        self.root = Path(root)
        self.pkg = _Package(self.root / SOURCE_NAME)
        self.doc = self.pkg.xml("word/document.xml")
        if self.doc is None:
            raise ExamError("The Word document has no text (word/document.xml is missing).")
        styles = self.pkg.xml("word/styles.xml")
        self.numbering = _Numbering(self.pkg, styles)
        self.char_styles = {}
        if styles is not None:
            for s in styles.iterfind(W + "style"):
                rp = s.find(W + "rPr")
                if rp is not None and s.get(W + "type") in ("character", "paragraph"):
                    self.char_styles[(s.get(W + "styleId") or "").lower()] = (
                        _on(rp.find(W + "b")), _on(rp.find(W + "i")))
        self.rels = {}
        rels = self.pkg.xml("word/_rels/document.xml.rels")
        if rels is not None:
            for r in rels.iterfind(PR + "Relationship"):
                if (r.get("TargetMode") or "").lower() == "external":
                    continue
                self.rels[r.get("Id")] = r.get("Target") or ""
        self.media = {}

    def _image(self, rid, width_pt, alt):
        target = self.rels.get(rid)
        if not target:
            return None
        part = str(PurePosixPath("word") / target) if not target.startswith("/") else target.lstrip("/")
        part = str(PurePosixPath(part))
        while "/../" in part:   # word/../media/x.png
            part = re.sub(r"[^/]+/\.\./", "", part, count=1)
        ext = PurePosixPath(part).suffix.lower()
        if ext not in IMAGE_TYPES:
            return None
        if part not in self.media:
            data = self.pkg.read(part, MAX_MEDIA)
            if data is None:
                return None
            name = f"image{len(self.media) + 1}{ext}"
            (self.root / "media").mkdir(exist_ok=True)
            (self.root / "media" / name).write_bytes(data)
            self.media[part] = name
        style = f' style="width:{width_pt:.0f}pt"' if width_pt else ""
        return f'<img src="media/{self.media[part]}" alt="{html.escape(alt or "image", quote=True)}"{style}>'

    def _runs(self, p, para, pstyle_bold):
        for r in p.iter(W + "r"):
            if r.getparent().tag == W + "rPr":
                continue
            rp = r.find(W + "rPr")
            bold = italic = hl = ul = False
            script = ""
            if rp is not None:
                bold, italic = _on(rp.find(W + "b")), _on(rp.find(W + "i"))
                hl = _on(rp.find(W + "highlight"))
                shd = rp.find(W + "shd")
                if shd is not None and (shd.get(W + "fill") or "auto").lower() not in ("auto", "ffffff", ""):
                    hl = True
                ul = _on(rp.find(W + "u"))
                va = rp.find(W + "vertAlign")
                if va is not None:
                    script = {"superscript": "sup", "subscript": "sub"}.get(va.get(W + "val"), "")
                rs = rp.find(W + "rStyle")
                if rs is not None:
                    sb, si = self.char_styles.get((rs.get(W + "val") or "").lower(), (False, False))
                    bold, italic = bold or sb, italic or si
                if rp.find(W + "b") is None:
                    bold = bold or pstyle_bold[0]
                if rp.find(W + "i") is None:
                    italic = italic or pstyle_bold[1]
            else:
                bold, italic = pstyle_bold
            text = ""
            for child in r:
                if child.tag == W + "t":
                    text += child.text or ""
                elif child.tag == W + "tab":
                    text += "\t"
                elif child.tag in (W + "br", W + "cr"):
                    text += "\n"
                elif child.tag == W + "drawing":
                    blip = child.find(f".//{A}blip")
                    ext = child.find(f".//{WP}extent")
                    doc_pr = child.find(f".//{WP}docPr")
                    width = int(ext.get("cx") or 0) / EMU_PER_PT if ext is not None else 0
                    if blip is not None:
                        img = self._image(blip.get(R + "embed"), width,
                                          (doc_pr.get("descr") or doc_pr.get("title") or "") if doc_pr is not None else "")
                        if img:
                            para.images.append(img)
            if text:
                para.runs.append(_Run(text, bold, italic, hl, ul, script))

    def _para(self, p):
        para = _Para()
        style = _style(p)
        para.heading = style.startswith("heading") or style == "title"
        lab = self.numbering.label(p)
        if lab:
            para.list_fmt, para.list_level, para.list_label, para.list_key = lab
        self._runs(p, para, self.char_styles.get(style, (False, False)) if not para.heading else (False, False))
        return para

    def _table(self, tbl):
        rows = []
        for tr in tbl.iterfind(W + "tr"):
            cells = []
            for tc in tr.iterfind(W + "tc"):
                parts = []
                for p in tc.iter(W + "p"):
                    para = self._para(p)
                    parts.append(_html(para.runs) + "".join(para.images))
                cells.append("<td>" + "<br>".join(x for x in parts if x) + "</td>")
            rows.append("<tr>" + "".join(cells) + "</tr>")
        return '<table border="1" cellpadding="3">' + "".join(rows) + "</table>"

    def paragraphs(self):
        body = self.doc.find(W + "body")
        if body is None:
            return []
        out = []
        for el in body:
            if el.tag == W + "p":
                out.append(self._para(el))
            elif el.tag == W + "tbl":
                out.append(_Para(table_html=self._table(el)))
            elif el.tag == W + "sdt":   # content controls: their paragraphs
                for p in el.iter(W + "p"):
                    out.append(self._para(p))
        return out


def _html(runs):
    out = []
    for r in runs:
        t = html.escape(r.text, quote=False).replace("\n", "<br>").replace("\t", " ")
        if r.script:
            t = f"<{r.script}>{t}</{r.script}>"
        if r.underline and not BLANK_RE.search(r.text):
            t = f"<u>{t}</u>"
        if r.italic:
            t = f"<i>{t}</i>"
        if r.bold:
            t = f"<b>{t}</b>"
        out.append(t)
    return "".join(out)


def _strip_prefix(runs, n):
    """The runs without their first n characters."""
    out, left = [], n
    for r in runs:
        if left >= len(r.text):
            left -= len(r.text)
            continue
        out.append(_Run(r.text[left:], r.bold, r.italic, r.highlight, r.underline, r.script))
        left = 0
    return out


def _strip_suffix_star(runs):
    text = "".join(r.text for r in runs).rstrip()
    if not text.endswith("*"):
        return runs, False
    keep = len(text) - 1
    out, used = [], 0
    for r in runs:
        if used >= keep:
            break
        part = r.text[:keep - used]
        out.append(_Run(part, r.bold, r.italic, r.highlight, r.underline, r.script))
        used += len(part)
    return out, True


def _marked_fraction(runs):
    total = marked = 0
    for r in runs:
        n = sum(1 for ch in r.text if not ch.isspace())
        total += n
        if r.bold or r.italic or r.highlight:
            marked += n
    return marked / total if total else 0.0


def _split_runs(runs, cuts):
    """Split runs at character positions `cuts` (ascending); returns the pieces."""
    pieces, bounds = [], [0] + list(cuts) + [sum(len(r.text) for r in runs)]
    for a, b in zip(bounds, bounds[1:]):
        piece, pos = [], 0
        for r in runs:
            lo, hi = max(a, pos), min(b, pos + len(r.text))
            if lo < hi:
                piece.append(_Run(r.text[lo - pos:hi - pos], r.bold, r.italic, r.highlight, r.underline, r.script))
            pos += len(r.text)
        pieces.append(piece)
    return pieces


# ------------------------------------------------------------------ questions

@dataclass
class _Opt:
    runs: List[_Run]
    star: bool = False
    images: List[str] = field(default_factory=list)

    @property
    def text(self):
        return "".join(r.text for r in self.runs).strip()


@dataclass
class _Q:
    number: str
    stem: List[str] = field(default_factory=list)      # HTML blocks
    stem_text: str = ""
    options: List[_Opt] = field(default_factory=list)
    loose: List[_Para] = field(default_factory=list)   # unlabelled lines after the stem
    answer: Optional[str] = None
    labelled: bool = False                             # options carry letters (typed or Word's)
    list_options: bool = False                         # options are a Word list


def _option_from(runs, label_len, star_before, star_after, images=()):
    rest = _strip_prefix(runs, label_len)
    rest, star_end = _strip_suffix_star(rest)
    return _Opt(rest, star_before or star_after or star_end, list(images))


def _inline_options(text):
    """Positions of a sequence of option labels a), b), c)... within one line, or []."""
    found, want = [], 0
    for m in INLINE_OPTION_RE.finditer(text):
        if m.group(1).lower() == LETTERS[want]:
            found.append(m.start() if text[m.start()] != " " else m.start() + 1)
            want += 1
            if want == len(LETTERS):
                break
    return found if len(found) >= 2 else []


def _parse_questions(paras):
    questions, preamble = [], []
    numbered_doc = any(QUESTION_RE.match(p.text) or (p.list_fmt == "decimal" and p.list_level == 0) for p in paras)
    question_list = None      # the Word list the questions are numbered with, once one is
    q = None
    closed = False
    for p in paras:
        text = p.text
        if p.empty:
            if q is not None and (q.options or q.loose or q.stem):
                closed = True
            continue
        if p.table_html:
            if q is None:
                preamble.append(p)
            elif not q.options:
                q.stem.append(p.table_html)
            continue
        am = ANSWER_RE.match(text)
        if am and q is not None:
            q.answer = am.group(1).strip()
            continue

        # a new question?
        qm = QUESTION_RE.match(text)
        auto_q = (p.list_fmt == "decimal" and p.list_level == 0
                  and (question_list is None or p.list_key == question_list or q is None))
        expected = LETTERS[len(q.options)] if q is not None and len(q.options) < len(LETTERS) else None
        om = OPTION_RE.match(text)
        is_option = (q is not None and om is not None and om.group(2).lower() == expected
                     and not auto_q and not (qm and not om))
        if (qm or auto_q) and not is_option:
            q = _Q(qm.group(1) if qm else p.list_label)
            questions.append(q)
            if auto_q and not qm:
                question_list = p.list_key
            runs = _strip_prefix(p.runs, qm.end()) if qm else p.runs
            stem_line = "".join(r.text for r in runs)
            cuts = _inline_options(stem_line)
            if cuts:                       # "Pick one: a) 3  b) 30  c) 0.3"
                pieces = _split_runs(runs, cuts)
                runs = pieces[0]
                for piece in pieces[1:]:
                    m = OPTION_RE.match("".join(r.text for r in piece))
                    q.options.append(_option_from(piece, m.end() if m else 0, bool(m and m.group(1)), bool(m and m.group(3))))
                q.labelled = True
            q.stem.append(_html(runs) + "".join(p.images))
            q.stem_text = "".join(r.text for r in runs)
            closed = False
            continue
        if q is None and (p.heading or numbered_doc):
            preamble.append(p)          # title, name line, instructions
            continue
        if q is None or (not numbered_doc and closed and not is_option
                         and not (p.list_fmt and p.list_fmt != "decimal")):
            # an unnumbered document: a line after a finished question starts the next one
            q = _Q(str(len(questions) + 1))
            questions.append(q)
            q.stem.append(_html(p.runs) + "".join(p.images))
            q.stem_text = text
            closed = False
            continue

        # an option?
        if is_option:
            q.options.append(_option_from(p.runs, om.end(), bool(om.group(1)), bool(om.group(3)), p.images))
            q.labelled = True
            continue
        if expected and q.labelled and expected != "a":
            bm = BARE_OPTION_RE.match(text)
            if bm and bm.group(2).lower() == expected:
                q.options.append(_option_from(p.runs, bm.end(), bool(bm.group(1)), bool(bm.group(3)), p.images))
                continue
        if p.list_fmt in ("lowerLetter", "upperLetter") or (p.list_fmt and p.list_level > 0):
            star = text.lstrip().startswith("*")
            runs = _strip_prefix(p.runs, len(text) - len(text.lstrip()) + (1 if star else 0))
            opt = _option_from(runs, 0, star, False, p.images)
            q.options.append(opt)
            q.labelled = q.labelled or p.list_fmt in ("lowerLetter", "upperLetter")
            q.list_options = True
            continue
        cuts = _inline_options(text) if not q.options else []
        if cuts:
            for piece in _split_runs(p.runs, cuts)[1:]:
                ptext = "".join(r.text for r in piece)
                m = OPTION_RE.match(ptext)
                q.options.append(_option_from(piece, m.end() if m else 0, bool(m and m.group(1)), bool(m and m.group(3))))
            head = _split_runs(p.runs, cuts)[0]
            if "".join(r.text for r in head).strip():
                q.stem.append(_html(head))
                q.stem_text += " " + "".join(r.text for r in head)
            q.labelled = True
            continue
        if q.options:
            if q.list_options or not q.labelled:
                q.options.append(_option_from(p.runs, 0, text.lstrip().startswith("*"), False, p.images))
                if text.lstrip().startswith("*"):
                    q.options[-1].runs = _strip_prefix(p.runs, len(text) - len(text.lstrip()) + 1)
            else:
                q.stem.append(_html(p.runs) + "".join(p.images))   # text after the options
            continue
        q.loose.append(p)
    return questions, preamble


def _resolve_loose(q):
    """Unlettered lines after the stem: options when they look like options (two or more, and one is
    marked or the answer line names a letter); otherwise more question text."""
    if not q.loose:
        return
    lines = q.loose
    marked = [l for l in lines if l.text.lstrip().startswith("*") or l.text.rstrip().endswith("*")
              or _marked_fraction(l.runs) >= 0.8]
    letter_answer = q.answer is not None and re.fullmatch(r"[A-Ha-h](?:\s*(?:,|;|/|and|&)?\s*[A-Ha-h])*", q.answer.strip())
    if len(lines) >= 2 and (marked or letter_answer) and len(marked) < len(lines):
        for l in lines:
            t = l.text
            star = t.lstrip().startswith("*")
            runs = _strip_prefix(l.runs, len(t) - len(t.lstrip()) + (1 if star else 0))
            q.options.append(_option_from(runs, 0, star, False, l.images))
    else:
        for l in lines:
            q.stem.append(_html(l.runs) + "".join(l.images))
            q.stem_text += " " + l.text
    q.loose = []


def _letters(answer, n):
    parts = re.split(r"\s*(?:,|;|/|&|\band\b|\s)\s*", answer.strip())
    parts = [x for x in parts if x]
    if parts and all(len(x) == 1 and x.lower() in LETTERS[:n] for x in parts):
        return {LETTERS.index(x.lower()) for x in parts}
    return None


def _number(text):
    t = text.strip().replace(",", ".") if text.count(",") == 1 and "." not in text else text.strip()
    try:
        float(t)
        return t
    except ValueError:
        return None


def build_questions(paras, canvas):
    """canvas: the canvas module (for Question, Option and the limits)."""
    found, preamble = _parse_questions(paras)
    out = []
    for n, q in enumerate(found, 1):
        # matching: "Match the ..." with "term = answer" lines (Akindi's format)
        pair_lines = []
        if "match" in q.stem_text.lower():
            lines = [l.text for l in q.loose] + [o.text for o in q.options]
            pair_lines = [t for t in lines if " = " in t]
            if pair_lines:
                q.loose, q.options = [l for l in q.loose if " = " not in l.text], [o for o in q.options if " = " not in o.text]
        _resolve_loose(q)
        label = f"Question {q.number or n}"
        stem_text = q.stem_text.strip()
        points = 1.0
        pm = POINTS_RE.search(stem_text)
        stem_html = "".join(f"<p>{b}</p>" if b and not b.startswith("<table") else b for b in q.stem if b)
        if pm:
            points = float(pm.group(1).replace(",", "."))
            stem_html = POINTS_RE.sub("", stem_html, count=1)
        stem_html = BLANK_RE.sub(canvas.BLANK, stem_html)
        ident = f"word-{n}"
        title = label

        if pair_lines:
            qq = canvas.Question(ident, title, "matching_question", points, stem_html, [], kind="match")
            for line in pair_lines:
                term, _eq, answer = line.partition(" = ")
                term = OPTION_RE.sub("", term, count=1).strip().lstrip("*").strip()
                answer = answer.strip()
                if answer not in qq.answers:
                    qq.answers.append(answer)
                qq.prompts.append(html.escape(term, quote=False))
                qq.matches.append(qq.answers.index(answer))
            qq.answers = [html.escape(a, quote=False) for a in qq.answers]
            if len(qq.prompts) > canvas.MAX_MATCH_PROMPTS:
                warn(f"Question {q.number or n} was omitted: it has {len(qq.prompts)} items; at most {canvas.MAX_MATCH_PROMPTS} are supported.")
                continue
            out.append(qq)
            continue

        if not q.options:
            if q.answer:
                num = _number(q.answer)
                if num is not None and not BLANK_RE.search(stem_text) and len(num.lstrip("+")) <= canvas.NUMERIC_BOXES:
                    qq = canvas.Question(ident, title, "calculated_question", points, stem_html, [], kind="numeric")
                    qq.value_sets = [({}, num.lstrip("+"))]
                    out.append(qq)
                    continue
                accepted = [a.strip() for a in re.split(r"\s*(?:;|\|)\s*", q.answer) if a.strip()]
                qq = canvas.Question(ident, title, "short_answer_question", points, stem_html, [], kind="text")
                qq.accepted = accepted
                out.append(qq)
                continue
            if BLANK_RE.search(stem_text):
                qq = canvas.Question(ident, title, "short_answer_question", points, stem_html, [], kind="text")
                out.append(qq)          # no answer given: the marker judges what was written
                continue
            warn(f"Question {q.number or n} was omitted: it has no answer options and no blank (open-ended questions "
                 f"cannot be marked on an answer card).")
            continue

        if len(q.options) > canvas.MAX_OPTIONS:
            warn(f"Question {q.number or n} was omitted: it has {len(q.options)} options; at most {canvas.MAX_OPTIONS} (A-F) are supported.")
            continue
        correct = {i for i, o in enumerate(q.options) if o.star}
        if not correct and q.answer:
            letters = _letters(q.answer, len(q.options))
            if letters is None:
                hit = [i for i, o in enumerate(q.options) if o.text.lower() == q.answer.strip().lower()]
                letters = set(hit) if hit else None
            if letters:
                correct = letters
        if not correct:
            fractions = [_marked_fraction(o.runs) for o in q.options]
            marked = {i for i, f in enumerate(fractions) if f >= 0.8}
            if marked and len(marked) < len(q.options):
                correct = marked
        if not correct:
            warn(f"Question {q.number or n} was omitted: no correct answer is marked (use bold, italics, highlighting, "
                 f"an asterisk or an 'Answer:' line).")
            continue
        texts = [o.text for o in q.options]
        if any(not t and not o.images for t, o in zip(texts, q.options)):
            warn(f"Question {q.number or n} was omitted: one of its options is empty.")
            continue
        tf = len(texts) == 2 and {t.lower().rstrip(".") for t in texts} in ({"true", "false"}, {"vrai", "faux"})
        qtype = ("true_false_question" if tf and len(correct) == 1 else
                 "multiple_choice_question" if len(correct) == 1 else "multiple_answers_question")
        options = []
        for i, o in enumerate(q.options):
            runs = [_Run(r.text, False, False, False, r.underline, r.script) for r in o.runs]   # the marking is not printed
            body = _html(runs).strip() + "".join(o.images)
            options.append(canvas.Option(f"{ident}-{LETTERS[i]}", body, True, i in correct, i))
        out.append(canvas.Question(ident, title, qtype, points, stem_html, options))
    return out, preamble


def load(root, canvas):
    """The quiz in the unpacked Word document at `root`: (title, description, [Question])."""
    reader = _Reader(root)
    questions, preamble = build_questions(reader.paragraphs(), canvas)
    skipped = [p for p in preamble if not p.heading and p.text.strip()]
    if skipped:
        warn(f"{len(skipped)} paragraph(s) before the first question (such as a name line or instructions) "
             f"are not printed; MasterTest prints its own instructions.")
    return questions


def describe(question, canvas):
    """For the summary of what was read: type, answer, start of the text, points (as written: 2, 1.5)."""
    text = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", question.html))).strip()
    text = text if len(text) <= 60 else text[:57] + "..."
    if question.kind == "numeric":
        kind, answer = "number", question.value_sets[0][1]
    elif question.kind == "text":
        kind, answer = "fill in the blank", " | ".join(question.accepted) or "(marked by hand)"
    elif question.kind == "match":
        # the answers are numbered differently on each exam: each item with its answer's text
        plain = lambda h: re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", h))).strip()
        kind, answer = "matching", ", ".join(f"{'abcdefghijklmnopqrstuvwxyz'[k]} = {plain(question.answers[m])}"
                                             for k, m in enumerate(question.matches))
    else:
        kind = {"true_false_question": "true/false", "multiple_choice_question": "multiple choice",
                "multiple_answers_question": "multiple answers"}[question.qtype]
        answer = ", ".join(LETTERS[o.export_pos].upper() for o in sorted(question.options, key=lambda o: o.export_pos)
                           if o.correct)
    points = f"{question.points:g}" if question.points is not None else "1"
    return kind, answer, text, points
