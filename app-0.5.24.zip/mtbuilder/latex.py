"""Canvas equations: the Canvas editor stores an equation as a picture its server draws from LaTeX,

    <img class="equation_image" src="/equation_images/..." alt="LaTeX: x^2" data-equation-content="x^2">

and the picture is not in the export. `equations(html)` prints each one as text instead, the way D2L's
MathML equations are printed (d2l.mathml): superscripts and subscripts as <sup> and <sub>, fractions
as (a)/(b), roots as √(…), the lines of an aligned equation on lines of their own, single letters in
italics. LaTeX that is not understood is printed as it was written, never left out.
"""
import html as _html
import re
import urllib.parse

_IMG = re.compile(r"<img\b[^>]*>", re.I)
_ATTR = re.compile(r"([\w:-]+)\s*=\s*(\"[^\"]*\"|'[^']*')")

SYMBOLS = {
    # Greek
    "alpha": "α", "beta": "β", "gamma": "γ", "delta": "δ", "epsilon": "ε", "varepsilon": "ε", "zeta": "ζ",
    "eta": "η", "theta": "θ", "vartheta": "ϑ", "iota": "ι", "kappa": "κ", "lambda": "λ", "mu": "μ", "nu": "ν",
    "xi": "ξ", "pi": "π", "varpi": "ϖ", "rho": "ρ", "varrho": "ϱ", "sigma": "σ", "varsigma": "ς", "tau": "τ",
    "upsilon": "υ", "phi": "φ", "varphi": "φ", "chi": "χ", "psi": "ψ", "omega": "ω",
    "Gamma": "Γ", "Delta": "Δ", "Theta": "Θ", "Lambda": "Λ", "Xi": "Ξ", "Pi": "Π", "Sigma": "Σ",
    "Upsilon": "Υ", "Phi": "Φ", "Psi": "Ψ", "Omega": "Ω",
    # operators and relations (spaced like + and =)
    "times": " × ", "cdot": " · ", "div": " ÷ ", "pm": " ± ", "mp": " ∓ ", "ast": " ∗ ",
    "le": " ≤ ", "leq": " ≤ ", "ge": " ≥ ", "geq": " ≥ ", "ne": " ≠ ", "neq": " ≠ ", "approx": " ≈ ",
    "equiv": " ≡ ", "sim": " ∼ ", "simeq": " ≃ ", "cong": " ≅ ", "propto": " ∝ ", "ll": " ≪ ", "gg": " ≫ ",
    "in": " ∈ ", "notin": " ∉ ", "ni": " ∋ ", "subset": " ⊂ ", "subseteq": " ⊆ ", "supset": " ⊃ ",
    "supseteq": " ⊇ ", "cup": " ∪ ", "cap": " ∩ ", "setminus": " ∖ ", "wedge": " ∧ ", "land": " ∧ ",
    "vee": " ∨ ", "lor": " ∨ ", "oplus": " ⊕ ", "otimes": " ⊗ ", "circ": "∘", "bullet": "•",
    "to": " → ", "rightarrow": " → ", "leftarrow": " ← ", "Rightarrow": " ⇒ ", "Leftarrow": " ⇐ ",
    "leftrightarrow": " ↔ ", "Leftrightarrow": " ⇔ ", "implies": " ⇒ ", "iff": " ⇔ ", "mapsto": " ↦ ",
    "longrightarrow": " ⟶ ", "rightleftharpoons": " ⇌ ", "uparrow": "↑", "downarrow": "↓",
    "perp": " ⊥ ", "parallel": " ∥ ", "mid": " | ", "therefore": "∴ ", "because": "∵ ",
    # others
    "infty": "∞", "partial": "∂", "nabla": "∇", "forall": "∀", "exists": "∃", "neg": "¬", "lnot": "¬",
    "emptyset": "∅", "varnothing": "∅", "angle": "∠", "triangle": "△", "degree": "°", "prime": "′",
    "ldots": "…", "dots": "…", "cdots": "⋯", "vdots": "⋮", "hbar": "ħ", "ell": "ℓ", "Re": "ℜ", "Im": "ℑ",
    "sum": "∑", "prod": "∏", "int": "∫", "iint": "∬", "oint": "∮", "sqcup": "⊔",
    "langle": "⟨", "rangle": "⟩", "lvert": "|", "rvert": "|", "vert": "|", "lVert": "‖", "rVert": "‖",
    "Vert": "‖", "|": "‖", "lfloor": "⌊", "rfloor": "⌋", "lceil": "⌈", "rceil": "⌉",
    "{": "{", "}": "}", "%": "%", "$": "$", "&": "&", "#": "#", "_": "_",
    "quad": "  ", "qquad": "    ", ",": " ", ";": " ", ":": " ", " ": " ", "!": "", "displaystyle": "",
    "textstyle": "", "left": "", "right": "", "big": "", "Big": "", "bigg": "", "Bigg": "", "limits": "",
    "nolimits": "", "nonumber": "", "notag": "",
}
# names printed upright, as words
FUNCTIONS = {"sin", "cos", "tan", "sec", "csc", "cot", "arcsin", "arccos", "arctan", "sinh", "cosh", "tanh",
             "log", "ln", "lg", "exp", "lim", "max", "min", "sup", "inf", "det", "gcd", "deg", "arg", "dim",
             "ker", "mod", "Pr"}
BLACKBOARD = {"R": "ℝ", "N": "ℕ", "Z": "ℤ", "Q": "ℚ", "C": "ℂ", "P": "ℙ"}
ACCENTS = {"vec": "\u20d7", "hat": "\u0302", "bar": "\u0305", "overline": "\u0305", "tilde": "\u0303",
           "dot": "\u0307", "ddot": "\u0308", "widehat": "\u0302", "widetilde": "\u0303", "overrightarrow": "\u20d7"}
SPACED = "=+<>"


def equations(html):
    """`html` with each Canvas equation picture replaced by the equation as text."""
    if "equation_image" not in html:
        return html
    return _IMG.sub(_replace, html)


def _replace(m):
    tag = m.group(0)
    attrs = {k.lower(): _html.unescape(v[1:-1]) for k, v in _ATTR.findall(tag)}
    if "equation_image" not in attrs.get("class", ""):
        return tag
    source = attrs.get("data-equation-content")
    if not source and attrs.get("alt", "").startswith("LaTeX:"):
        source = attrs["alt"][len("LaTeX:"):]
    if not source:
        source = attrs.get("title")
    if not source and "/equation_images/" in attrs.get("src", ""):
        code = attrs["src"].split("/equation_images/", 1)[1].split("?", 1)[0]
        source = urllib.parse.unquote(urllib.parse.unquote(code))
    if not source or not source.strip():
        return tag
    return to_html(source)


def to_html(source):
    """One LaTeX equation as HTML text."""
    try:
        return _Parser(source).document()
    except Exception:       # never lose the equation: print what was written
        return _esc(source.strip())


def _esc(text):
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _group(html):
    """Brackets round a part of a fraction that is more than a number or a letter: (x + 1)/(2a)."""
    plain = re.sub(r"<[^>]+>", "", html).strip()
    if len(plain) <= 1 or re.fullmatch(r"[\d.,]+", plain) or (plain.startswith("(") and plain.endswith(")")
                                                             and plain.count("(") == 1):
        return html
    return f"({html})"


_TOKEN = re.compile(r"\\([A-Za-z]+)\*?|\\(.)|(\s+)|(.)", re.S)


class _Parser:
    def __init__(self, source):
        self.tokens = []
        for m in _TOKEN.finditer(source):
            if m.group(1) is not None:
                self.tokens.append(("cmd", m.group(1)))
            elif m.group(2) is not None:
                self.tokens.append(("cmd", m.group(2)))
            elif m.group(3) is not None:
                self.tokens.append(("space", m.group(3)))
            else:
                self.tokens.append(("char", m.group(4)))
        self.i = 0

    def peek(self):
        return self.tokens[self.i] if self.i < len(self.tokens) else None

    def take(self):
        t = self.peek()
        self.i += 1
        return t

    def skip_space(self):
        while self.peek() and self.peek()[0] == "space":
            self.i += 1

    def document(self):
        return self._tidy(self.sequence(stop=None))

    @staticmethod
    def _tidy(html):
        html = re.sub(r" {2,}", lambda m: " " if len(m.group(0)) < 4 else "\u2003", html)
        lines = [line.strip() for line in html.split("<br/>")]
        while lines and not lines[0]:
            lines.pop(0)
        while lines and not lines[-1]:
            lines.pop()
        return "<br/>".join(lines)

    def sequence(self, stop):
        """Everything up to the closing `stop` ("}", "]", "end" or None for the end)."""
        out = []
        while True:
            t = self.peek()
            if t is None:
                break
            kind, value = t
            if stop == "}" and kind == "char" and value == "}":
                self.i += 1
                break
            if stop == "]" and kind == "char" and value == "]":
                self.i += 1
                break
            if stop == "end" and kind == "cmd" and value == "end":
                self.i += 1
                self.raw_group()
                break
            if t == ("char", "-") and self._unary(out):
                self.i += 1
                out.append("−")
                continue
            out.append(self.atom_with_scripts())
        return "".join(out)

    @staticmethod
    def _unary(out):
        """A minus sign with nothing, an operator or an opening bracket before it (−3, x = −y)."""
        before = re.sub(r"<[^>]+>", "", "".join(out))
        return not before.strip() or before.endswith((" ", "(", "[", "{", "<br/>"))

    def raw_group(self):
        """The text of a {...} argument as written (environment names, \\text)."""
        self.skip_space()
        t = self.peek()
        if not t or t != ("char", "{"):
            return ""
        self.i += 1
        depth, out = 1, []
        while self.peek():
            kind, value = self.take()
            if kind == "char" and value == "{":
                depth += 1
            elif kind == "char" and value == "}":
                depth -= 1
                if depth == 0:
                    break
            out.append(value if kind != "cmd" else ("\\" + value if value.isalpha() else value))
        return "".join(out)

    def argument(self):
        """One argument: a {group} or a single token."""
        self.skip_space()
        t = self.peek()
        if t is None:
            return ""
        if t == ("char", "{"):
            self.i += 1
            return self.sequence("}")
        return self.atom()

    def atom_with_scripts(self):
        base = self.atom()
        sub = sup = ""
        while True:
            if self._script_after_space():
                self.skip_space()
            t = self.peek()
            if t == ("char", "^"):
                self.i += 1
                sup += self.argument()
            elif t == ("char", "_"):
                self.i += 1
                sub += self.argument()
            elif t == ("char", "'"):
                self.i += 1
                base += "′"
            else:
                break
        return base + (f"<sub>{sub.strip()}</sub>" if sub else "") + (f"<sup>{sup.strip()}</sup>" if sup else "")

    def _script_after_space(self):
        j = self.i
        while j < len(self.tokens) and self.tokens[j][0] == "space":
            j += 1
        return j < len(self.tokens) and self.tokens[j] in (("char", "^"), ("char", "_"))

    def atom(self):
        t = self.take()
        if t is None:
            return ""
        kind, value = t
        if kind == "space":
            return ""
        if kind == "char":
            if value == "{":
                return self.sequence("}")
            if value == "}":
                return ""
            if value == "&":          # alignment point
                return " "
            if value == "~":
                return " "
            if value == "-":
                return " − "
            if value in SPACED:
                return f" {_esc(value)} "
            if value == ",":
                return ", "
            if value.isalpha():
                return f"<i>{_esc(value)}</i>"
            return _esc(value)
        return self.command(value)

    def command(self, name):
        if name == "\\":              # a new line
            return "<br/>"
        if name in ("frac", "dfrac", "tfrac", "cfrac"):
            num, den = self.argument(), self.argument()
            return f"{_group(num.strip())}/{_group(den.strip())}"
        if name in ("binom", "dbinom", "tbinom"):
            n, k = self.argument(), self.argument()
            return f"C({n.strip()}, {k.strip()})"
        if name == "sqrt":
            self.skip_space()
            index = ""
            if self.peek() == ("char", "["):
                self.i += 1
                index = self.sequence("]")
            body = self.argument().strip()
            return (f"<sup>{index.strip()}</sup>" if index else "") + f"√({body})"
        if name in ("text", "textrm", "textnormal", "mbox", "textit", "textbf", "operatorname"):
            text = _esc(self.raw_group())
            return {"textit": f"<i>{text}</i>", "textbf": f"<b>{text}</b>"}.get(name, text)
        if name in ("mathrm", "mathsf", "mathtt", "rm"):
            return re.sub(r"</?i>", "", self.argument())
        if name in ("mathbf", "boldsymbol", "bm", "bf"):
            return f"<b>{re.sub(r'</?i>', '', self.argument())}</b>"
        if name in ("mathit", "it"):
            return f"<i>{re.sub(r'</?i>', '', self.argument())}</i>"
        if name in ("mathbb", "mathbbm"):
            arg = re.sub(r"<[^>]+>", "", self.argument())
            return "".join(BLACKBOARD.get(c, c) for c in arg)
        if name in ACCENTS:
            arg = self.argument()
            return re.sub(r"([^<>\s])(?=(</i>)?$)", lambda m: m.group(1) + ACCENTS[name], arg, count=1)
        if name in ("pmod",):
            return f" (mod {self.argument().strip()})"
        if name in ("bmod",):
            return " mod "
        if name in ("begin",):
            env = self.raw_group().rstrip("*")
            if env == "array":
                self.raw_group()          # column spec
            body = self.sequence("end")
            if env in ("pmatrix", "bmatrix", "vmatrix", "matrix", "cases"):
                rows = [r.strip() for r in body.split("<br/>")]
                left, right = {"pmatrix": ("(", ")"), "bmatrix": ("[", "]"), "vmatrix": ("|", "|"),
                               "cases": ("{ ", "")}.get(env, ("", ""))
                return left + "; ".join(rows) + right
            return "<br/>" + body + "<br/>" if "<br/>" in body else body
        if name in ("end",):
            self.raw_group()
            return ""
        if name in FUNCTIONS:
            return f"{name} "
        if name in SYMBOLS:
            return _esc(SYMBOLS[name])
        if name in ("hspace", "vspace", "phantom", "label", "tag"):
            self.raw_group()
            return " " if name == "hspace" else ""
        return _esc(name)
