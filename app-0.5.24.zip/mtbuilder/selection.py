"""Which questions each exam gets, in which order, and what the correct answers print as."""



from . import canvas, qr_payload
from .errors import ExamError, warn
from .exam_pdf import LETTERS
from .i18n import t
from .classlist import _read_csv, inline_title_map


class Selector:
    """Chooses and shuffles the questions of one exam variant."""

    def __init__(self, quiz, max_items=None, item_banks=True, title_map=None, essays=True):
        """At most one of --max-items, --ignore-item-banks (item_banks=False) and --title-map. By default
        (item_banks=True) item banks and question groups with a "pick N" rule give N questions each;
        every other question is printed. essays=False: essay questions are left out (single-page quizzes)."""
        self.quiz = quiz
        self.essays = essays
        self.mode, self.max_items, self.title_counts = "none", None, None
        pool = len(quiz.questions)
        if max_items is not None:
            if not 1 <= max_items <= pool:
                raise ExamError(f"--max-items must be a number from 1 to {pool} (the usable questions in the export).")
            self.mode, self.max_items = "maxitems", max_items
        elif title_map is not None:
            self.mode = "titlemap"
            self.title_counts = self._read_title_map(title_map.strip())
        elif item_banks and any(g.select is not None for g in quiz.groups):
            self.mode = "useitembanks"

    def _read_title_map(self, path):
        if not path:
            raise ExamError("--title-map needs a filename.")
        by_title = {}
        for q in self.quiz.questions:
            by_title.setdefault(q.title.strip(), []).append(q.index)
        counts = {}
        inline = inline_title_map(path)
        if inline is not None:
            rows, where = inline, "--title-map"
        else:
            rows = [r for r in _read_csv(path, "title map") if any(c.strip() for c in r)]
            where = f"Title map '{path}'"
        for n, row in enumerate(rows):
            title = row[0].strip()
            count = row[1].strip() if len(row) > 1 else ""
            if not count.isdigit():
                if n == 0 and inline is None:
                    continue  # header row
                raise ExamError(f"{where}: '{title}' needs a whole number of questions, not '{count}'.")
            if title not in by_title:
                raise ExamError(f"{where}: no usable question in the export has the title '{title}'.")
            if int(count) > len(by_title[title]):
                raise ExamError(f"{where}: '{title}' asks for {count} questions but only {len(by_title[title])} exist.")
            counts[title] = (int(count), by_title[title])
        unused = sorted(t for t in by_title if t not in counts)
        if unused:
            warn("Question titles not listed in the title map are left out of the exam: " + ", ".join(repr(t) for t in unused))
        if not sum(c for c, _ in counts.values()):
            raise ExamError(f"{where} selects no questions.")
        return counts

    def max_questions(self):
        if self.mode == "maxitems":
            return self.max_items
        if self.mode == "useitembanks":
            return sum(len(g.indices) if g.select is None else g.select for g in self.quiz.groups)
        if self.mode == "titlemap":
            return sum(c for c, _ in self.title_counts.values())
        return len(self.quiz.questions)

    def draw(self, rng):
        """Returns [(Question, option permutation)] in printed order."""
        qs = self.quiz.questions
        if self.mode == "maxitems":
            chosen = rng.sample(range(len(qs)), self.max_items)
        elif self.mode == "useitembanks":
            chosen = []
            for g in self.quiz.groups:
                avail = [i for i in g.indices if i not in chosen]
                chosen += avail if g.select is None else rng.sample(avail, min(g.select, len(avail)))
        elif self.mode == "titlemap":
            chosen = []
            for count, indices in self.title_counts.values():
                chosen += rng.sample(indices, count)
        else:
            chosen = list(range(len(qs)))
        rng.shuffle(chosen)
        selection = []
        for i in chosen:
            q = qs[i]
            if q.kind == "numeric":         # which worked example (value set) this exam prints
                selection.append((q, [rng.randrange(len(q.value_sets))]))
                continue
            if q.kind in ("text", "essay"):
                selection.append((q, []))
                continue
            if q.kind == "match":               # the seed of this exam's order of the answers (or items)
                seed = rng.randrange(1 << qr_payload.MATCH_SEED_BITS)
                while q.ordering and not canvas.ordering_shuffled(seed, len(q.prompts)):
                    seed = rng.randrange(1 << qr_payload.MATCH_SEED_BITS)   # never printed in the right order
                selection.append((q, [seed]))
                continue
            # perm[i] = pre-randomized position of the option printed in slot i
            perm = list(range(len(q.options)))
            if q.qtype == "true_false_question":  # always printed as written: True, then False
                perm.sort(key=lambda i: q.options[i].export_pos)
            else:
                rng.shuffle(perm)
            selection.append((q, perm))
        # essays come last, in their shuffled order: their answer spaces are at the end of the answer card
        rest = [s for s in selection if s[0].kind != "essay"]
        return rest + ([s for s in selection if s[0].kind == "essay"] if self.essays else [])


def correct_letters(question, perm):
    """The correct answer as printed: letters for multiple choice, the number for a calculated
    question, accepted answers separated by | for fill-in-the-blank."""
    if question.kind == "numeric":
        return question.value_sets[perm[0]][1]
    if question.kind == "text":
        return "|".join(question.accepted)
    if question.kind == "essay":
        return t("essay_key")
    if question.kind == "match":         # a3 b1 c4: each item's letter and the number of its answer
        return " ".join(f"{'abcdefghijklmnopqrstuvwxyz'[k]}{n}" for k, n in enumerate(question.printed_answers(perm)[1]))
    printed = [i for i in perm if not question.options[i].empty]
    return "".join(LETTERS[k] for k, i in enumerate(printed) if question.options[i].correct)
