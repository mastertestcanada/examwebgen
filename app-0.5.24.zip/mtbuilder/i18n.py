"""The language of everything MasterTest Builder prints (--print-language), and the decimal mark
used for numbers on the page (--decimal-mark).

The printed language is separate from the language of the program's own messages: a teacher may
print a French test from an English program, or the reverse. Each text has one entry per
language, in mtbuilder/locales/<language>.json; `t(key, **values)` returns it in the current print language. Numbers the program
prints (calculated-question values, points) use the decimal mark; the QR codes and the
answer_key.csv always use a point, so marking does not depend on the language.
"""

from . import locales

LANGUAGES = {code: locales.load(code).get("language", code) for code in locales.codes()}

# A non-breaking space, which French puts before ":" and inside « ».
NBSP = "\u00a0"

# key: {language: text}, from mtbuilder/locales/<language>.json ("printed")
TEXT = {}
for _code in LANGUAGES:
    for _key, _text in locales.load(_code).get("printed", {}).items():
        TEXT.setdefault(_key, {})[_code] = _text

_language = "en"
_comma = False


def set_language(language="en", decimal_mark=None):
    """`decimal_mark`: "point", "comma", or None for the language's usual mark (French: comma)."""
    global _language, _comma
    if language not in LANGUAGES:
        raise ValueError(f"unknown print language {language!r}")
    _language = language
    _comma = (decimal_mark == "comma") if decimal_mark else bool(_rules().get("decimal_comma"))


def language():
    return _language


def decimal_comma():
    return _comma


def usual_decimal_comma():
    """Whether the print language usually writes the decimal comma, whatever --decimal-mark says."""
    return bool(_rules().get("decimal_comma"))


def _rules():
    """How the print language writes numbers and labels (locales/<language>.json, "rules")."""
    return locales.load(_language).get("rules", {})


def label(text):
    """A label followed by a colon, as the language writes it ("Nom :" in French)."""
    return _rules().get("label", "{0}:").format(text)


def t(key, **values):
    entry = TEXT[key]
    text = entry.get(_language) or entry["en"]
    if "{mark}" in text:
        values.setdefault("mark", entry_text("mark_comma" if _comma else "mark_point"))
    return text.format(**values)


def entry_text(key):
    entry = TEXT[key]
    return entry.get(_language) or entry["en"]


def number(text):
    """A number as printed: with the decimal comma when that is the mark ("2.5" -> "2,5")."""
    text = str(text)
    return text.replace(".", ",") if _comma else text


def points_text(points):
    """"(2 pts)", "(1 pt)"; French: 1,5 pt but 2 pts. "" when the question has no points."""
    if points is None:
        return ""
    n = int(points) if float(points).is_integer() else points
    # English: 1 pt but 1.5 pts; French: 1,5 pt but 2 pts
    one = points < 2 if _rules().get("singular_below_two") else points == 1
    return t("points_one" if one else "points_many", n=number(n))


def order_hint(question, merged=False):
    """The line under an ordering question: what to write, and what 1 and the last position mean
    ("1 = Strongest … 4 = Weakest", from the quiz; else "1 = first … 4 = last")."""
    from html import escape
    top, bottom = question.scale
    scale = t("order_scale", top=escape(top or t("order_first")), bottom=escape(bottom or t("order_last")),
              n=len(question.prompts))
    return t("order_hint_merged" if merged else "order_hint", scale=scale)


def select_hint(question):
    """The line under a multiple-answer question: "Select all that apply.", or, when D2L limits the
    choices to the number of correct answers, "Select only 2 answers."."""
    if question.scoring != "limited":
        return t("select_all")
    n = sum(1 for o in question.options if o.correct)
    return t("select_one") if n == 1 else t("select_n", n=n)
