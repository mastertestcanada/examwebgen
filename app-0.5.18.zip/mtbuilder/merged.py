"""Merged single-page quizzes (page sizes letter-merged and A4-merged).

The questions and the answer spaces share the page: two columns of questions, each with an answer
gutter down its right side, where every question's bubbles, number box or text box sits level with
the question. A quiz runs onto further sheets when it does not fit on one. Every sheet carries a
compact header (title, name, student number, QR code) and the four corner squares.

The card QR code (schema 0x20, kind 2) records, for every question on the sheet, which column it is in and
how far down the page its answer is, so a scanner can find the answers whatever the questions'
lengths. Everything else on the sheet is at fixed positions that depend only on the paper size;
MasterTest Marker's MergedGeometry must match the constants below.
"""

import io
from dataclasses import replace as dc_replace

from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import Spacer, Table, TableStyle

from .answer_card import bubble, draw_qr, draw_cells, SHADING
from .card_instructions import CardInstructions, draw as draw_instructions, height as instruction_height
from .canvas import question_html
from .exam_pdf import ITEM_LETTERS, match_answers_table
from .errors import ExamError
from . import i18n
from .fonts import enclosed_letter
from .i18n import label

# ---- fixed geometry (points; origin at the bottom-left corner of the page)
MARGIN = 40.0            # content left and right
INSET = 32.0             # centres of the corner squares, from the page edges
MARK = 14.0              # corner square size
QR_SIZE = 104.0          # QR code including its quiet zone, top right (large enough for 2-3 MP preview frames)
QR_TOP = 40.0            # from the top of the page
HEADER_BOTTOM = 156.0    # divider below the header, from the top of the page
CONTENT_TOP = 164.0      # first question, from the top of the page
CONTENT_BOTTOM = 52.0    # from the bottom of the page
COVER_MARGIN = 40.0      # top and bottom of a cover page (quiz instructions too long for the first sheet)
COLUMN_GAP = 14.0
LEADER_DOT = 0.45        # dotted leaders from a matching item to its cells (one-column sheets): dot radius,
LEADER_STEP = 3.2        # ... spacing,
LEADER_CLEAR = 0.45      # ... and they stop this many cell widths before the cells (MasterTest Marker reads 0.35)
ESSAY_COLUMN = -1        # a sheet entry that is an essay: across the whole width, below the columns
ESSAY_MIN_BOX = 40.0     # the least answer space under an essay's text
RULE_SHORT = 6.0         # a rule between questions stops this far before the answer gutter
NUMBER_WIDTH = 20.0
PITCH = 13.2             # bubble pitch
BUBBLE_RADIUS = 5.4
CELL_W = 15.0            # one character cell of a number box (13.2 before 0.2.3: QR flag bit 4 clear)
BOX_HALF = 9.5           # boxes are 19 pt tall (16 before 0.2.3)
BOX_CELLS = 6
ANSWER_WIDTH = BOX_CELLS * CELL_W  # default width of the answer column (--answer-width); bubbles and boxes scale with it
SCALE_CAP = 120.0        # bubbles and box height scale with the answer width only up to this width (k <= 4/3)
GUTTER_AIR = 4.8         # the answer gutter is the answer width plus this
DIGIT_W = 15.0           # handwritten student-number and seat boxes
DIGIT_H = 22.0
ID_DIGITS = 9
SEAT_DIGITS = 3
MAX_CHOICES = 4              # options (A-D) a question may have on a two-column sheet
MAX_CHOICES_ONE_COLUMN = 6   # and on a one-column sheet (A-F): the answer gutter has room for six bubbles
MAX_SHEETS = 16
LETTERS = "ABCDEF"


def column_width(W):
    return (W - 2 * MARGIN - COLUMN_GAP) / 2


def answer_scale(aw):
    """The width that sets the size of bubbles and the height of boxes: the answer width, at most
    SCALE_CAP, so wide answer boxes get longer rather than also taller (0.3.3; QR SCALE_FLAG)."""
    return min(aw, SCALE_CAP)


def _leader_start(flowables, width):
    """Where a matching item's dotted leader can start (points from its left): the end of its text
    when it is a single line, else the text's right-hand margin (`width`), so that the dots never run
    over a longer line underneath."""
    from reportlab.platypus import Paragraph
    f = flowables[0] if len(flowables) == 1 else None
    if not isinstance(f, Paragraph):
        return width
    f.wrap(width, 100000)
    bl = getattr(f, "blPara", None)
    if bl is None or len(bl.lines) != 1:
        return width
    line = bl.lines[0]
    extra = line[0] if bl.kind == 0 else getattr(line, "extraSpace", 0)
    return max(0.0, width - extra)


def gutter_left(W, col, aw=ANSWER_WIDTH):
    """Left edge of the answer gutter's widgets (bubble A's cell, or a box's left side) in column `col`."""
    cw = column_width(W)
    return MARGIN + col * (cw + COLUMN_GAP) + cw - aw - 2.0


def header_boxes(W, H):
    """Blank cards: (name box, first student-number box, first seat box) as (left, bottom, width, height)."""
    qr_left = W - MARGIN - QR_SIZE
    available = qr_left - 12 - MARGIN
    ids = ID_DIGITS * DIGIT_W
    seats = SEAT_DIGITS * DIGIT_W
    name_w = available - ids - seats - 2 * 14
    top = H - 69.0
    name = (MARGIN, top - DIGIT_H, name_w, DIGIT_H)
    id_left = MARGIN + name_w + 14
    seat_left = id_left + ids + 14
    return name, (id_left, top - DIGIT_H, DIGIT_W, DIGIT_H), (seat_left, top - DIGIT_H, DIGIT_W, DIGIT_H)


def fiducials(W, H):
    return [[INSET, H - INSET], [W - INSET, H - INSET], [INSET, INSET], [W - INSET, INSET]]


def widget_spots(W, col, yc, kind, bubbles, aw=ANSWER_WIDTH):
    """Bubble centres or the box of one answer, for the manifest and the drawing. Boxes fill the
    answer area; bubbles end at its right edge. Bubble pitch and size, and box height, scale with
    the answer width `aw` up to SCALE_CAP (answer_scale())."""
    gx = gutter_left(W, col, aw)
    k = answer_scale(aw) / ANSWER_WIDTH
    if kind == "choice":
        first = gx + aw - bubbles * k * PITCH
        return {"bubbles": [[first + k * PITCH / 2 + j * k * PITCH, yc] for j in range(bubbles)], "bubble_radius": BUBBLE_RADIUS * k}
    if kind == "match":     # one item's digit cells (`bubbles` of them), ending at the right edge
        cw = aw / BOX_CELLS
        return {"box": [gx + aw - bubbles * cw, yc - BOX_HALF * k, bubbles * cw, 2 * BOX_HALF * k], "cells": bubbles}
    return {"box": [gx, yc - BOX_HALF * k, aw, 2 * BOX_HALF * k], "cells": BOX_CELLS if kind == "numeric" else 1}


class SheetLimit(ExamError):
    """A merged quiz needs more than MAX_SHEETS sheets."""


def check_choices(questions, columns=2):
    """Merged quizzes print at most four options per question in two columns, six in one."""
    most = MAX_CHOICES if columns == 2 else MAX_CHOICES_ONE_COLUMN
    for q in questions:
        if q.kind == "choice" and q.printed_option_count > most:
            label = q.title or q.ident
            hint = " Use --columns 1 (up to six options), another page size, or shorten the question." if columns == 2 \
                else " Use another page size or shorten the question."
            raise ExamError(f"Question '{label}' ({q.ident}) has {q.printed_option_count} options; a {columns}-column "
                            f"merged --page-size allows at most {most} ({LETTERS[0]}-{LETTERS[most - 1]}).{hint}")


class MergedBuilder:
    """Lays out and draws merged quizzes, using an ExamBuilder's renderer for the question text."""

    def __init__(self, exam_builder, pagesize, spacing=None, hints=(None, None), pad_options=False, shading=SHADING,
                 columns=2, answer_width=None, instructions=None, title_page=False, pad_title_page=False, rules=False):
        self.eb = exam_builder
        # --question-rules: a thin grey line between questions, from the question numbers to just
        # before the answer gutter (it stops short of the answers, where a digit written over it
        # would join it), so a question is easy to follow across to its answer
        self.rules = rules
        # --page-options title-page: a cover page (not scanned) with the quiz title and instructions;
        # without it the instructions go above the questions on the first sheet
        self.title_page = title_page
        self.pad_title_page = pad_title_page and title_page
        self.L = exam_builder.layout
        self.R = exam_builder.renderer
        self.W, self.H = pagesize
        self.spacing = 6.0 if spacing is None else spacing
        self.hints = hints            # (calculated, fill-in) instruction lines; None = none
        self.pad_options = pad_options
        self.shading = shading        # darkness of the shaded answer cells; 0 = outlined boxes
        # one column (--columns 1): the questions run the full width and every answer sits
        # in the right-hand gutter, exactly where column 1's answers are in the two-column layout,
        # so the QR code describes them the same way (column 1) and the marking app needs nothing new
        self.columns = columns
        self.instructions = instructions or CardInstructions.load()        # --answer-card-instructions
        self.set_answer_width(answer_width)

    def set_answer_width(self, answer_width):
        """--answer-width (None: the default); bubbles and box heights scale with it up to SCALE_CAP."""
        self.aw = ANSWER_WIDTH if answer_width is None else answer_width
        self.half = BOX_HALF * answer_scale(self.aw) / ANSWER_WIDTH                      # half the height of an answer box

    # ------------------------------------------------------------ question blocks
    def _block(self, question, perm, variables):
        """A flowable holding the question's text (and options) at the column's text width."""
        L, R = self.L, self.R
        width = self.text_width
        base = R.base_ctx()
        content = R.render(self.eb._html(question_html(question, perm), True, variables), width)
        self.item_offsets = []
        self.item_ends = []
        if question.kind == "match":
            self._match_parts(question, perm, variables, width, content)
        hint = self.hints[0] if question.kind == "numeric" else self.hints[1] if question.kind == "text" else None
        if hint:
            content.append(R.paragraph(hint, dc_replace(base, italic=True), spaceBefore=2))
        if question.qtype == "multiple_answers_question":
            content.append(R.paragraph(i18n.t("select_all"), dc_replace(base, italic=True), spaceBefore=1))
        if question.kind == "choice":
            printed = [question.options[i] for i in perm if not question.options[i].empty]
            content.append(Spacer(1, L.font_size * 0.2))
            content.append(self._options(printed, variables, width))
        if not content:
            content = [R.paragraph("", base)]
        block = Table([[content]], colWidths=[width])
        block.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                   ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                                   ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return block

    def _essay_block(self, question, variables, width):
        """An essay question's text at the full width of the sheet; its answer space goes under it."""
        R = self.R
        content = R.render(self.eb._html(question_html(question, []), True, variables), width) or [R.paragraph("", R.base_ctx())]
        content.append(R.paragraph(i18n.t("essay") + " " + i18n.points_text(question.points),
                                   dc_replace(R.base_ctx(), italic=True), spaceBefore=2))
        block = Table([[content]], colWidths=[width])
        block.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                   ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                                   ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        block.item_offsets = []
        return block

    def _match_parts(self, question, perm, variables, width, content):
        """Adds a matching question's instruction, numbered answers and items to `content`; each item
        gets a line of its own with its box beside it, and self.item_offsets the distance from the
        top of the block to the centre of each item's box."""
        L, R = self.L, self.R
        base = R.base_ctx()
        content.append(R.paragraph(i18n.t("match_hint_merged"), dc_replace(base, italic=True), spaceBefore=2))
        content.append(Spacer(1, L.font_size * 0.2))
        content.append(match_answers_table(self.eb, question, perm, variables, width))
        content.append(Spacer(1, L.font_size * 0.3))
        y = sum(f.wrap(width, 100000)[1] + f.getSpaceBefore() + f.getSpaceAfter() for f in content)
        letter_w = L.font_size * 1.6
        least = 2 * self.half + 3            # an item's line is at least as tall as its box
        for k, text in enumerate(question.prompts):
            body = R.render(self.eb._html(text, True, variables), width - letter_w) or [R.paragraph("", base)]
            row = Table([[R.paragraph(ITEM_LETTERS[k], dc_replace(base, bold=True)), body]], colWidths=[letter_w, width - letter_w])
            style = [("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                     ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0), ("VALIGN", (0, 0), (-1, -1), "TOP")]
            row.setStyle(TableStyle(style))
            h = row.wrap(width, 100000)[1]
            if h < least:                     # centre the line in a box-high row
                pad = (least - h) / 2
                row.setStyle(TableStyle([("TOPPADDING", (0, 0), (-1, -1), pad), ("BOTTOMPADDING", (0, 0), (-1, -1), pad)]))
                h = row.wrap(width, 100000)[1]
            # the box centred on a one-line item; level with the first line of a longer one
            self.item_offsets.append(y + min(h, least) / 2)
            self.item_ends.append(letter_w + _leader_start(body, width - letter_w))
            content.append(row)
            y += h

    def _options(self, printed, variables, width):
        """The options, as many to a line as fit: 4, 2 or 1 columns."""
        L, R = self.L, self.R
        base = R.base_ctx()
        optface = self.eb.fonts.face(L.option_family)
        dot = "." if L.option_dot else ""
        marks = [enclosed_letter(k, L.option_letters) + dot for k in range(len(printed))]
        letter_w = max(self.eb.fonts.width(m, optface, L.option_size) for m in marks) + L.font_size * 0.5 + 1
        octx = dc_replace(base, family=L.option_family, size=L.option_size)
        one_line = L.font_size * 1.6
        for cols in (4, 2, 1):
            if cols > len(printed) and cols != 1:
                continue
            cell_w = width / cols
            cells, fits = [], True
            for k, opt in enumerate(printed):
                body = R.render(self.eb._html(opt.text, opt.is_html, variables), cell_w - letter_w - 4) or [R.paragraph("", base)]
                t = Table([[R.paragraph(marks[k], octx), body]], colWidths=[letter_w, cell_w - letter_w])
                t.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                       ("RIGHTPADDING", (1, 0), (1, 0), 4),
                                       ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
                                       ("VALIGN", (0, 0), (-1, -1), "TOP")]))
                if t.wrap(cell_w, 100000)[1] > one_line:
                    fits = False
                cells.append(t)
            if fits or cols == 1:
                rows = [cells[i:i + cols] + [""] * (cols - len(cells[i:i + cols])) for i in range(0, len(cells), cols)]
                table = Table(rows, colWidths=[cell_w] * cols)
                table.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                           ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
                return table

    @property
    def text_width(self):
        if self.columns == 1:
            return self.W - 2 * MARGIN - NUMBER_WIDTH - self.aw - GUTTER_AIR - 6.0
        return column_width(self.W) - NUMBER_WIDTH - self.aw - GUTTER_AIR - 6.0

    def text_left(self, col):
        """Left edge of the question numbers in column `col`."""
        return MARGIN if self.columns == 1 else MARGIN + col * (column_width(self.W) + COLUMN_GAP)

    # ------------------------------------------------------------ layout
    def _intro(self, variables):
        """The quiz instructions as flowables, and their height."""
        if not (self.L.instructions and self.eb.quiz.description):
            return [], 0.0
        intro = self.R.render(self.eb._html(self.eb.quiz.description, True, variables), self.W - 2 * MARGIN)
        return intro, sum(f.wrap(self.W - 2 * MARGIN, 100000)[1] + f.getSpaceBefore() + f.getSpaceAfter() for f in intro)

    def layout(self, selection, variables, who):
        """Places every question. Returns (instructions flowables, sheets, cover); a sheet is a list of
        (selection index, column, block top, block, block height). With a title page (`cover` True)
        the title and instructions are on a page of their own before the first sheet, not scanned;
        otherwise the instructions go above the questions of the first sheet, across its columns.
        [[QUESTION COUNT]] is the number of questions, [[PAGE COUNT]] the number of sheets."""
        variables = dict(variables)
        variables["QUESTION COUNT"] = len(selection)
        variables["PAGE COUNT"] = "00"            # until the sheets are counted
        intro, intro_h = self._intro(variables)
        for _ in range(3):                        # the page count can change the instructions' height
            sheets, cover = self._place(selection, variables, who, intro_h)
            variables["PAGE COUNT"] = len(sheets)
            intro, new_h = self._intro(variables)
            if abs(new_h - intro_h) < 0.01 or cover:
                break
            intro_h = new_h
        if cover:
            intro = self._cover(variables)
        return intro, sheets, cover

    def _cover(self, variables):
        """The title page: the quiz title and instructions, made smaller until they fit the page."""
        width, room, scale = self.W - 2 * MARGIN, self._cover_room(), 1.0
        while True:
            flows = self.eb._title_block(self.R.scaled(scale), variables, width)
            h = sum(f.wrap(width, 100000)[1] + f.getSpaceBefore() + f.getSpaceAfter() for f in flows)
            if h <= room or scale < 0.15:
                return flows
            scale *= 0.94

    def _cover_room(self):
        return self.H - 2 * COVER_MARGIN

    def _place(self, selection, variables, who, intro_h):
        H = self.H
        col_h = H - CONTENT_TOP - CONTENT_BOTTOM
        cover = self.title_page
        first_col = 1 if self.columns == 1 else 0     # one column: its answers use column 1's gutter
        sheets, sheet, col = [], [], first_col
        # the first sheet's columns start under the instructions (they run across the whole width)
        first_top = H - CONTENT_TOP - (intro_h + 6 if intro_h and not cover else 0)
        y = first_top
        for i, (q, perm) in enumerate(selection):
            if q.kind == "essay":          # essays come last; they are placed below
                break
            block = self._block(q, perm, variables)
            block.item_offsets = self.item_offsets
            block.item_ends = self.item_ends
            h = max(block.wrap(self.text_width, 100000)[1], 2 * self.half + 1)
            if h > col_h:
                raise ExamError(f"Question {i + 1} ({q.ident}) is {h:.0f} pt tall, more than a column of a merged "
                                f"quiz ({col_h:.0f} pt). Use a smaller --font-size or another page size.")
            if y - h < CONTENT_BOTTOM:
                col += 1
                y = first_top if not sheets else H - CONTENT_TOP
                if col == 2:
                    if not sheets and not sheet:
                        raise ExamError(f"The quiz instructions take {intro_h:.0f} pt, too much to leave room for "
                                        f"question 1 on the first sheet, for {who}. Shorten them, print them on a "
                                        f"title page (--page-options title-page) or use --no-quiz-instructions.")
                    sheets.append(sheet)
                    sheet, col = [], first_col
                    y = H - CONTENT_TOP
            sheet.append((i, col, y, block, h))
            y -= h + self.spacing
        # essays: across the whole width, under everything else on the last sheet, each taking its
        # fraction of a column's height (question and answer space together); then on further sheets
        width = self.W - 2 * MARGIN - NUMBER_WIDTH
        for i, (q, perm) in enumerate(selection):
            if q.kind != "essay":
                continue
            block = self._essay_block(q, variables, width)
            text_h = block.wrap(width, 100000)[1]
            need = q.essay_quarters / 4 * col_h
            top = (min(t - h for _i, _c, t, _b, h in sheet) - self.spacing if sheet
                   else first_top if not sheets else H - CONTENT_TOP)
            if sheet and top - need < CONTENT_BOTTOM - 0.5:      # on a sheet of its own
                sheets.append(sheet)
                sheet, top = [], H - CONTENT_TOP
            need = min(need, top - CONTENT_BOTTOM)          # a first sheet under long instructions
            if need - text_h < ESSAY_MIN_BOX:
                raise ExamError(f"Question {i + 1} ({q.ident}), an essay, has too long a text for its answer space "
                                f"({q.essay_quarters}/4 page). Give it more space, for example \"(1/2 page)\" in its "
                                f"name in Canvas or a larger --essay-space.")
            sheet.append((i, ESSAY_COLUMN, top, block, need))
        sheets.append(sheet)
        if len(sheets) > MAX_SHEETS:
            raise SheetLimit(f"The quiz for {who} needs {len(sheets)} sheets; a merged quiz can have at most {MAX_SHEETS}.")
        return sheets, cover

    def _leader(self, c, x0, x1, y):
        """A dotted leader from x0 to x1 at height y (nothing when there is no room)."""
        if x1 - x0 < 3 * LEADER_STEP:
            return
        c.saveState()
        # one dashed line of zero-length dashes with round ends: round dots, in a single small path
        c.setStrokeGray(0.45)
        c.setLineWidth(2 * LEADER_DOT)
        c.setLineCap(1)
        c.setDash([0, LEADER_STEP])
        c.line(x0, y, x1, y)
        c.restoreState()

    def _draw_essay(self, c, number, top, block, h, bold):
        """An essay: its number and text, then a box with light writing lines down to the end of its space."""
        L = self.L
        left = MARGIN + NUMBER_WIDTH
        c.setFont(bold, L.font_size)
        c.setFillGray(0)
        c.drawRightString(MARGIN + NUMBER_WIDTH - 4, top - L.font_size * 1.05, f"{number}.")
        _bw, bh = block.wrapOn(c, self.W - 2 * MARGIN - NUMBER_WIDTH, 100000)
        block.drawOn(c, left, top - bh)
        box_top, bottom = top - bh - 4, top - h + 4
        c.saveState()
        c.setLineWidth(0.6)
        c.setStrokeGray(0.55)
        c.rect(left, bottom, self.W - MARGIN - left, box_top - bottom, stroke=1, fill=0)
        c.setStrokeGray(0.85)
        c.setLineWidth(0.4)
        y = box_top - 22
        while y > bottom + 6:
            c.line(left + 6, y, self.W - MARGIN - 6, y)
            y -= 22
        c.restoreState()

    def answer_y(self, block_top):
        """Centre of a question's answer: level with its first line."""
        return block_top - self.half

    # ------------------------------------------------------------ drawing
    def build(self, selection, variables, who, payload_for, *, quiz_title, blank, name, number, seat, variant,
              card_id, qr_quality):
        """Returns (pdf bytes, per sheet: {payload, first_number, spots}). payload_for(sheet index,
        first number, [selection indices], [(column, y from the top)]) gives a sheet's QR payload."""
        intro, sheets, cover = self.layout(selection, variables, who)
        self.cover = cover            # the PDF starts with a cover page holding the quiz instructions
        W, H = self.W, self.H
        fonts, L = self.eb.fonts, self.L
        font, bold = fonts.face(L.family), fonts.face(L.family, bold=True)
        buf = io.BytesIO()
        c = rl_canvas.Canvas(buf, pagesize=(W, H))
        c.setTitle(quiz_title)
        c.setAuthor("MasterTest Builder")
        out = []
        if cover:   # the title page: the quiz title and instructions, before the first sheet
            y = H - COVER_MARGIN
            for f in intro:
                _w, h = f.wrap(W - 2 * MARGIN, 100000)
                y -= f.getSpaceBefore()
                f.drawOn(c, MARGIN, y - h)
                y -= h + f.getSpaceAfter()
            c.showPage()
            if self.pad_title_page:   # a blank back, so the first sheet starts on a new sheet of paper
                c.showPage()

        def safe(text, face):
            return "".join(ch if ch.isspace() or fonts.has_glyph(face, ch) else "?" for ch in str(text))

        for s, sheet in enumerate(sheets):
            first = sheet[0][0] + 1 if sheet else 1
            spots = []
            for _i, col, top, block, _h in sheet:      # a matching question: one position per item
                if col == ESSAY_COLUMN:                 # an essay has none
                    continue
                ys = [top - off for off in block.item_offsets] if block.item_offsets else [self.answer_y(top)]
                spots += [(col, round(H - y, 1)) for y in ys]
            payload = payload_for(s, first, [i for i, *_ in sheet], spots)
            # corner squares
            c.setFillGray(0)
            for x, y in fiducials(W, H):
                c.rect(x - MARK / 2, y - MARK / 2, MARK, MARK, stroke=0, fill=1)
            # QR code and header
            qx, qy = W - MARGIN - QR_SIZE, H - QR_TOP - QR_SIZE
            draw_qr(c, payload, qx, qy, QR_SIZE, qr_quality)
            title = safe(quiz_title, bold)
            room = qx - 12 - MARGIN
            size = 13.0
            while size > 7 and stringWidth(title, bold, size) > room:
                size -= 0.5
            c.setFont(bold, size)
            c.drawString(MARGIN, H - 52, title)
            sheet_note = i18n.t("sheet_of", n=s + 1, total=len(sheets)) if len(sheets) > 1 else ""
            if blank:
                name_box, id_box, seat_box = header_boxes(W, H)
                c.setFont(bold, 6.5)
                c.drawString(name_box[0], name_box[1] + DIGIT_H + 3, i18n.t("name_print"))
                c.drawString(id_box[0], id_box[1] + DIGIT_H + 3, i18n.t("student_number_caps"))
                c.drawString(seat_box[0], seat_box[1] + DIGIT_H + 3, i18n.t("seat_caps"))
                c.setLineWidth(0.8)
                c.setStrokeGray(0)
                c.rect(*name_box, stroke=1, fill=0)
                for box, n in ((id_box, ID_DIGITS), (seat_box, SEAT_DIGITS)):
                    draw_cells(c, box[0], box[1], n * DIGIT_W, DIGIT_H, n, self.shading)
                c.setFont(font, 7)
                bits = [f"{i18n.t('card')} {card_id}"] + ([f"{i18n.t('variant')} {variant}"] if variant else []) + ([sheet_note] if sheet_note else [])
                c.drawString(MARGIN, H - 103, "  ·  ".join(bits))
            else:
                c.setFont(font, 9)
                line = f"{label(i18n.t('name'))} {safe(name, font)}    {label(i18n.t('student_number'))} {safe(number, font)}"
                if seat:
                    line += f"    {label(i18n.t('seat'))} {safe(seat, font)}"
                c.drawString(MARGIN, H - 72, line)
                c.setFont(font, 7)
                bits = [f"{i18n.t('card')} {card_id}"] + ([f"{i18n.t('variant')} {variant}"] if variant else []) + ([sheet_note] if sheet_note else [])
                c.drawString(MARGIN, H - 86, "  ·  ".join(bits))
            # instructions (--answer-card-instructions): below the header details, above the divider
            conditions = {"merged", "blank" if blank else "named"}
            if any(q.kind != "choice" for q, _p in selection):
                conditions.add("written")
            iw = qx - 10 - MARGIN
            flow = self.instructions.flowables(fonts, L.family, 7.0, iw, conditions)
            room = HEADER_BOTTOM - 4 - 113
            if instruction_height(flow, iw) > room:
                raise ExamError(f"The answer-card instructions are {instruction_height(flow, iw):.0f} pt tall; a merged "
                                f"sheet has room for {room:.0f} pt. Shorten the --answer-card-instructions file or its images.")
            draw_instructions(c, flow, MARGIN, H - 113, iw)
            c.setFont(font, 6.5)
            c.drawCentredString(qx + QR_SIZE / 2, qy - 7, safe(card_id, font))
            c.setStrokeGray(0.6)
            c.setLineWidth(0.5)
            c.line(MARGIN, H - HEADER_BOTTOM, W - MARGIN, H - HEADER_BOTTOM)
            c.setStrokeGray(0.8)
            # the column divider stops above the essays, which run across the whole width
            essay_tops = [t for _i, col, t, _b, _h in sheet if col == ESSAY_COLUMN]
            if self.columns == 2 and any(col != ESSAY_COLUMN for _i, col, *_r in sheet):
                c.line(W / 2, H - CONTENT_TOP + 4, W / 2, (max(essay_tops) + 4) if essay_tops else CONTENT_BOTTOM - 2)
            c.setStrokeGray(0)
            # quiz instructions, first sheet only
            if s == 0 and intro and not cover:
                y = H - CONTENT_TOP
                for f in intro:
                    _w, h = f.wrap(W - 2 * MARGIN, 100000)
                    y -= f.getSpaceBefore()
                    f.drawOn(c, MARGIN, y - h)
                    y -= h + f.getSpaceAfter()
            # rules between consecutive questions in the same column, halfway across the gap
            if self.rules:
                c.saveState()
                c.setStrokeGray(0.72)
                c.setLineWidth(0.5)
                for (_i, col, top, _b, h), (_j, col2, top2, _b2, _h2) in zip(sheet, sheet[1:]):
                    if col2 != col:
                        continue
                    y = (top - h + top2) / 2
                    # clear of the strip MasterTest Marker reads around a number box (a third of a cell
                    # to its left), so the rule never touches what it reads
                    c.line(self.text_left(col), y, gutter_left(W, col, self.aw) - max(RULE_SHORT, 0.45 * self.aw / 6 + 2), y)
                c.restoreState()
            # questions and their answers
            sheet_spots = []
            for (i, col, top, block, h) in sheet:
                q, perm = selection[i]
                if col == ESSAY_COLUMN:
                    self._draw_essay(c, i + 1, top, block, h, bold)
                    continue
                cx = self.text_left(col)
                c.setFont(bold, L.font_size)
                c.setFillGray(0)
                c.drawRightString(cx + NUMBER_WIDTH - 4, top - L.font_size * 1.05, f"{i + 1}.")
                _bw, bh = block.wrapOn(c, self.text_width, 100000)
                block.drawOn(c, cx + NUMBER_WIDTH, top - bh)
                yc = self.answer_y(top)
                kind = q.kind
                if kind == "match":
                    for k, off in enumerate(block.item_offsets):
                        spot = widget_spots(W, col, top - off, "match", q.cells, self.aw)
                        if self.columns == 1:     # one column: dots lead from the item across to its cells
                            cw = spot["box"][2] / spot["cells"]
                            self._leader(c, cx + NUMBER_WIDTH + block.item_ends[k] + 5,
                                         spot["box"][0] - max(5.0, LEADER_CLEAR * cw + 2), top - off)
                        spot.update({"number": i + 1, "item": ITEM_LETTERS[k], "kind": kind, "column": col,
                                     "y_from_top": round(H - (top - off), 1)})
                        sheet_spots.append(spot)
                        left, bottom, width, height = spot["box"]
                        draw_cells(c, left, bottom, width, height, spot["cells"], self.shading)
                    continue
                # padding (pad_options: the quiz's most options): as many bubbles for every question
                n_bub = (self.pad_options if self.pad_options else q.printed_option_count) \
                    if kind == "choice" else 0
                spot = widget_spots(W, col, yc, kind, n_bub, self.aw)
                spot.update({"number": i + 1, "kind": kind, "column": col, "y_from_top": round(H - yc, 1)})
                sheet_spots.append(spot)
                if kind == "choice":
                    r = spot["bubble_radius"]
                    for k, (bx, by) in enumerate(spot["bubbles"]):
                        bubble(c, bx, by, r, LETTERS[k], font, 6 * r / BUBBLE_RADIUS, 2.1 * r / BUBBLE_RADIUS)
                else:
                    left, bottom, width, height = spot["box"]
                    draw_cells(c, left, bottom, width, height, spot["cells"], self.shading)
            c.showPage()
            out.append({"payload": payload, "first_number": first, "spots": sheet_spots,
                        "layout": {"page": [W, H], "fiducials": fiducials(W, H), "fiducial_size": MARK,
                                   "qr": {"x": qx, "y": qy, "size": QR_SIZE}, "merged": True, "answers": sheet_spots,
                                   **({"name_box": list(header_boxes(W, H)[0]), "id_box": list(header_boxes(W, H)[1]),
                                       "seat_box": list(header_boxes(W, H)[2])} if blank else {})}})
        c.save()
        return buf.getvalue(), out
